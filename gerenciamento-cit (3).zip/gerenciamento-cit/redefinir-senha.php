<?php
/**
 * redefinir-senha.php
 * ---------------------------------------------------------------------
 * Página aberta pelo link do e-mail de "Esqueci minha senha"
 * (api/recuperar_senha.php). Confere o código (token) da URL contra o
 * hash guardado em senha_reset — precisa existir, não ter sido usado e
 * estar dentro dos 30 minutos — e deixa a pessoa criar uma senha nova.
 * Depois de usado, o código não vale mais.
 *
 * Tudo é feito aqui no servidor (formulário comum com token CSRF), sem
 * depender do script.js.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';

$token = (string) ($_GET['token'] ?? $_POST['token'] ?? '');
$erro = '';
$sucesso = false;
$pedido = null;

/** Pedido de redefinição válido para este código, ou null. */
function buscarPedidoValido(PDO $pdo, string $token): ?array
{
    if (!preg_match('/^[0-9a-f]{64}$/', $token)) {
        return null;
    }
    $stmt = $pdo->prepare(
        "SELECT r.rese_id, u.usua_id, u.usua_nome
           FROM senha_reset r
           JOIN usuario u ON u.usua_id = r.rese_usuario_id
          WHERE r.rese_token_hash = ?
            AND r.rese_usado_em IS NULL
            AND r.rese_expira_em > NOW()
            AND u.usua_papel IN ('aluno','servidor')
            AND u.usua_aprovacao = 'aprovado' AND u.usua_ativo = 1"
    );
    $stmt->execute([hash('sha256', $token)]);
    return $stmt->fetch() ?: null;
}

$pdo = getPDO();
if (!$pdo) {
    $erro = 'Não foi possível conectar ao banco de dados. Tente novamente em alguns minutos.';
} else {
    $pedido = buscarPedidoValido($pdo, $token);

    if ($pedido && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $senha = (string) ($_POST['senha'] ?? '');
        $confirmacao = (string) ($_POST['senha_confirmar'] ?? '');

        if (!csrfValidate($_POST['csrf_token'] ?? null)) {
            $erro = 'Sessão do formulário expirada. Tente novamente.';
        } elseif (mb_strlen($senha) < SENHA_MIN_CARACTERES) {
            $erro = 'A senha precisa ter pelo menos ' . SENHA_MIN_CARACTERES . ' caracteres.';
        } elseif ($senha !== $confirmacao) {
            $erro = 'As senhas digitadas não são iguais.';
        } else {
            $pdo->beginTransaction();
            $pdo->prepare('UPDATE usuario SET usua_senha_hash = ? WHERE usua_id = ?')
                ->execute([password_hash($senha, PASSWORD_DEFAULT), $pedido['usua_id']]);
            // Marca este e qualquer outro pedido pendente como usados.
            $pdo->prepare('UPDATE senha_reset SET rese_usado_em = NOW() WHERE rese_usuario_id = ? AND rese_usado_em IS NULL')
                ->execute([$pedido['usua_id']]);
            $pdo->commit();
            // Se esta mesma pessoa estava logada neste navegador, sai —
            // ela entra de novo já com a senha nova.
            unset($_SESSION['usuario_id']);
            $sucesso = true;
        }
    }
}

// O código secreto está no endereço desta página: não deixa o navegador
// repassá-lo (no cabeçalho Referer) para o Tailwind/Google Fonts.
header('Referrer-Policy: no-referrer');
include __DIR__ . '/includes/header.php';
?>
   <section class="py-16 px-4 bg-white min-h-[70vh]">
    <div class="max-w-md mx-auto">
     <h1 class="text-3xl font-bold text-gray-900 mb-2">Redefinir senha</h1>

     <?php if ($sucesso): ?>
      <div class="border border-green-200 bg-green-50 rounded-lg p-6">
       <p class="font-semibold text-green-800 mb-2">✅ Senha alterada!</p>
       <p class="text-sm text-gray-700 mb-4">Agora é só entrar com sua matrícula e a senha nova.</p>
       <a href="acesso.php" class="inline-block px-5 py-2.5 bg-green-700 text-white rounded-md font-semibold hover:bg-green-800 transition-colors">Ir para o login</a>
      </div>

     <?php elseif (!$pedido): ?>
      <div class="border border-red-200 bg-red-50 rounded-lg p-6">
       <p class="font-semibold text-red-800 mb-2"><?= $erro !== '' ? e($erro) : 'Este link não é válido ou já expirou.' ?></p>
       <p class="text-sm text-gray-700 mb-4">Cada link vale por 30 minutos e só pode ser usado uma vez. Peça um novo na tela de login.</p>
       <a href="acesso.php" class="inline-block px-5 py-2.5 bg-green-700 text-white rounded-md font-semibold hover:bg-green-800 transition-colors">Pedir um novo link</a>
      </div>

     <?php else: ?>
      <p class="text-gray-600 mb-6">Olá, <?= e($pedido['usua_nome']) ?>. Escolha uma senha nova para sua conta.</p>
      <?php if ($erro !== ''): ?>
       <div class="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700 font-semibold"><?= e($erro) ?></div>
      <?php endif; ?>
      <form method="post" action="redefinir-senha.php" class="border border-gray-200 rounded-lg p-6 space-y-4">
       <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
       <input type="hidden" name="token" value="<?= e($token) ?>">
       <div>
        <label for="senha" class="block text-xs font-semibold text-gray-700 mb-1">Nova senha</label>
        <input id="senha" name="senha" type="password" required minlength="<?= SENHA_MIN_CARACTERES ?>" autocomplete="new-password" class="w-full px-3 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
        <span class="block text-xs text-gray-500 mt-1">Pelo menos <?= SENHA_MIN_CARACTERES ?> caracteres.</span>
       </div>
       <div>
        <label for="senha_confirmar" class="block text-xs font-semibold text-gray-700 mb-1">Confirme a nova senha</label>
        <input id="senha_confirmar" name="senha_confirmar" type="password" required minlength="<?= SENHA_MIN_CARACTERES ?>" autocomplete="new-password" class="w-full px-3 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
       </div>
       <button type="submit" class="w-full px-4 py-2.5 bg-green-700 text-white rounded-md font-semibold hover:bg-green-800 transition-colors">Salvar senha nova</button>
      </form>
     <?php endif; ?>
    </div>
   </section>
<?php
include __DIR__ . '/includes/footer.php';
