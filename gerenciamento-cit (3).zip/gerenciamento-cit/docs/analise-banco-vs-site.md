# Verificação do banco de dados x páginas do site (25/09/2026)

Conferência página por página do site (`index.php`, `login.php`, `acesso.php`,
`logout.php`, `acessibilidade.php`) contra o modelo de banco de dados
(tabelas `usuario`, `agendamento`, `alocacao`, `equipamento`, `mensagem`).

## Resultado

Todos os campos preenchidos em formulários do site têm uma coluna
correspondente em alguma das 5 tabelas. Nenhuma tabela ou campo essencial
estava faltando.

## Ponto de atenção encontrado: matrícula

- O documento de requisitos descreve o login como "Matrícula e Senha".
- O banco de dados modelado tem `usuario_matricula VARCHAR(60) UNIQUE NOT NULL`.
- **Mas nenhum formulário do site real pedia matrícula**: nem o cadastro
  feito pelo admin (`novo-usuario-nome` em `includes/main-content.php`),
  nem o autocadastro do aluno/servidor (`cadastro-servidor-form` em
  `acesso.php`), nem o login do aluno/servidor (`login-usuario-form`, que
  usava nome + senha).
- O login do administrador (`login.php`) é à parte: usa um usuário fixo
  definido em `config.php` (`ADMIN_USERNAME` / `ADMIN_PASSWORD_HASH`), não
  passa pela tabela `usuario` — isso é esperado, já que agora ele é
  representado como `usuario_papel = 'admin'` no modelo, mas o código atual
  ainda não usa o banco para autenticar ninguém (tudo roda em localStorage
  no navegador, via `assets/js/script.js`).

## Decisão

Adicionar o campo **matrícula** aos formulários de cadastro (admin e
autocadastro) e trocar o login do aluno/servidor de "nome + senha" para
"matrícula + senha", para alinhar o site com o documento de requisitos e
com o banco de dados já modelado. Implementado em 25/09/2026:

- `includes/main-content.php`: campo de matrícula no card "Cadastrar
  usuário autorizado".
- `acesso.php`: campo de matrícula no formulário de solicitação de
  cadastro e no formulário de login (substituindo o campo de nome).
- `assets/js/script.js`: `cadastrarUsuarioAutorizado()`,
  `handleSolicitarCadastro()` e `handleLoginUsuario()` passaram a
  ler/gravar/validar a matrícula (unicidade verificada pela matrícula, não
  mais pelo nome); listas administrativas (`renderUsuariosAutorizadosList`,
  `renderCadastrosPendentes`) passaram a exibir a matrícula ao lado do
  nome.

## Próximo passo em aberto

Avaliar se vale separar login e pré-cadastro do aluno/servidor em páginas
próprias (hoje ambos ficam em abas dentro de `acesso.php`) — discutir com
o Cassio antes de mexer, para não duplicar o que já existe.

## Atualização (28/09/2026)

O ponto acima sobre o login do administrador foi resolvido: `login.php`
agora também pede **matrícula** em vez de "usuário" genérico, usando as
novas constantes `ADMIN_MATRICULA`/`ADMIN_NOME` em `config/config.php`
(que também mudou de lugar — antes `config.php` na raiz, agora dentro de
`config/`). Continua validando contra essas constantes, não contra a
tabela `usuario` — isso só muda quando `config/database.php` for
ativado (ver README.md).
