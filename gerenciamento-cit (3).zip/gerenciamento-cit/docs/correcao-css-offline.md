# Correção de CSS para conexão lenta

- `assets/css/tailwind-local.css`: CSS compilado e armazenado no próprio projeto; não requer acesso ao CDN.
- `includes/header.php`: carrega o Tailwind local com `assetVersion()` antes do CSS personalizado.
- `login.php`: aplica a mesma correção à tela de login.
- `assets/css/style.css`: comentário atualizado.
- Google Fonts remoto foi retirado do carregamento para não depender de conexão externa. A fonte passa a usar o fallback sans-serif do sistema; o desenho das letras pode variar ligeiramente.

O CSS local foi gerado com Tailwind v4.1.10 a partir das classes identificadas no projeto. Como a versão anterior era Tailwind CDN 3.4.17, podem existir diferenças pontuais em estilos. Valide as telas principais após publicar.

**Importante:** conexão lenta entre o visitante e o próprio servidor ainda pode atrasar o CSS; esta correção remove a dependência de servidores externos, mas não garante funcionamento offline. Chart.js e Google Tradutor ainda usam CDNs e podem falhar em conexões ruins.

Para instalar, publique os arquivos alterados, incluindo `assets/css/tailwind-local.css`, no mesmo diretório do site. Limpe o cache do navegador (Ctrl+F5) e verifique a aba Network do DevTools.
