<?php
/**
 * config/mail.php
 * ---------------------------------------------------------------------
 * Configuração de envio de e-mail (SMTP) usada pelo formulário de
 * Contato (api/records.php → criarMensagem()) para avisar a
 * coordenação do CIT por e-mail assim que alguém manda uma mensagem.
 *
 * Como preencher (usando Gmail, recomendado para este protótipo):
 *   1. Entre na conta Gmail que vai ser a "remetente" das notificações
 *      (pode ser a sua ou uma conta nova só para isso).
 *   2. Ative a verificação em duas etapas, se ainda não estiver ativa:
 *      https://myaccount.google.com/security
 *   3. Gere uma "senha de app" em
 *      https://myaccount.google.com/apppasswords
 *      (escolha "Outro (nome personalizado)", dê um nome como
 *      "Sistema CIT" e copie a senha de 16 letras gerada).
 *   4. Preencha MAIL_USERNAME com o e-mail dessa conta Gmail e
 *      MAIL_PASSWORD com a senha de app gerada (NÃO é a senha normal
 *      da conta Gmail).
 *
 * Enquanto MAIL_USERNAME/MAIL_PASSWORD estiverem com os valores de
 * exemplo abaixo, o envio de e-mail fica desativado automaticamente
 * (mandarEmailContato() simplesmente não faz nada) — a mensagem
 * continua sendo salva no banco normalmente, só o e-mail de aviso que
 * não sai. Não precisa comentar/descomentar nada.
 * ---------------------------------------------------------------------
 */

define('MAIL_SMTP_HOST', 'smtp.gmail.com');
define('MAIL_SMTP_PORT', 587);
define('MAIL_USERNAME', 'cassiosouzasilva86@gmail.com');      // troque pelo e-mail Gmail remetente
define('MAIL_PASSWORD', 'zlbvhacirtfcpvuy');    // troque pela senha de app de 16 letras
define('MAIL_FROM_NAME', 'Sistema de Agendamento CIT');

// Para quem vai a notificação quando alguém preenche o formulário de
// Contato. Por padrão usa o mesmo e-mail mostrado na página (ver
// config/config.php → CONTACT_EMAIL); troque aqui se quiser mandar
// para outro endereço.
define('MAIL_NOTIFICACAO_PARA', 'cassiosouzasilva86@gmail.com');
