<?php
/**
 * config/rate-limit.php
 * ---------------------------------------------------------------------
 * Limite de requisições por IP (proteção contra abuso: robô martelando a
 * API, spam no formulário de Contato/autocadastro, força bruta de senha).
 *
 * Contador de "janela fixa" por IP e por "balde" (ex.: 'api' = toda a
 * API, 'login' = tentativas de login), guardado em arquivo na pasta
 * temporária do sistema — sem tabela nova no banco, nada para manter.
 * Cada arquivo é travado com flock() durante a leitura+gravação, para
 * duas requisições simultâneas do mesmo IP não contarem errado.
 *
 * O IP vem só de REMOTE_ADDR: cabeçalhos como X-Forwarded-For são
 * escolhidos por quem faz a requisição e serviriam para burlar o limite.
 * ---------------------------------------------------------------------
 */

/** Pasta dos contadores (criada na primeira vez). */
function pastaRateLimit(): string
{
    $pasta = rtrim(sys_get_temp_dir(), '/\\') . DIRECTORY_SEPARATOR . 'agendacit-rate-limit';
    if (!is_dir($pasta)) {
        @mkdir($pasta, 0700, true);
    }
    return $pasta;
}

/**
 * Conta mais uma requisição deste IP no balde e devolve quantos segundos
 * faltam para liberar, se o limite estourou — ou 0 se ainda pode.
 * Em caso de falha ao ler/gravar o contador, libera (não derruba o site
 * por um problema na pasta temporária).
 */
function registrarRequisicao(string $balde, int $maximo, int $janelaSegundos): int
{
    $ip = (string) ($_SERVER['REMOTE_ADDR'] ?? 'desconhecido');
    $arquivo = pastaRateLimit() . DIRECTORY_SEPARATOR . $balde . '-' . hash('sha256', $ip) . '.json';

    $fp = @fopen($arquivo, 'c+');
    if (!$fp) {
        return 0;
    }
    try {
        if (!flock($fp, LOCK_EX)) {
            return 0;
        }
        $agora = time();
        $dados = json_decode((string) stream_get_contents($fp), true);
        if (!is_array($dados) || $agora - (int) ($dados['inicio'] ?? 0) >= $janelaSegundos) {
            $dados = ['inicio' => $agora, 'contador' => 0];
        }
        $dados['contador']++;

        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($dados));
        fflush($fp);

        return $dados['contador'] > $maximo ? max(1, $janelaSegundos - ($agora - $dados['inicio'])) : 0;
    } finally {
        flock($fp, LOCK_UN);
        fclose($fp);
        // Faxina de vez em quando: contadores parados há mais de 1 hora.
        if (random_int(1, 200) === 1) {
            foreach (glob(pastaRateLimit() . DIRECTORY_SEPARATOR . '*.json') ?: [] as $antigo) {
                if (filemtime($antigo) < time() - 3600) {
                    @unlink($antigo);
                }
            }
        }
    }
}

/** Texto amigável de espera ("40 segundos", "3 minutos"). */
function tempoDeEspera(int $segundos): string
{
    if ($segundos < 60) {
        return $segundos . ' segundo' . ($segundos !== 1 ? 's' : '');
    }
    $minutos = (int) ceil($segundos / 60);
    return $minutos . ' minuto' . ($minutos !== 1 ? 's' : '');
}
