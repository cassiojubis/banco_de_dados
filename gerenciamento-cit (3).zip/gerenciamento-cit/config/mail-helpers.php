<?php
/**
 * config/mail-helpers.php
 * ---------------------------------------------------------------------
 * Funções de envio de e-mail do sistema: aviso de nova mensagem de
 * Contato (para a coordenação) e avisos para o aluno/servidor quando o
 * cadastro ou um agendamento é aprovado/recusado. Usa a biblioteca
 * PHPMailer (vendor/phpmailer/), com as credenciais SMTP de
 * config/mail.php.
 *
 * Nenhuma função daqui lança exceção para quem chamou — se o envio
 * falhar (SMTP não configurado, senha errada, sem internet...), só
 * registra no log de erros do PHP. A ação principal (salvar a mensagem,
 * aprovar/recusar) já foi gravada no banco de qualquer forma, então
 * falha de e-mail não deve travar o site nem mostrar erro na tela.
 *
 * Enquanto config/mail.php ainda estiver com as credenciais de exemplo
 * (MAIL_USERNAME = 'seu-email@gmail.com'), o envio é pulado em
 * silêncio — assim o site funciona mesmo antes de alguém configurar o
 * e-mail de verdade.
 * ---------------------------------------------------------------------
 */

// config/mail.php (com a senha real) fica fora do git; quem acabou de
// clonar o projeto só tem o modelo — nesse caso o envio fica desativado
// em vez de o site inteiro quebrar por arquivo faltando.
require_once is_file(__DIR__ . '/mail.php') ? __DIR__ . '/mail.php' : __DIR__ . '/mail.example.php';
require_once __DIR__ . '/../vendor/phpmailer/src/Exception.php';
require_once __DIR__ . '/../vendor/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/../vendor/phpmailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * Envia um e-mail de texto simples. Devolve true se o SMTP aceitou a
 * mensagem, false se o e-mail não está configurado ou se o envio falhou.
 */
function enviarEmail(string $para, string $assunto, string $corpo, ?string $responderPara = null, ?string $responderNome = null): bool
{
    if (MAIL_USERNAME === 'cassiosouzasilva86@gmail.com' || MAIL_PASSWORD === '301200@Ca') {
        return false; // e-mail ainda não configurado — ver config/mail.php
    }
    if (!filter_var($para, FILTER_VALIDATE_EMAIL)) {
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = MAIL_SMTP_HOST;
        $mail->Port       = MAIL_SMTP_PORT;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USERNAME;
        $mail->Password   = MAIL_PASSWORD;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->CharSet    = 'UTF-8';
        // Sem isso, uma rede lenta ou um firewall que derruba a conexão
        // em silêncio (em vez de recusar na hora) prende a requisição
        // inteira — e quem clicou no site fica esperando a página
        // "carregando" por minutos. 10s é de sobra para um SMTP que está
        // respondendo normalmente.
        $mail->Timeout    = 10;
        $mail->SMTPKeepAlive = false;

        $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
        $mail->addAddress($para);
        if ($responderPara !== null && filter_var($responderPara, FILTER_VALIDATE_EMAIL)) {
            $mail->addReplyTo($responderPara, $responderNome ?? '');
        }

        $mail->Subject = $assunto;
        $mail->isHTML(false);
        $mail->Body = $corpo;

        $mail->send();
        return true;
    } catch (PHPMailerException $e) {
        error_log('[agendacit] Falha ao enviar e-mail ("' . $assunto . '"): ' . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Avisa a coordenação do CIT que alguém preencheu o formulário de
 * Contato. "Responder" no e-mail recebido responde direto para quem
 * mandou a mensagem.
 */
function enviarEmailContato(string $nomeRemetente, string $emailRemetente, string $mensagem): void
{
    enviarEmail(
        MAIL_NOTIFICACAO_PARA,
        'Nova mensagem de contato — ' . SITE_TITLE,
        "Nova mensagem recebida pelo formulário de Contato do site:\n\n"
            . "Nome: {$nomeRemetente}\n"
            . "E-mail: {$emailRemetente}\n\n"
            . "Mensagem:\n{$mensagem}\n\n"
            . "---\n"
            . "Para responder, entre no painel administrativo do sistema ou responda direto este e-mail.",
        $emailRemetente,
        $nomeRemetente
    );
}

/**
 * Avisa o aluno/servidor que um agendamento dele foi aprovado ou
 * recusado (com o motivo, quando recusado). $agendamento é a linha da
 * tabela agendamento (já com o status novo).
 */
function enviarEmailStatusAgendamento(string $emailPara, string $nome, array $agendamento): void
{
    $data   = date('d/m/Y', strtotime($agendamento['agen_data']));
    $inicio = substr((string) $agendamento['agen_hora_inicio'], 0, 5);
    $fim    = substr((string) $agendamento['agen_hora_fim'], 0, 5);
    $quando = "{$data}, das {$inicio} às {$fim}";

    if ($agendamento['agen_status'] === 'approved') {
        $assunto = "Agendamento aprovado — {$data}";
        $texto = "Seu agendamento da sala do CIT foi APROVADO.\n\n"
            . "Quando: {$quando}\n"
            . "Finalidade: {$agendamento['agen_finalidade']}\n";
    } else {
        $assunto = "Agendamento recusado — {$data}";
        $texto = "Seu agendamento da sala do CIT foi RECUSADO.\n\n"
            . "Quando: {$quando}\n"
            . "Finalidade: {$agendamento['agen_finalidade']}\n"
            . "Motivo: {$agendamento['agen_motivo_recusa']}\n\n"
            . "Você pode solicitar um novo horário pelo site.\n";
    }

    enviarEmail(
        $emailPara,
        $assunto . ' — ' . SITE_TITLE,
        "Olá, {$nome}!\n\n{$texto}\n"
            . "Acompanhe em \"Meus agendamentos\", na página Login / Cadastro do site.\n\n"
            . "---\n" . SITE_TITLE . ' · ' . INSTITUTION_NAME . "\n"
            . "Este é um aviso automático; em caso de dúvida, escreva para " . CONTACT_EMAIL . '.',
        CONTACT_EMAIL
    );
}

/**
 * Avisa o aluno/servidor que o pedido de cadastro foi aceito ou
 * recusado (com o motivo, quando recusado).
 */
function enviarEmailStatusCadastro(string $emailPara, string $nome, bool $aprovado, ?string $motivo = null): void
{
    $texto = $aprovado
        ? "Seu cadastro no " . SITE_TITLE . " foi ACEITO. Você já pode entrar com sua matrícula e senha e agendar a sala do CIT.\n"
        : "Seu pedido de cadastro no " . SITE_TITLE . " foi RECUSADO.\n\nMotivo: {$motivo}\n\n"
            . "Se achar que foi um engano, você pode enviar uma nova solicitação pelo site ou falar com a coordenação.\n";

    enviarEmail(
        $emailPara,
        ($aprovado ? 'Cadastro aceito' : 'Cadastro recusado') . ' — ' . SITE_TITLE,
        "Olá, {$nome}!\n\n{$texto}\n"
            . "---\n" . SITE_TITLE . ' · ' . INSTITUTION_NAME . "\n"
            . "Este é um aviso automático; em caso de dúvida, escreva para " . CONTACT_EMAIL . '.',
        CONTACT_EMAIL
    );
}

/**
 * Envia o link de "Esqueci minha senha". O link leva o código em texto
 * puro (só quem recebeu o e-mail tem); o banco guarda apenas o hash.
 * Devolve true se o SMTP aceitou a mensagem.
 */
function enviarEmailRecuperacaoSenha(string $emailPara, string $nome, string $link, int $minutosValidade): bool
{
    return enviarEmail(
        $emailPara,
        'Redefinir sua senha — ' . SITE_TITLE,
        "Olá, {$nome}!\n\n"
            . "Recebemos um pedido para redefinir a senha da sua conta no " . SITE_TITLE . ".\n\n"
            . "Para criar uma senha nova, abra o link abaixo:\n{$link}\n\n"
            . "O link vale por {$minutosValidade} minutos e só pode ser usado uma vez.\n\n"
            . "Se não foi você que pediu, ignore este e-mail — sua senha continua a mesma.\n\n"
            . "---\n" . SITE_TITLE . ' · ' . INSTITUTION_NAME . "\n"
            . "Este é um aviso automático; em caso de dúvida, escreva para " . CONTACT_EMAIL . '.',
        CONTACT_EMAIL
    );
}

/**
 * Avisa a coordenação que um aluno/servidor cancelou o próprio
 * agendamento, com o motivo. Se o agendamento já estava aprovado, a
 * sala volta a ficar livre naquele horário.
 */
function enviarEmailCancelamento(string $nome, string $quando, string $finalidade, string $motivo, bool $estavaAprovado): void
{
    enviarEmail(
        MAIL_NOTIFICACAO_PARA,
        "Agendamento cancelado — {$quando} — " . SITE_TITLE,
        "{$nome} cancelou um agendamento " . ($estavaAprovado ? 'que já estava APROVADO' : 'que estava pendente') . ".\n\n"
            . "Quando: {$quando}\n"
            . "Finalidade: {$finalidade}\n"
            . "Motivo informado: {$motivo}\n\n"
            . ($estavaAprovado ? "A sala e os equipamentos desse horário voltaram a ficar livres.\n\n" : '')
            . "---\n" . SITE_TITLE . ' · ' . INSTITUTION_NAME . "\nAviso automático."
    );
}
