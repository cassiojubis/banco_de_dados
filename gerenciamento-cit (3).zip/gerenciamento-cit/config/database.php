<?php
/**
 * config/database.php
 * ---------------------------------------------------------------------
 * Conexão com o banco MySQL (agendacit) via PDO.
 *
 * ATIVA. O site agora fala com o banco de verdade — não usa mais
 * localStorage para agendamentos, equipamentos, cadastros de
 * aluno/servidor nem mensagens de contato (ver api/records.php e
 * assets/js/script.js).
 *
 * O esquema das tabelas está em database/schema.sql (5 tabelas:
 * usuario, equipamento, agendamento, alocacao, mensagem — já inclui o
 * usuário administrador inicial). Rode esse arquivo no MySQL
 * Workbench/phpMyAdmin do XAMPP antes de abrir o site.
 *
 * As credenciais abaixo são as do XAMPP desta máquina: root, sem senha,
 * porta 3307 (o padrão do XAMPP é 3306, mas aqui o my.ini do XAMPP usa
 * 3307 porque a 3306 está ocupada por outro MySQL instalado como serviço
 * do Windows). Se o seu MySQL usa outro usuário/senha/porta, ajuste as
 * constantes abaixo.
 * ---------------------------------------------------------------------
 */

// 127.0.0.1 (e não "localhost"): o MySQL do XAMPP só escuta em
// 127.0.0.1 (bind-address no my.ini), e no Windows "localhost" pode
// virar o endereço IPv6 ::1, que ele recusaria.
// Variáveis de ambiente (DB_HOST, DB_PORT...) têm prioridade — é assim
// que o Docker (docker-compose.yml) aponta para o banco dele. Sem elas,
// valem os valores do XAMPP desta máquina.
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3307');
define('DB_NAME', getenv('DB_NAME') ?: 'agendacit');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') !== false ? getenv('DB_PASS') : '');

/**
 * Abre (ou reaproveita) a conexão PDO com o banco agendacit. Devolve
 * null se a conexão falhar (banco fora do ar, schema.sql não rodado,
 * credenciais erradas) — quem chamar deve checar isso e responder com
 * um erro amigável em vez de deixar a exceção estourar pro usuário.
 */
function getPDO(): ?PDO
{
    static $pdo = null;

    if ($pdo instanceof PDO) {
        return $pdo;
    }

    try {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        return $pdo;
    } catch (PDOException $e) {
        // Em produção, registre $e->getMessage() em log — nunca exiba
        // a mensagem de erro do banco diretamente para o usuário.
        error_log('[agendacit] Falha ao conectar no banco: ' . $e->getMessage());
        return null;
    }
}
