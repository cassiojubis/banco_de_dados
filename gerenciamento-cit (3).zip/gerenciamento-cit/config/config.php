<?php
/**
 * config/config.php
 * ---------------------------------------------------------------------
 * Configuração central do Sistema de Agendamento CIT.
 *
 * Responsabilidades deste arquivo:
 *   1. Iniciar a sessão PHP com opções de segurança básicas.
 *   2. Definir constantes de configuração do site (nome, contatos).
 *   3. Definir as credenciais do administrador (login único, protótipo).
 *   4. Fornecer funções auxiliares de autenticação usadas por todas as
 *      páginas restritas (isAuthenticated, requireLogin) e de apoio
 *      (e(), csrfToken(), csrfValidate()).
 *
 * Este arquivo deve ser incluído no topo de TODA página do sistema,
 * antes de qualquer saída HTML, pois configura a sessão e pode
 * redirecionar (header()) quando o acesso não é autorizado.
 *
 * Este arquivo vive em config/, mas as páginas (index.php, login.php
 * etc.) continuam na raiz do projeto — é para lá que os links do menu
 * apontam e é onde o Apache serve o site (localhost/gerenciamento-cit/).
 * PROJECT_ROOT abaixo é o que permite esse arquivo, mesmo estando uma
 * pasta mais fundo, continuar encontrando assets/ e outras pastas a
 * partir da raiz do projeto.
 * ---------------------------------------------------------------------
 */

// Raiz do projeto (uma pasta acima de config/), usada para localizar
// assets/, database/ etc. a partir daqui, independente de este arquivo
// estar em config/.
define('PROJECT_ROOT', dirname(__DIR__));

// ------------------------------------------------------------------
// 0. Erros: nunca mostrar detalhes técnicos (mensagem do PHP, consulta
//    SQL, caminho no servidor) na tela de quem está usando o site — só
//    no log de erros do servidor, que só a administração acessa. Sem
//    isso, um erro inesperado (ex.: duas pessoas cadastrando a mesma
//    matrícula no mesmíssimo instante) pode aparecer como uma tela
//    branca cheia de detalhes internos em vez de uma mensagem normal.
//    display_errors do php.ini do XAMPP vem ligado por padrão — por
//    isso é preciso desligar aqui, e não só confiar na configuração do
//    servidor.
// ------------------------------------------------------------------
// Fuso horário do CIT (Rondônia, UTC-4). Sem isso o PHP usa o fuso do
// php.ini do XAMPP (aqui, Europa/+02:00): a checagem de "data que já
// passou" em api/records.php recusava agendamentos para hoje a partir
// do fim da tarde, e a data dos e-mails saía errada.
date_default_timezone_set('America/Porto_Velho');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

// ------------------------------------------------------------------
// 1. Sessão: configurações de segurança aplicadas antes de iniciar
// ------------------------------------------------------------------
if (session_status() === PHP_SESSION_NONE) {
    // Impede acesso ao cookie de sessão via JavaScript (mitiga XSS)
    ini_set('session.cookie_httponly', '1');
    // Cookie de sessão só é reenviado em requisições de mesmo site (mitiga CSRF)
    ini_set('session.cookie_samesite', 'Lax');
    // Em produção com HTTPS, habilite a linha abaixo:
    // ini_set('session.cookie_secure', '1');

    session_start();
}

// ------------------------------------------------------------------
// 1b. Sessão expira após 5 minutos sem atividade (admin e
//     aluno/servidor). Cada requisição ao servidor conta como
//     atividade; enquanto a pessoa mexe na página sem gerar requisição
//     (lendo, preenchendo um formulário), o script.js manda um "ping"
//     (api/sessao.php) no máximo a cada minuto. Se passar do limite, o
//     login é desfeito aqui mesmo, antes de qualquer página ou endpoint
//     da API conferir isAuthenticated()/usuarioLogadoId().
// ------------------------------------------------------------------
define('SESSAO_INATIVIDADE_SEGUNDOS', 5 * 60);

$algumLoginAtivo = !empty($_SESSION['admin_logged_in']) || isset($_SESSION['usuario_id']);
if ($algumLoginAtivo && isset($_SESSION['ultima_atividade'])
    && time() - $_SESSION['ultima_atividade'] > SESSAO_INATIVIDADE_SEGUNDOS) {
    unset(
        $_SESSION['admin_logged_in'], $_SESSION['admin_usuario'], $_SESSION['admin_matricula'],
        $_SESSION['admin_id'], $_SESSION['usuario_id']
    );
    // Para login.php / api/login_usuario.php avisarem por que a pessoa
    // precisa entrar de novo (apagado assim que a mensagem é mostrada).
    $_SESSION['sessao_expirada'] = true;
}
// As consultas automáticas de novidades do script.js (a cada 15 s, ver
// verificarNovidades()) mandam este cabeçalho e NÃO contam como
// atividade — senão a página aberta manteria a sessão viva para sempre
// e o limite de inatividade nunca valeria. (Elas ainda caem na checagem
// acima: se o tempo já passou, o login é desfeito do mesmo jeito.)
if (empty($_SERVER['HTTP_X_ATUALIZACAO_AUTOMATICA'])) {
    $_SESSION['ultima_atividade'] = time();
}
unset($algumLoginAtivo);

// ------------------------------------------------------------------
// 2. Configurações gerais exibidas na interface
// ------------------------------------------------------------------
define('SITE_TITLE', 'Sistema de Agendamento CIT');
// Mesmos valores usados como fallback em assets/js/script.js (defaultConfig),
// para que o HTML gerado pelo PHP já nasça idêntico ao que o JS aplicaria.
define('INSTITUTION_NAME', 'Instituto Federal de Rondônia');
define('CONTACT_EMAIL', 'cit@ifro.edu.br');
define('CONTACT_PHONE', '(69) 3211-0000');

// Endereço do site, usado para montar o link de "Esqueci minha senha"
// no e-mail. É fixo aqui (e não montado a partir do endereço da
// requisição) de propósito: senão alguém poderia pedir a recuperação
// da senha de outra pessoa forjando o cabeçalho Host, e o e-mail dela
// chegaria com um link para um site falso. AO SERVIR O SITE NA REDE
// (outro computador acessando pelo IP), troque pelo endereço usado,
// ex.: 'http://192.168.0.10/gerenciamento-cit'.
define('SITE_URL', getenv('SITE_URL') ?: 'http://192.168.0.155/gerenciamento-cit'); // no Docker: variável SITE_URL
define('IP_SERVER','192.168.0.155');
// Horário de funcionamento da sala do CIT — fonte única: vale para a
// validação da API (api/records.php), para o calendário e o formulário
// (repassado ao script.js via window.SERVER_CONFIG) e para o texto do
// rodapé. Segunda a sexta: aberto a todos. Sábado: só o administrador
// agenda (eventos e atividades combinados antes). Domingo: fechado.
define('HORARIO_ABERTURA', '08:00');
define('HORARIO_FECHAMENTO', '22:00');

/**
 * Se a sala pode ser agendada na data informada (AAAA-MM-DD). Domingo
 * nunca; sábado só pelo administrador; segunda a sexta, sempre.
 */
function diaDeFuncionamento(string $data, bool $admin): bool
{
    $diaSemana = (int) date('w', strtotime($data)); // 0 = domingo, 6 = sábado
    if ($diaSemana === 0) {
        return false;
    }
    if ($diaSemana === 6) {
        return $admin;
    }
    return true;
}

// ------------------------------------------------------------------
// 3. Credenciais do administrador
// ------------------------------------------------------------------
// O login pede MATRÍCULA e valida contra a tabela `usuario` do banco
// real (usua_papel = 'admin'), via password_verify() — ver login.php e
// config/database.php. O administrador inicial (matrícula "admin",
// senha "cit@2025") já vem cadastrado pelo INSERT em
// database/schema.sql; troque a senha pela tela de administração ou
// direto no banco depois do primeiro acesso.

// ------------------------------------------------------------------
// 4. Funções auxiliares
// ------------------------------------------------------------------

/**
 * Escapa uma string para saída segura em HTML (evita XSS).
 */
function e(string $valor): string
{
    return htmlspecialchars($valor, ENT_QUOTES, 'UTF-8');
}

/**
 * Verifica se existe uma sessão de administrador autenticada.
 */
function isAuthenticated(): bool
{
    return !empty($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

/**
 * Bloqueia o acesso à página atual caso não haja administrador logado,
 * redirecionando para a tela de login. Deve ser chamada logo após
 * incluir este arquivo, no topo de toda página restrita.
 */
function requireLogin(string $paginaLogin = 'login.php'): void
{
    if (!isAuthenticated()) {
        // Páginas fora da raiz (ex.: api/exportar-pdf.php) passam
        // '../login.php' — o caminho é relativo à página atual.
        header('Location: ' . $paginaLogin);
        exit;
    }
}

/**
 * Gera (ou reaproveita) um token CSRF para o formulário de login,
 * guardado na sessão do usuário.
 */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Valida um token CSRF recebido de um formulário contra o valor
 * guardado na sessão, usando comparação resistente a timing attacks.
 */
function csrfValidate(?string $tokenRecebido): bool
{
    return is_string($tokenRecebido)
        && !empty($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $tokenRecebido);
}

// ------------------------------------------------------------------
// 5. Limite de tentativas de login (mitiga força bruta na senha). O
//    contador e o bloqueio ficam na própria sessão PHP — simples e
//    suficiente para um protótipo. O parâmetro $tipo separa o contador
//    do login do administrador ('admin', login.php) do login de
//    aluno/servidor ('usuario', api/login_usuario.php), para que errar
//    a senha em um não bloqueie o outro.
// ------------------------------------------------------------------

define('LOGIN_MAX_TENTATIVAS', 5);
define('LOGIN_BLOQUEIO_SEGUNDOS', 60);

/**
 * Verifica se o login está temporariamente bloqueado por excesso de
 * tentativas incorretas. Se o tempo de bloqueio já passou, libera de
 * volta automaticamente.
 */
function loginBloqueado(string $tipo = 'admin'): bool
{
    $chave = "login_{$tipo}_bloqueado_ate";
    if (empty($_SESSION[$chave])) {
        return false;
    }
    if (time() >= $_SESSION[$chave]) {
        limparTentativasLogin($tipo);
        return false;
    }
    return true;
}

/**
 * Quantos segundos faltam até o login ser liberado de novo.
 */
function loginSegundosRestantes(string $tipo = 'admin'): int
{
    return max(0, ($_SESSION["login_{$tipo}_bloqueado_ate"] ?? time()) - time());
}

/**
 * Registra uma tentativa de login incorreta. Ao atingir o limite,
 * bloqueia novas tentativas por LOGIN_BLOQUEIO_SEGUNDOS.
 */
function registrarTentativaFalha(string $tipo = 'admin'): void
{
    $chave = "login_{$tipo}_tentativas";
    $_SESSION[$chave] = ($_SESSION[$chave] ?? 0) + 1;
    if ($_SESSION[$chave] >= LOGIN_MAX_TENTATIVAS) {
        $_SESSION["login_{$tipo}_bloqueado_ate"] = time() + LOGIN_BLOQUEIO_SEGUNDOS;
    }
}

/**
 * Limpa o contador de tentativas após um login bem-sucedido.
 */
function limparTentativasLogin(string $tipo = 'admin'): void
{
    unset($_SESSION["login_{$tipo}_tentativas"], $_SESSION["login_{$tipo}_bloqueado_ate"]);
}

// ------------------------------------------------------------------
// 6. Sessão do aluno/servidor (login feito em api/login_usuario.php).
//    Antes o navegador só guardava a matrícula no localStorage e a API
//    acreditava em qualquer matrícula enviada — bastava saber a
//    matrícula de alguém para agendar ou cancelar no nome dessa pessoa.
//    Agora quem está logado fica registrado na sessão PHP (no
//    servidor), do mesmo jeito que o administrador.
// ------------------------------------------------------------------

/** Tamanho mínimo de senha no cadastro/redefinição de aluno/servidor. */
define('SENHA_MIN_CARACTERES', 6);

/**
 * usua_id do aluno/servidor logado nesta sessão, ou null se ninguém
 * estiver logado.
 */
function usuarioLogadoId(): ?int
{
    return isset($_SESSION['usuario_id']) ? (int) $_SESSION['usuario_id'] : null;
}

/**
 * Desenha um ícone do arquivo assets/img/icones.svg. Ex.:
 *   <?= icone('calendario', 'w-6 h-6 text-green-600') ?>
 * A cor vem do texto em volta (text-green-600 etc.), e os nomes
 * disponíveis são os id="..." dos <symbol> daquele arquivo.
 */
function icone(string $nome, string $classes = 'w-6 h-6'): string
{
    return '<svg class="' . e($classes) . '" aria-hidden="true" focusable="false">'
        . '<use href="' . e(assetVersion('assets/img/icones.svg')) . '#' . e($nome) . '"></use></svg>';
}

/**
 * Adiciona "?v=<data de modificação>" ao final do caminho de um arquivo
 * CSS/JS, para que o navegador baixe a versão nova assim que o arquivo
 * muda, em vez de continuar usando uma cópia antiga guardada em cache.
 * Caso o arquivo não seja encontrado, devolve o caminho sem alterações.
 */
function assetVersion(string $caminhoRelativoAoProjeto): string
{
    // PROJECT_ROOT (não __DIR__): este arquivo fica em config/, mas o
    // caminho recebido (ex.: "assets/css/style.css") é relativo à raiz
    // do projeto, que é onde as páginas realmente ficam.
    $caminhoAbsoluto = PROJECT_ROOT . '/' . ltrim($caminhoRelativoAoProjeto, '/');
    $versao = is_file($caminhoAbsoluto) ? filemtime($caminhoAbsoluto) : time();
    return $caminhoRelativoAoProjeto . '?v=' . $versao;
}
