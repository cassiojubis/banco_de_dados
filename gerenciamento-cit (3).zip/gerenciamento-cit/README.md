# Sistema de Agendamento CIT — versão PHP + MySQL

Conversão do protótipo estático (HTML/CSS/JS) para uma aplicação PHP completa:
autenticação de administrador por sessão, um banco de dados MySQL de verdade
e uma API própria em PHP. Agendamentos, equipamentos, cadastros de
aluno/servidor e mensagens de contato são gravados e lidos do banco — nada
mais fica só no `localStorage` do navegador (que hoje só guarda duas coisas
pequenas: preferências de acessibilidade e a sessão do aluno/servidor logado
naquele navegador).

## Como rodar localmente

Requer PHP 7.4+ (testado em PHP 8.3/8.4) com a extensão `pdo_mysql`, e um
MySQL/MariaDB rodando (o XAMPP já traz os dois — no Windows, o "MySQL" do
XAMPP é na prática o MariaDB, e o `schema.sql` já é compatível com ele).

1. Crie o banco: veja "Conectar o banco de dados" abaixo.
2. Suba o servidor PHP:

```bash
cd gerenciamento-cit
php -S localhost:8000
```

Acesse `http://localhost:8000/index.php` no navegador. A página inicial
é pública; só a seção "Administração" exige login.

Também funciona em XAMPP/WAMP: copie a pasta para `htdocs` (ou `www`) e
acesse `http://localhost/gerenciamento-cit/`.

## Conectar o banco de dados

1. Rode `database/schema.sql` no MySQL Workbench (ou phpMyAdmin do XAMPP)
   para criar o banco `agendacit` com as 5 tabelas (`usuario`, `equipamento`,
   `agendamento`, `alocacao`, `mensagem`) — o arquivo já cria um usuário
   administrador inicial (ver credenciais abaixo).
2. Confira as constantes no topo de `config/database.php`
   (`DB_HOST`/`DB_PORT`/`DB_NAME`/`DB_USER`/`DB_PASS`). Vêm com `root`, sem
   senha, porta **3307** (o padrão do XAMPP é 3306; confira a linha `port=`
   em `C:\xampp\mysql\bin\my.ini` e use o mesmo valor em `DB_PORT`). Só
   mude se o seu MySQL usa outro usuário/senha/porta.
3. Pronto — `login.php`, `acesso.php` e a API (`api/records.php`,
   `api/login_usuario.php`) já consultam o banco de verdade a partir daqui.
   Não é preciso mais nenhum passo manual.

Se o site mostrar "Não foi possível conectar ao banco de dados", confira se
o MySQL está rodando (no XAMPP, o painel de controle) e se o passo 1 foi
executado.

## Rodar com Docker (sem XAMPP)

Com o [Docker Desktop](https://www.docker.com/products/docker-desktop/)
instalado, na pasta do projeto:

```bash
docker compose up --build
```

Na primeira vez, ele baixa as imagens, monta o PHP 8.3 + Apache com o projeto
e sobe um MySQL 8 que já roda o `database/schema.sql` (tabelas e administrador
inicial). Depois é só abrir **http://localhost:8000**. Entre com a matrícula
`admin` e a senha inicial `cit@2025`, e **troque essa senha**.

- `docker compose down` desliga e **mantém** os dados (volume `dados-mysql`).
- `docker compose down -v` apaga também os dados e começa do zero.
- E-mail: por padrão fica desligado no Docker (o `config/mail.php` com a senha
  não entra na imagem). Para ligar, crie o `config/mail.php` e descomente o
  `volumes:` do serviço `app` no `docker-compose.yml`.
- As senhas do banco no `docker-compose.yml` são de desenvolvimento. Para um
  servidor de verdade, defina `DB_PASS` e `MYSQL_ROOT_PASSWORD` num arquivo
  `.env` ao lado do `docker-compose.yml`, que fica fora do git.

A configuração do projeto lê o banco e o endereço do site de variáveis de
ambiente (`DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASS`, `SITE_URL`).
Sem elas, valem os valores do XAMPP, então nada muda para quem usa XAMPP.

## Integração contínua (GitHub Actions)

A cada `git push`, o GitHub roda `.github/workflows/ci.yml`: sobe um MySQL 8,
confere a sintaxe de todos os arquivos PHP e roda os testes PHPUnit. O
resultado aparece na aba **Actions** do repositório, e no histórico de commits
como ✅ ou ❌. Se algum teste quebrar, o build falha.

## Testes automatizados (PHPUnit)

As regras mais críticas têm testes automáticos em `tests/`: conflito de
horário (sobreposição de intervalos), disponibilidade de equipamento, matrícula
duplicada e os horários livres sugeridos. As regras ficam em
`lib/regras-agendamento.php`, separadas da API justamente para poderem ser
testadas.

O PHPUnit 11 já vem no projeto (`vendor/phpunit/phpunit.phar`, sem Composer).
Na raiz do projeto, com o MySQL do XAMPP ligado:

```bash
C:\xampp\php\php.exe vendor/phpunit/phpunit.phar           # roda tudo
C:\xampp\php\php.exe vendor/phpunit/phpunit.phar --testdox  # lista cada teste por nome
```

Os testes usam um banco **separado**, `agendacit_test`, que é apagado e
recriado a partir de `database/schema.sql` a cada execução. O banco real
(`agendacit`) nunca é tocado (o bootstrap se recusa a rodar se o nome for
esse). A conexão vem do `phpunit.xml` (padrão: `127.0.0.1:3307`, `root`, sem
senha). Para usar outro servidor, defina as variáveis de ambiente
`TEST_DB_HOST`, `TEST_DB_PORT`, `TEST_DB_NAME`, `TEST_DB_USER` e `TEST_DB_PASS`.
O usuário precisa poder criar e apagar o banco de teste.

## Configurar envio de e-mail (formulário de Contato)

Quando alguém preenche o formulário de Contato, a mensagem é sempre salva no
banco (tabela `mensagem`, visível para o administrador). Para também chegar
um e-mail avisando na hora, configure o SMTP em `config/mail.php`:

1. Entre na conta Gmail que vai enviar as notificações (pode ser a sua ou uma
   conta nova só para isso).
2. Ative a verificação em duas etapas, se ainda não estiver:
   https://myaccount.google.com/security
3. Gere uma "senha de app" em https://myaccount.google.com/apppasswords
   (escolha "Outro (nome personalizado)", dê um nome como "Sistema CIT" e
   copie a senha de 16 letras gerada).
4. Copie `config/mail.example.php` para `config/mail.php` (o `mail.php` fica
   fora do git, porque vai guardar a senha), abra-o e troque `MAIL_USERNAME` pelo e-mail dessa conta
   Gmail e `MAIL_PASSWORD` pela senha de app gerada (**não** é a senha normal
   da conta).

Enquanto esses dois valores estiverem com os textos de exemplo, o envio de
e-mail fica desativado sozinho — o formulário continua salvando as mensagens
no banco normalmente, só o e-mail de aviso que não sai. Não precisa comentar
nem descomentar nada no código.

O destinatário das notificações é `MAIL_NOTIFICACAO_PARA` (por padrão, o
mesmo `CONTACT_EMAIL` mostrado na página — troque em `config/mail.php` se
quiser mandar para outro endereço). O envio usa a biblioteca PHPMailer
(pasta `vendor/phpmailer/`, incluída no projeto).

## Credenciais de administrador

A matrícula do administrador é `admin`. Uma instalação **nova** (rodando
`database/schema.sql`) vem com a senha inicial `cit@2025` — **troque antes
de deixar outras pessoas acessarem o site**: com essa senha pública, qualquer
um entra no painel. A senha fica no banco só como hash bcrypt (tabela
`usuario`, papel `admin`); para trocar, gere um hash novo com
`password_hash()` e atualize `usua_senha_hash` dessa linha.

A senha em uso **não** é anotada neste README nem em nenhum arquivo do git.

## Estrutura de arquivos

```
index.php                  Página principal (pública; só a seção Administração exige login)
login.php                  Login do administrador (matrícula + senha, contra o banco, com proteção CSRF)
logout.php                 Encerra a sessão do administrador
acesso.php                 Login / auto-cadastro de aluno e servidor + "Meus agendamentos"
acessibilidade.php         Tamanho de fonte, modo escuro e idioma
redefinir-senha.php        Página aberta pelo link do e-mail para criar uma senha nova

config/
  config.php                Sessão, constantes do site, funções de autenticação
                             (isAuthenticated, requireLogin, csrfToken...)
  database.php               Conexão PDO com o MySQL/MariaDB (getPDO()) — ativa
  mail.php                    Credenciais SMTP para o e-mail de notificação do formulário
                             de Contato (ver "Configurar envio de e-mail" acima)
  mail-helpers.php             Função enviarEmailContato(), usada por api/records.php
  rate-limit.php               Limite de requisições por IP (contadores em arquivo temporário)

lib/
  regras-agendamento.php       Regras de negócio (conflito, horários livres, equipamento,
                             matrícula) usadas pela API e pelos testes

tests/                       Testes PHPUnit (banco agendacit_test; ver "Testes automatizados")
phpunit.xml                  Configuração do PHPUnit
Dockerfile                   Imagem PHP 8.3 + Apache do projeto
docker-compose.yml           Sobe app + MySQL 8 (ver "Rodar com Docker")
.github/workflows/ci.yml     Integração contínua: sintaxe + PHPUnit a cada push
.htaccess                    Bloqueia acesso web a arquivos internos

database/
  schema.sql                 Schema do banco `agendacit` (5 tabelas: usuario, equipamento,
                             agendamento, alocacao, mensagem) + usuário administrador inicial,
                             pronto para rodar no MySQL Workbench/XAMPP (testado em MySQL 8 e
                             MariaDB)
  legado/agendacit-original.sql  Dump original, só para consulta — NÃO rode este; use schema.sql

api/
  _bootstrap.php              Conexão, cabeçalho JSON e helpers (jsonInput, jsonResponse,
                             exigirAdmin) comuns aos dois endpoints abaixo
  records.php                  API única para equipamentos, agendamentos, cadastros de
                             aluno/servidor e mensagens de contato (GET/POST/PUT/DELETE) —
                             ao criar uma mensagem de contato, também dispara o e-mail de
                             notificação (ver config/mail.php)
  login_usuario.php             Login de aluno/servidor (POST matrícula + senha) contra a
                             tabela usuario
  recuperar_senha.php            "Esqueci minha senha": envia o link de redefinição por e-mail
  sessao.php                     Ping de atividade e encerramento por inatividade (5 min)
  exportar-pdf.php               Relatório de Uso em PDF (somente admin; ?mes= / ?data=)
  exportar-ics.php               Agendamento aprovado como arquivo .ics (admin ou dono; ?id=)
  docs.php                       Documentação interativa da API (Swagger UI; somente admin)

vendor/
  phpmailer/                  Biblioteca PHPMailer (envio de e-mail via SMTP), incluída
                             direto no projeto — sem precisar de Composer
  dompdf/                     Biblioteca dompdf 3.1.6 (geração do Relatório de Uso em PDF),
                             com as dependências — também sem Composer

includes/
  header.php                 <head>, folha de estilos e barra de navegação
  main-content.php           Todas as seções (Início, Calendário, Admin, Relatórios, Contato)
  footer.php                 Rodapé, modais, toast e carregamento do script.js

assets/
  css/style.css               Estilos complementares ao Tailwind (CDN)
  css/acessibilidade.css        Modo escuro e overrides de acessibilidade
  js/script.js                   Lógica de interface; fala com o banco via fetch() para
                             api/records.php e api/login_usuario.php
  js/acessibilidade.js            Fonte, modo escuro e idioma (assets/css/acessibilidade.css)

docs/
  analise-banco-vs-site.md    Conferência do schema do banco contra o que o site usa
  openapi.yaml                Especificação OpenAPI 3.0 da API (vista em api/docs.php)
```

## O que mudou em relação ao protótipo original

- HTML único (`index.html`) dividido em `header.php` / `main-content.php`
  / `footer.php`, incluídos por `index.php`.
- Acesso à seção "Administração" de `index.php` exige uma sessão de
  administrador válida (`requireLogin()` em `config/config.php`); sem
  login, o usuário é redirecionado para `login.php`.
- Login do administrador pede **matrícula** (antes pedia um "usuário"
  genérico), no mesmo formato usado pela tabela `usuario` do banco, e agora
  autentica contra o banco de verdade (antes eram constantes fixas em
  `config.php`).
- **Banco de dados MySQL real** (`database/schema.sql` + `config/database.php`,
  acessado via PDO com prepared statements): agendamentos, equipamentos,
  cadastros de aluno/servidor e mensagens de contato são gravados e lidos de
  lá, não mais do `localStorage` do navegador — os dados agora são os mesmos
  para todo mundo que acessa o site, de qualquer computador.
- **API própria em PHP** (`api/records.php`, `api/login_usuario.php`):
  `assets/js/script.js` fala com o banco através dela via `fetch()`. Ações
  administrativas (cadastrar/editar/remover equipamento, aprovar/recusar
  agendamento e cadastro, redefinir senha, etc.) exigem sessão de
  administrador no servidor (`exigirAdmin()`) — antes, sem conexão real com
  o banco, qualquer pessoa podia alterar os dados direto pelo DevTools do
  navegador.
- **Senhas com hash** (`password_hash()`/`password_verify()`, bcrypt) para
  administrador e para aluno/servidor — antes a senha de aluno/servidor era
  comparada em texto puro no JavaScript.
- **Recusar cadastro de aluno/servidor** agora é uma atualização (grava
  `aprovação = recusado` e o motivo informado), não mais uma exclusão —
  mantém o histórico de quem foi recusado e por quê.
- **Formulário de Contato manda e-mail de verdade** (via SMTP/PHPMailer, ver
  "Configurar envio de e-mail" acima), além de salvar a mensagem no banco —
  antes ficava só salva, sem nenhum aviso além de entrar no painel.
- Nome da instituição, e-mail e telefone de contato vêm de constantes em
  `config/config.php`, repassadas ao JavaScript via `window.SERVER_CONFIG`
  (gerado em `includes/footer.php`).
- Arquivos de configuração (`config.php`, `database.php`) organizados em
  `config/`; o schema do banco em `database/`; a API em `api/`;
  documentação solta (como a análise de schema) em `docs/` — para separar
  "o que é servido pelo Apache/acessado por URL" (arquivos na raiz) de
  "apoio interno" (config/database/api/docs).
- Comentários adicionados em todos os arquivos PHP, JS e CSS, explicando a
  função de cada bloco.
- Validação de entrada e proteção CSRF no formulário de login; validações
  de negócio (conflito de horário, quantidade de equipamento disponível,
  matrícula já cadastrada etc.) reforçadas também no servidor, não mais só
  no JavaScript.
- **Aluno/servidor pode cancelar o próprio agendamento** (pendente ou
  aprovado) direto em "Meus agendamentos" — antes só o Gestor do CIT podia
  excluir um agendamento.
- **Revisão de pré-lançamento** (2026-09-29): nome e matrícula de
  aluno/servidor não são mais devolvidos pela API para quem não está
  logado como administrador; erros técnicos internos (`display_errors`)
  nunca mais aparecem na tela de quem usa o site, só no log do servidor;
  a criação de agendamento passou a rodar dentro de uma transação com
  `SELECT ... FOR UPDATE`, evitando que duas pessoas reservem o mesmo
  horário (ou a última unidade de um equipamento) ao mesmo tempo;
  adicionado `.gitignore` para reduzir o risco de credenciais reais irem
  para o controle de versão.
- **Correções de 2026-10-05**:
  - O login de aluno/servidor agora cria uma **sessão PHP no servidor**
    (`api/login_usuario.php`). Agendar e cancelar o próprio agendamento
    usam essa sessão; antes a API confiava em qualquer matrícula enviada
    pelo navegador, e bastava saber a matrícula de alguém para agendar ou
    cancelar no nome dessa pessoa.
  - O login de aluno/servidor também passou a ser bloqueado por 60 s após 5
    senhas erradas.
  - Aluno/servidor voltou a conseguir agendar: o JavaScript procurava o
    cadastro numa lista que a API deixou de enviar para quem não é admin.
  - A disponibilidade de equipamento considera só os agendamentos
    aprovados **no mesmo dia e com horário sobreposto** (antes somava todos
    os aprovados de todas as datas, e o equipamento parecia esgotado para
    sempre). Ao aprovar, a quantidade e a situação do equipamento são
    conferidas de novo, e item em manutenção ou indisponível não pode ser
    reservado.
  - O calendário não marca mais o dia de hoje como passado (erro de fuso
    horário em UTC-4).
  - A API recusa data passada, data/hora em formato inválido, senha com
    menos de 6 caracteres e situação de equipamento fora da lista, e não
    apaga mais a conta de administrador.
  - "Meus agendamentos" filtra pelo id do usuário, não pelo nome.
  - O dump original do banco foi movido para `database/legado/`. Use
    sempre `database/schema.sql`.
- **Sugestões do orientador (2026-10-05)**:
  - **Esqueci minha senha**: na tela de login do aluno/servidor. Manda por
    e-mail um link de uso único que vale 30 minutos
    (`api/recuperar_senha.php` + `redefinir-senha.php`). O banco guarda só
    o hash do código (tabela `senha_reset`); a resposta é sempre a mesma,
    exista ou não o cadastro; pedidos seguidos são limitados.
  - **Sessão expira após 5 minutos sem atividade** (admin e aluno/servidor):
    `SESSAO_INATIVIDADE_SEGUNDOS` em `config/config.php` encerra no
    servidor; o `script.js` acompanha mouse/teclado/toque (valendo entre
    abas), avisa o servidor que a pessoa continua ativa (`api/sessao.php`)
    e manda para o login quando o tempo acaba.
  - Bancos criados antes desta data: rode
    `database/migracoes/2026-10-05-senha-reset.sql`.
- **Log de auditoria (2026-10-07)**: toda ação administrativa (aprovar/recusar
  agendamento e cadastro, criar reserva manual, cadastrar/ativar/desativar
  usuário, redefinir senha, alterar e-mail, cadastrar/editar/remover
  equipamento, remover qualquer registro) fica registrada na tabela
  `log_auditoria`: quem fez, o quê, em qual registro e quando. A senha nunca
  vai para o log. Nova aba **Auditoria** no painel do admin, com filtro por
  tipo de ação (`GET api/records.php?tipo=auditoria`). Bancos antigos: rode
  `database/migracoes/2026-10-07-log-auditoria.sql`.
- **Gráficos na aba Relatórios (2026-10-07)**, com Chart.js (carregado só para
  o admin): ocupação por dia da semana (barras), equipamentos mais pedidos
  (barras horizontais) e situação dos agendamentos (rosca: aprovados,
  pendentes, recusados). Cada gráfico tem "Ver como tabela" com os mesmos
  números e acompanha o modo escuro. Dados em
  `GET api/records.php?tipo=estatisticas` (somente admin).
- **Sugestão inteligente de horário (2026-10-07)**: quando o horário pedido
  está ocupado, a resposta de erro da API traz `horarios_livres` (intervalos
  livres do mesmo dia, considerando aprovados e pendentes) e o formulário
  mostra cada um como botão que já preenche Início/Término. Também corrigido:
  o cálculo de horários livres do calendário ignorava pedidos pendentes e
  somava 1 minuto após cada reserva; e a API aceitava agendar hoje num
  horário que já tinha passado.
- **Relatório de Uso em PDF (2026-10-07)**: botão **Exportar PDF** na aba
  Histórico do painel (respeita os filtros de mês/data). Gera, com a
  biblioteca dompdf, um PDF com logo, período, resumo (usos, horas de sala,
  participantes) e a tabela dos agendamentos aprovados
  (`api/exportar-pdf.php`, somente admin).
- **Novidades em tempo real (2026-10-07)**: com alguém logado e a aba visível,
  a página confere novidades a cada 15 segundos (polling do mesmo
  `GET api/records.php`). O aluno/servidor é avisado quando um agendamento
  dele é aprovado ou recusado; o admin, quando chega pedido novo de
  agendamento ou de cadastro. Para de consultar com a aba em segundo plano.
  Essas consultas automáticas mandam o cabeçalho `X-Atualizacao-Automatica`
  e não contam como atividade (senão o logout por inatividade nunca
  aconteceria); com um formulário aberto, a tela só é redesenhada depois,
  para não apagar o que já foi preenchido.
- **Adicionar ao calendário (.ics) (2026-10-07)**: link em cada agendamento
  aprovado, em "Meus agendamentos" e na Agenda do admin. Baixa um arquivo
  iCalendar (RFC 5545) que o Google Agenda, o Outlook e o calendário do
  celular importam, com lembrete 30 minutos antes
  (`api/exportar-ics.php?id=`). Só o admin ou o dono do agendamento baixam.
- **Limite de requisições por IP (2026-10-07)**: toda a API aceita até 60
  requisições por minuto por IP; acima disso responde `429 Too Many Requests`
  (com `Retry-After`). Limites mais apertados onde há risco de abuso: login de
  aluno/servidor e de admin (10 a cada 5 min), formulário de Contato,
  autocadastro e "Esqueci minha senha" (5 a cada 10 min). Contadores em
  arquivo na pasta temporária (`config/rate-limit.php`), com o IP guardado
  só como hash. Isso também resolve a limitação antiga do bloqueio de login,
  que ficava só na sessão e era contornado descartando o cookie.
- **Testes automatizados (2026-10-07)**: 36 testes PHPUnit em `tests/`
  (conflito de horário, disponibilidade de equipamento, matrícula duplicada,
  horários livres), com banco de teste separado. Para isso as regras saíram
  do `api/records.php` para `lib/regras-agendamento.php` (comportamento da API
  igual). Ver "Testes automatizados" acima.
- **Documentação da API (2026-10-07)**: `docs/openapi.yaml` (OpenAPI 3.0) descreve
  todos os endpoints (métodos, parâmetros, corpos, respostas e erros), e
  `api/docs.php` mostra a documentação interativa (Swagger UI), só para o
  admin: `http://localhost/gerenciamento-cit/api/docs.php`. O "Try it out"
  chama a API de verdade, com os dados reais.
- **Docker + CI (2026-10-07)**: `Dockerfile` (PHP 8.3 + Apache) e
  `docker-compose.yml` (app + MySQL 8 com o `schema.sql`) sobem o sistema em
  `localhost:8000` sem XAMPP; `.github/workflows/ci.yml` roda a checagem de
  sintaxe e o PHPUnit a cada push. Banco e `SITE_URL` passam a aceitar
  variáveis de ambiente (sem elas, valem os valores do XAMPP).
- **Segurança (2026-10-07)**: arquivos internos deixaram de ser baixáveis pela
  web. Antes, qualquer pessoa na mesma rede baixava o backup do banco, a pasta
  `.git`, os modelos e a documentação. `.htaccess` na raiz e em
  `config/`, `database/`, `docs/`, `lib/`, `tests/` e `vendor/`.
- **Cancelar com justificativa e editar o próprio agendamento (2026-10-07)**:
  em "Meus agendamentos", o dono pode **cancelar** (pendente ou aprovado que
  ainda não aconteceu) informando o motivo, e **editar** (só enquanto está
  pendente: data, horário, finalidade, participantes, descrição e
  equipamentos, com todas as validações de um pedido novo). O cancelamento não
  apaga mais o agendamento: ele fica como **Cancelado**, com o motivo, visível
  para o admin (Agenda, auditoria, gráficos, planilha), e a coordenação recebe
  um e-mail. Bancos antigos: rode `database/migracoes/2026-10-07-cancelamento.sql`.
- **Aba Usuários (2026-10-07)**: o cadastro e a lista de alunos/servidores
  saíram do topo da Área Administrativa para uma aba da Central de
  Gerenciamento, com busca e filtro (inclusive os pedidos recusados, que antes
  não apareciam em lugar nenhum).
- **Revisão do ponto de vista do aluno (2026-10-07)**: painel "Hoje" do topo com
  dados reais (antes eram horários de exemplo fixos, como "Prof. Silva");
  menu com "Área do aluno" e "Coordenação", o nome de quem está logado e
  "Sair"; Relatórios e Administração escondidos de quem não é admin;
  visitante sem login vê "Reservado" no calendário, sem o nome (a API deixou
  de enviá-lo); "Ocupação do mês" calculada de verdade; fonte do site 12,5%
  maior e página de Acessibilidade mais legível.
- **Responsividade em celular e tablet (2026-10-07)**: a página rola pelo
  documento, e não mais por dentro do `<body>` (no celular havia duas barras
  de rolagem); palavras não quebram mais no meio ("Agendam/ento",
  "Calendá/rio"); título, espaçamentos e topo menores no celular; Ações
  Rápidas em uma coluna; no tablet o topo não se divide em duas colunas, o
  "Como Funciona" fica em 2 colunas e o calendário mostra "Fechado" inteiro,
  com nomes limitados a 2 linhas.

## Limitações conhecidas (protótipo acadêmico)

- A API (`api/records.php`, `api/login_usuario.php`) não tem proteção CSRF
  própria — só o formulário de login do administrador (`login.php`) tem.
  O cookie de sessão com `SameSite=Lax` já bloqueia o ataque clássico via
  formulário cross-site em navegadores atuais, mas não cobre todo cenário;
  vale registrar como ponto de evolução futura.
- Recuperar a senha por e-mail só funciona para quem tem e-mail no cadastro
  (quem foi cadastrado antes de 2026-10-05 precisa que o admin preencha o
  e-mail pelo botão **E-mail**). O administrador não tem esse fluxo: a senha
  dele continua sendo trocada direto no banco.
- O painel administrativo ainda não tem uma aba "Mensagens" para as
  mensagens de Contato — hoje elas só chegam por e-mail (se configurado)
  ou direto no banco de dados.
- Um agendamento já **aprovado** não pode ser editado pelo dono (só cancelado
  e pedido de novo), porque a mudança exigiria nova análise da coordenação.
- O limite por IP (`config/rate-limit.php`) guarda os contadores em arquivo na
  pasta temporária do sistema: funciona bem num servidor só. Se o site um dia
  rodar em vários servidores atrás de um balanceador, os contadores teriam de
  ir para um lugar compartilhado (banco ou Redis). Atrás de um proxy reverso,
  todos chegariam com o IP do proxy — aí seria preciso configurar o IP real.
- O MySQL/MariaDB do XAMPP roda sem modo estrito (`sql_mode` sem
  `STRICT_TRANS_TABLES`): um valor inválido é gravado truncado ou vazio, em
  silêncio, em vez de dar erro. O PHP valida os campos principais, mas vale
  ligar o modo estrito no `my.ini`.

Detalhes, cenários de falha e recomendações para cada um desses pontos
estão no documento "Sistema de Agendamento CIT — Levantamento e Análise de
Requisitos (atualizado)", seção 6 (Revisão Técnica de Pré-Lançamento).
