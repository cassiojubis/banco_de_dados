<?php
/**
 * login.php
 * ---------------------------------------------------------------------
 * Tela de autenticação do administrador do CIT. Todo o restante do
 * sistema (index.php) exige uma sessão autenticada; esta é a única
 * porta de entrada.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/rate-limit.php';

// Se já existe sessão válida, não faz sentido mostrar o login de novo.
if (isAuthenticated()) {
    header('Location: index.php#admin');
    exit;
}

$erro = '';

// Chegou aqui porque a sessão expirou por inatividade (config.php, 1b).
if (!empty($_SESSION['sessao_expirada'])) {
    $erro = 'Sua sessão foi encerrada após ' . intdiv(SESSAO_INATIVIDADE_SEGUNDOS, 60) . ' minutos sem atividade. Entre novamente.';
    unset($_SESSION['sessao_expirada']);
}

// Limite por IP das tentativas de login (10 a cada 5 minutos). O
// bloqueio por sessão (loginBloqueado) um robô contorna descartando o
// cookie a cada tentativa; este não. Só conta envios do formulário.
$esperaIp = $_SERVER['REQUEST_METHOD'] === 'POST' ? registrarRequisicao('login-admin', 10, 5 * 60) : 0;

if ($esperaIp > 0) {
    http_response_code(429);
    header('Retry-After: ' . $esperaIp);
    $erro = 'Muitas tentativas de login deste computador. Tente novamente em ' . tempoDeEspera($esperaIp) . '.';
} elseif (loginBloqueado()) {
    $erro = 'Muitas tentativas incorretas. Tente novamente em ' . loginSegundosRestantes() . ' segundos.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Validação do token CSRF do formulário
    if (!csrfValidate($_POST['csrf_token'] ?? null)) {
        $erro = 'Sessão do formulário expirada. Tente novamente.';
    } else {
        // Sanitiza e valida as entradas do formulário
        $matricula = trim((string) ($_POST['matricula'] ?? ''));
        $senha     = (string) ($_POST['senha'] ?? '');

        if ($matricula === '' || $senha === '') {
            $erro = 'Informe matrícula e senha para continuar.';
        } else {
            $pdo = getPDO();
            if (!$pdo) {
                $erro = 'Não foi possível conectar ao banco de dados. Confira se o MySQL está rodando e se database/schema.sql foi executado.';
            } else {
                $stmt = $pdo->prepare(
                    "SELECT usua_id, usua_nome, usua_matricula, usua_senha_hash
                       FROM usuario
                      WHERE usua_matricula = ? AND usua_papel = 'admin'
                      LIMIT 1"
                );
                $stmt->execute([$matricula]);
                $admin = $stmt->fetch();

                if ($admin && password_verify($senha, $admin['usua_senha_hash'])) {
                    // Credenciais corretas: renova o ID de sessão (evita
                    // session fixation), zera o contador de tentativas e
                    // marca o administrador como autenticado.
                    session_regenerate_id(true);
                    limparTentativasLogin();
                    unset($_SESSION['sessao_expirada']);
                    $_SESSION['admin_logged_in'] = true;
                    $_SESSION['admin_usuario'] = $admin['usua_nome'];
                    $_SESSION['admin_matricula'] = $admin['usua_matricula'];
                    $_SESSION['admin_id'] = (int) $admin['usua_id'];

                    header('Location: index.php#admin');
                    exit;
                } else {
                    registrarTentativaFalha();
                    $erro = loginBloqueado()
                        ? 'Muitas tentativas incorretas. Tente novamente em ' . loginSegundosRestantes() . ' segundos.'
                        : 'Matrícula ou senha inválidos.';
                }
            }
        }
    }
}
?>
<!doctype html>
<html lang="pt-BR" class="h-full">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Entrar · <?= e(SITE_TITLE) ?></title>
<link rel="icon" type="image/png" href="<?= e(assetVersion('assets/img/favicon.png')) ?>">
<link rel="stylesheet" href="<?= e(assetVersion('assets/css/tailwind-local.css')) ?>">
<!-- Fonte de sistema como fallback: evita bloqueio de renderização por Google Fonts. -->
<link rel="stylesheet" href="<?= e(assetVersion('assets/css/style.css')) ?>">
<link rel="stylesheet" href="<?= e(assetVersion('assets/css/acessibilidade.css')) ?>">
<script>
    (function () {
      try {
        var fonte = localStorage.getItem('CIT_ACESSIBILIDADE_FONTE_V3');
        if (fonte) document.documentElement.style.fontSize = fonte + '%';
        if (localStorage.getItem('CIT_ACESSIBILIDADE_MODO_ESCURO') === 'true') {
          document.documentElement.classList.add('dark');
        }
      } catch (e) {}
    })();
</script>
<script>
    function googleTranslateElementInit() {
      new google.translate.TranslateElement({ pageLanguage: 'pt', includedLanguages: 'pt,en,es', autoDisplay: false }, 'google_translate_element');
    }
    // Só baixa o Google Tradutor (script externo que pode travar em
    // conexão ruim) quando o usuário escolheu outro idioma. Para quem
    // usa português — a maioria — nada é baixado e a página não depende
    // de servidor externo. Quando baixa, é de forma assíncrona, sem
    // bloquear o desenho da tela.
    (function () {
      try {
        var idioma = localStorage.getItem('CIT_IDIOMA');
        if (idioma && idioma !== 'pt') {
          var s = document.createElement('script');
          s.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
          s.async = true;
          document.head.appendChild(s);
        }
      } catch (e) {}
    })();
</script>
</head>
<body class="bg-gray-50 text-gray-800 min-h-screen flex items-center justify-center px-4 py-8">
<div id="google_translate_element" style="display:none;"></div>

<div class="w-full max-w-md">
    <div class="text-center mb-6">
        <a href="index.php" class="inline-block mb-3" aria-label="AgendaCIT — página inicial">
            <img src="<?= e(assetVersion('assets/img/logo-agendacit.png')) ?>" alt="AgendaCIT" width="112" height="112" class="w-28 h-28 object-contain mx-auto">
        </a>
        <h1 class="text-2xl font-black text-gray-800"><?= e(SITE_TITLE) ?></h1>
        <p class="text-sm text-gray-600 font-medium"><?= e(INSTITUTION_NAME) ?> · Acesso restrito ao administrador</p>
    </div>

    <div class="bg-white rounded-2xl p-5 sm:p-8 border-2 border-green-200 shadow-lg">
        <?php if ($erro !== ''): ?>
            <div class="mb-4 p-3 rounded-lg bg-red-50 border-2 border-red-200 text-sm text-red-700 font-semibold">
                <?= e($erro) ?>
            </div>
        <?php endif; ?>

        <form method="post" action="login.php" novalidate>
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

            <div class="mb-4">
                <label for="matricula" class="block text-sm font-bold text-gray-700 mb-2">Matrícula</label>
                <input type="text" id="matricula" name="matricula" required autofocus
                       class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium">
            </div>

            <div class="mb-6">
                <label for="senha" class="block text-sm font-bold text-gray-700 mb-2">Senha</label>
                <input type="password" id="senha" name="senha" required
                       class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium">
            </div>

            <button type="submit" class="w-full gradient-ifro text-white py-3 rounded-lg font-bold hover:shadow-lg transition-all text-lg">
                Entrar
            </button>
        </form>
    </div>

    <p class="text-center text-sm text-gray-600 mt-6">
        É aluno ou servidor?
        <a href="acesso.php" class="font-semibold text-green-700 hover:underline">Entrar na área do aluno →</a>
    </p>
</div>

<script src="assets/js/acessibilidade.js"></script>
</body>
</html>
