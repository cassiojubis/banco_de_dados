<?php
/**
 * Conflito de horário (sobreposição de intervalos) — a regra que impede
 * duas reservas da sala no mesmo período.
 */

use PHPUnit\Framework\Attributes\DataProvider;

final class ConflitoHorarioTest extends TestCaseComBanco
{
    /** @return array<string, array{string,string,string,string,bool}> */
    public static function pares(): array
    {
        return [
            'mesmo horário'                    => ['08:00', '10:00', '08:00', '10:00', true],
            'cruza o início'                   => ['08:00', '10:00', '07:00', '09:00', true],
            'cruza o fim'                      => ['08:00', '10:00', '09:00', '11:00', true],
            'um dentro do outro'               => ['08:00', '12:00', '09:00', '10:00', true],
            'um engloba o outro'               => ['09:00', '10:00', '08:00', '12:00', true],
            'só 1 minuto em comum'             => ['08:00', '10:00', '09:59', '11:00', true],
            'encosta no fim (não conflita)'    => ['08:00', '10:00', '10:00', '11:00', false],
            'encosta no início (não conflita)' => ['08:00', '10:00', '07:00', '08:00', false],
            'antes'                            => ['08:00', '10:00', '06:00', '07:00', false],
            'depois'                           => ['08:00', '10:00', '13:00', '14:00', false],
        ];
    }

    #[DataProvider('pares')]
    public function testSobreposicaoDeIntervalos(string $i1, string $f1, string $i2, string $f2, bool $esperado): void
    {
        $this->assertSame($esperado, intervalosSeSobrepoem($i1, $f1, $i2, $f2));
        // A ordem dos dois intervalos não muda a resposta.
        $this->assertSame($esperado, intervalosSeSobrepoem($i2, $f2, $i1, $f1));
    }

    public function testAprovadoEPendenteSeguramOHorario(): void
    {
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'approved');
        $this->criarAgendamento('2030-03-04', '14:00', '16:00', 'pending');

        $this->assertSame(1, contarConflitosHorario($this->pdo, '2030-03-04', '09:00', '11:00'));
        $this->assertSame(1, contarConflitosHorario($this->pdo, '2030-03-04', '15:00', '17:00'));
        $this->assertSame(2, contarConflitosHorario($this->pdo, '2030-03-04', '07:00', '18:00'));
    }

    public function testRecusadoECanceladoNaoSeguramOHorario(): void
    {
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'rejected');
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'cancelled');

        $this->assertSame(0, contarConflitosHorario($this->pdo, '2030-03-04', '08:00', '10:00'));
    }

    public function testAoEditarOProprioAgendamentoNaoConflitaConsigoMesmo(): void
    {
        $proprio = $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'pending');
        $this->criarAgendamento('2030-03-04', '13:00', '14:00', 'approved');

        // Mudar 08-10 para 09-11: só "conflitaria" consigo mesmo.
        $this->assertSame(0, contarConflitosHorario($this->pdo, '2030-03-04', '09:00', '11:00', false, $proprio));
        // Mudar para 12:30-13:30 cruza o outro agendamento.
        $this->assertSame(1, contarConflitosHorario($this->pdo, '2030-03-04', '12:30', '13:30', false, $proprio));
    }

    public function testOutroDiaEHorarioEncostadoNaoConflitam(): void
    {
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'approved');

        $this->assertSame(0, contarConflitosHorario($this->pdo, '2030-03-05', '08:00', '10:00'), 'outro dia');
        $this->assertSame(0, contarConflitosHorario($this->pdo, '2030-03-04', '10:00', '12:00'), 'começa quando o outro termina');
        $this->assertSame(0, contarConflitosHorario($this->pdo, '2030-03-04', '07:00', '08:00'), 'termina quando o outro começa');
    }

    public function testComTravaDentroDeTransacao(): void
    {
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'approved');

        $this->pdo->beginTransaction();
        $this->assertSame(1, contarConflitosHorario($this->pdo, '2030-03-04', '09:00', '09:30', true));
        $this->pdo->rollBack();
    }
}
