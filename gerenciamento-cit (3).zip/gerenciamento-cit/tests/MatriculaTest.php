<?php
/**
 * Validação de matrícula duplicada no cadastro de aluno/servidor.
 */

final class MatriculaTest extends TestCaseComBanco
{
    public function testMatriculaNovaPodeCadastrar(): void
    {
        $this->assertSame(['acao' => 'nova', 'usua_id' => null], situacaoMatricula($this->pdo, '2024109100001'));
    }

    public function testMatriculaPendenteOuAprovadaFicaBloqueada(): void
    {
        $pendente = $this->criarUsuario('2024109100002', 'aluno', 'pendente');
        $aprovado = $this->criarUsuario('2024109100003', 'servidor', 'aprovado');

        $this->assertSame(['acao' => 'bloqueada', 'usua_id' => $pendente], situacaoMatricula($this->pdo, '2024109100002'));
        $this->assertSame(['acao' => 'bloqueada', 'usua_id' => $aprovado], situacaoMatricula($this->pdo, '2024109100003'));
    }

    public function testMatriculaRecusadaPodeSerReaproveitada(): void
    {
        // Regressão: antes o cadastro recusado sumia do painel mas
        // continuava ocupando a matrícula para sempre.
        $recusado = $this->criarUsuario('2024109100004', 'aluno', 'recusado');

        $this->assertSame(['acao' => 'reaproveitar', 'usua_id' => $recusado], situacaoMatricula($this->pdo, '2024109100004'));
    }

    public function testMatriculaDoAdministradorNuncaEReaproveitada(): void
    {
        $admin = $this->criarUsuario('admin', 'admin', 'recusado');

        $this->assertSame(['acao' => 'bloqueada', 'usua_id' => $admin], situacaoMatricula($this->pdo, 'admin'));
    }

    public function testMaiusculasEMinusculasContamComoAMesmaMatricula(): void
    {
        // A coluna usa collation sem distinção de maiúsculas (utf8mb4_unicode_ci),
        // igual à UNIQUE do banco — "ABC123" e "abc123" são a mesma matrícula.
        $id = $this->criarUsuario('ABC123', 'aluno', 'aprovado');

        $this->assertSame(['acao' => 'bloqueada', 'usua_id' => $id], situacaoMatricula($this->pdo, 'abc123'));
    }

    public function testBancoRecusaMatriculaRepetidaMesmoSemAChecagem(): void
    {
        // Última linha de defesa (duas requisições simultâneas): a UNIQUE
        // do banco, que a API traduz para "Essa matrícula já está cadastrada".
        $this->criarUsuario('2024109100005');

        $this->expectException(PDOException::class);
        $this->criarUsuario('2024109100005');
    }
}
