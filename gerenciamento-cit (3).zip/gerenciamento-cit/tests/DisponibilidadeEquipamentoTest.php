<?php
/**
 * Disponibilidade de equipamento: total cadastrado menos o que está
 * reservado em agendamentos APROVADOS no mesmo dia e horário sobreposto.
 */

final class DisponibilidadeEquipamentoTest extends TestCaseComBanco
{
    public function testSemReservasTudoDisponivel(): void
    {
        $projetor = $this->criarEquipamento('Projetor', 3);

        $this->assertSame(0, quantidadeReservada($this->pdo, $projetor, '2030-03-04', '08:00', '10:00'));
        $this->assertSame(3, disponibilidadeEquipamento($this->pdo, $projetor, '2030-03-04', '08:00', '10:00'));
    }

    public function testAprovadoSobrepostoDescontaDoTotal(): void
    {
        $notebook = $this->criarEquipamento('Notebook', 10);
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'approved', [$notebook => 4]);
        $this->criarAgendamento('2030-03-04', '09:00', '11:00', 'approved', [$notebook => 3]);

        // 09:00-09:30 cruza os dois aprovados: 4 + 3 reservados.
        $this->assertSame(7, quantidadeReservada($this->pdo, $notebook, '2030-03-04', '09:00', '09:30'));
        $this->assertSame(3, disponibilidadeEquipamento($this->pdo, $notebook, '2030-03-04', '09:00', '09:30'));
        // 10:30-12:00 só cruza o segundo.
        $this->assertSame(7, disponibilidadeEquipamento($this->pdo, $notebook, '2030-03-04', '10:30', '12:00'));
    }

    public function testPendenteERecusadoNaoReservam(): void
    {
        $kit = $this->criarEquipamento('Kit de robótica', 5);
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'pending', [$kit => 5]);
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'rejected', [$kit => 5]);

        $this->assertSame(5, disponibilidadeEquipamento($this->pdo, $kit, '2030-03-04', '08:00', '10:00'));
    }

    public function testOutroDiaOuHorarioSemSobreposicaoNaoReserva(): void
    {
        // Regressão: antes a conta somava TODOS os aprovados de todas as
        // datas, e o equipamento parecia esgotado para sempre.
        $impressora = $this->criarEquipamento('Impressora 3D', 2);
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'approved', [$impressora => 2]);

        $this->assertSame(2, disponibilidadeEquipamento($this->pdo, $impressora, '2030-03-05', '08:00', '10:00'), 'outro dia');
        $this->assertSame(2, disponibilidadeEquipamento($this->pdo, $impressora, '2030-03-04', '10:00', '12:00'), 'logo depois');
    }

    public function testIgnorarOProprioAgendamentoAoAprovar(): void
    {
        $projetor = $this->criarEquipamento('Projetor', 2);
        $id = $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'approved', [$projetor => 2]);

        $this->assertSame(0, disponibilidadeEquipamento($this->pdo, $projetor, '2030-03-04', '08:00', '10:00'));
        $this->assertSame(2, disponibilidadeEquipamento($this->pdo, $projetor, '2030-03-04', '08:00', '10:00', $id));
    }

    public function testNuncaNegativoEEquipamentoInexistente(): void
    {
        $projetor = $this->criarEquipamento('Projetor', 3);
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'approved', [$projetor => 3]);
        // O admin diminuiu o total depois da reserva (cenário que a API
        // impede, mas o cálculo não pode dar número negativo).
        $this->pdo->prepare('UPDATE equipamento SET equip_quantidade = 1 WHERE equip_id = ?')->execute([$projetor]);

        $this->assertSame(0, disponibilidadeEquipamento($this->pdo, $projetor, '2030-03-04', '08:00', '10:00'));
        $this->assertSame(0, disponibilidadeEquipamento($this->pdo, 999999, '2030-03-04', '08:00', '10:00'));
    }
}
