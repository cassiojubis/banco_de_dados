<?php
/**
 * tests/TestCaseComBanco.php
 * ---------------------------------------------------------------------
 * Base dos testes que usam o banco de teste: abre a conexão, esvazia as
 * tabelas antes de cada teste (cada um começa do zero, sem depender da
 * ordem) e oferece atalhos para criar usuário, equipamento e
 * agendamento de exemplo.
 * ---------------------------------------------------------------------
 */

use PHPUnit\Framework\TestCase;

abstract class TestCaseComBanco extends TestCase
{
    public static string $nomeBanco = 'agendacit_test';
    protected PDO $pdo;

    protected function setUp(): void
    {
        $this->pdo = new PDO(
            sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
                getenv('TEST_DB_HOST') ?: '127.0.0.1', getenv('TEST_DB_PORT') ?: '3306', self::$nomeBanco),
            getenv('TEST_DB_USER') ?: 'root',
            getenv('TEST_DB_PASS') ?: '',
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
        $this->pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        foreach (['alocacao', 'agendamento', 'equipamento', 'senha_reset', 'log_auditoria', 'mensagem', 'usuario'] as $tabela) {
            $this->pdo->exec("DELETE FROM `{$tabela}`");
        }
        $this->pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
    }

    protected function criarUsuario(string $matricula, string $papel = 'aluno', string $aprovacao = 'aprovado'): int
    {
        $this->pdo->prepare(
            'INSERT INTO usuario (usua_nome, usua_matricula, usua_senha_hash, usua_papel, usua_ativo, usua_aprovacao)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute(["Usuário {$matricula}", $matricula, password_hash('senha123', PASSWORD_DEFAULT), $papel,
                    $aprovacao === 'aprovado' ? 1 : 0, $aprovacao]);
        return (int) $this->pdo->lastInsertId();
    }

    protected function criarEquipamento(string $nome, int $quantidade): int
    {
        $this->pdo->prepare('INSERT INTO equipamento (equip_nome, equip_quantidade) VALUES (?, ?)')
            ->execute([$nome, $quantidade]);
        return (int) $this->pdo->lastInsertId();
    }

    /**
     * @param array<int,int> $equipamentos  [equip_id => quantidade]
     */
    protected function criarAgendamento(string $data, string $inicio, string $fim, string $status = 'approved', array $equipamentos = []): int
    {
        $this->pdo->prepare(
            'INSERT INTO agendamento (agen_responsavel, agen_data, agen_hora_inicio, agen_hora_fim, agen_finalidade, agen_status)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute(['Teste', $data, $inicio, $fim, 'Aula', $status]);
        $id = (int) $this->pdo->lastInsertId();
        foreach ($equipamentos as $equipId => $quantidade) {
            $this->pdo->prepare('INSERT INTO alocacao (aloc_agendamento_id, aloc_equipamento_id, aloc_quantidade) VALUES (?, ?, ?)')
                ->execute([$id, $equipId, $quantidade]);
        }
        return $id;
    }
}
