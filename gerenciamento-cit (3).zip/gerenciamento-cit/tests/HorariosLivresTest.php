<?php
/**
 * Horários livres sugeridos quando o horário pedido está ocupado
 * (calcularIntervalosLivres e horariosLivres).
 */

final class HorariosLivresTest extends TestCaseComBanco
{
    public function testDiaVazioEstaTodoLivre(): void
    {
        $this->assertSame([['inicio' => '08:00', 'fim' => '22:00']], calcularIntervalosLivres([], '08:00', '22:00'));
    }

    public function testBuracosEntreReservasForaDeOrdem(): void
    {
        $livres = calcularIntervalosLivres([['12:00', '14:00'], ['08:00', '10:00']], '08:00', '22:00');

        $this->assertSame([
            ['inicio' => '10:00', 'fim' => '12:00'],
            ['inicio' => '14:00', 'fim' => '22:00'],
        ], $livres);
    }

    public function testReservasEncostadasNaoDeixamBuracoDeUmMinuto(): void
    {
        // Regressão: antes o próximo livre começava 1 minuto depois (10:01).
        $livres = calcularIntervalosLivres([['08:00', '10:00'], ['10:00', '12:00']], '08:00', '22:00');

        $this->assertSame([['inicio' => '12:00', 'fim' => '22:00']], $livres);
    }

    public function testReservasSobrepostasEReservaDentroDeOutra(): void
    {
        $livres = calcularIntervalosLivres([['08:00', '12:00'], ['09:00', '10:00'], ['11:00', '13:00']], '08:00', '22:00');

        $this->assertSame([['inicio' => '13:00', 'fim' => '22:00']], $livres);
    }

    public function testRespeitaOHorarioDeFuncionamento(): void
    {
        // Reserva que começa antes da abertura e outra que passa do fechamento.
        $livres = calcularIntervalosLivres([['07:00', '09:00'], ['21:00', '23:00']], '08:00', '22:00');

        $this->assertSame([['inicio' => '09:00', 'fim' => '21:00']], $livres);
    }

    public function testDiaLotadoNaoTemSugestao(): void
    {
        $this->assertSame([], calcularIntervalosLivres([['08:00', '22:00']], '08:00', '22:00'));
    }

    public function testHojeIgnoraOQueJaPassouArredondandoPara5Minutos(): void
    {
        // Agora = 13:42 → próximo horário oferecido: 13:45.
        $livres = calcularIntervalosLivres([['15:00', '16:00']], '08:00', '22:00', 13 * 60 + 42);

        $this->assertSame([
            ['inicio' => '13:45', 'fim' => '15:00'],
            ['inicio' => '16:00', 'fim' => '22:00'],
        ], $livres);
    }

    public function testHojeDepoisDoFechamentoNaoTemSugestao(): void
    {
        $this->assertSame([], calcularIntervalosLivres([], '08:00', '22:00', 22 * 60 + 10));
    }

    public function testNoBancoPendenteConflitaERecusadoNao(): void
    {
        $this->criarAgendamento('2030-03-04', '08:00', '10:00', 'approved');
        $this->criarAgendamento('2030-03-04', '12:00', '14:00', 'pending');
        $this->criarAgendamento('2030-03-04', '15:00', '17:00', 'rejected');
        $this->criarAgendamento('2030-03-05', '10:00', '20:00', 'approved'); // outro dia

        $this->assertSame([
            ['inicio' => '10:00', 'fim' => '12:00'],
            ['inicio' => '14:00', 'fim' => '22:00'],
        ], horariosLivres($this->pdo, '2030-03-04', '08:00', '22:00'));
    }

    public function testValidacaoDeDataEHora(): void
    {
        $this->assertTrue(dataValida('2030-02-28'));
        $this->assertFalse(dataValida('2030-02-30'), 'dia que não existe');
        $this->assertFalse(dataValida('04/03/2030'), 'formato brasileiro não é aceito pela API');
        $this->assertTrue(horaValida('08:05'));
        $this->assertFalse(horaValida('8:05'), 'sem zero à esquerda');
        $this->assertFalse(horaValida('24:00'));
    }
}
