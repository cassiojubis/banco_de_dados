<?php
/**
 * tests/bootstrap.php
 * ---------------------------------------------------------------------
 * Preparação dos testes automatizados (carregado pelo phpunit.xml antes
 * de qualquer teste):
 *   1. carrega a configuração do projeto (fuso horário, horário de
 *      funcionamento) e as regras de lib/regras-agendamento.php;
 *   2. recria o banco de TESTE (agendacit_test por padrão — nunca o
 *      banco real) a partir de database/schema.sql, para todo teste
 *      começar com as tabelas exatamente como no projeto.
 *
 * Conexão em variáveis de ambiente TEST_DB_* (padrões no phpunit.xml).
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../lib/regras-agendamento.php';
require_once __DIR__ . '/TestCaseComBanco.php';

// config.php esconde os erros (bom para o site); nos testes queremos vê-los.
ini_set('display_errors', '1');

$nomeBanco = getenv('TEST_DB_NAME') ?: 'agendacit_test';
if (!preg_match('/^[A-Za-z0-9_]+$/', $nomeBanco) || $nomeBanco === 'agendacit') {
    fwrite(STDERR, "TEST_DB_NAME inválido ('{$nomeBanco}'): use um banco separado só para testes.\n");
    exit(1);
}

$servidor = new PDO(
    sprintf('mysql:host=%s;port=%s;charset=utf8mb4', getenv('TEST_DB_HOST') ?: '127.0.0.1', getenv('TEST_DB_PORT') ?: '3306'),
    getenv('TEST_DB_USER') ?: 'root',
    getenv('TEST_DB_PASS') ?: '',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);

// O schema.sql cria e usa o banco `agendacit`; aqui o mesmo script é
// apontado para o banco de teste.
$schema = file_get_contents(__DIR__ . '/../database/schema.sql');
$schema = str_replace('`agendacit`', "`{$nomeBanco}`", $schema);
$servidor->exec("DROP DATABASE IF EXISTS `{$nomeBanco}`");
$servidor->exec($schema);
unset($servidor, $schema);

TestCaseComBanco::$nomeBanco = $nomeBanco;
