-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: agendacit
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agendamento`
--

DROP TABLE IF EXISTS `agendamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agendamento` (
  `agen_id` int(11) NOT NULL AUTO_INCREMENT,
  `agen_usuario_id` int(11) DEFAULT NULL,
  `agen_responsavel` varchar(150) NOT NULL,
  `agen_data` date NOT NULL,
  `agen_hora_inicio` time NOT NULL,
  `agen_hora_fim` time NOT NULL,
  `agen_finalidade` varchar(150) NOT NULL,
  `agen_observacoes` text DEFAULT NULL,
  `agen_participantes` int(11) NOT NULL DEFAULT 0,
  `agen_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `agen_motivo_recusa` varchar(255) DEFAULT NULL,
  `agen_criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `agen_atualizado_em` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`agen_id`),
  KEY `fk_agendamento_usuario_idx` (`agen_usuario_id`),
  KEY `idx_agendamento_data_hora` (`agen_data`,`agen_hora_inicio`,`agen_hora_fim`),
  CONSTRAINT `fk_agendamento_usuario` FOREIGN KEY (`agen_usuario_id`) REFERENCES `usuario` (`usua_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agendamento`
--

LOCK TABLES `agendamento` WRITE;
/*!40000 ALTER TABLE `agendamento` DISABLE KEYS */;
INSERT INTO `agendamento` VALUES (1,NULL,'neemias','2026-10-05','07:00:00','08:50:00','Aula','dsdvrgvagf',12,'approved',NULL,'2026-10-05 09:10:55','2026-10-05 09:11:17'),(2,NULL,'neemias','2026-10-05','14:00:00','16:50:00','Aula','fdhdathbatfdg',12,'approved',NULL,'2026-10-05 09:11:10','2026-10-05 09:11:18');
/*!40000 ALTER TABLE `agendamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alocacao`
--

DROP TABLE IF EXISTS `alocacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alocacao` (
  `aloc_id` int(11) NOT NULL AUTO_INCREMENT,
  `aloc_agendamento_id` int(11) NOT NULL,
  `aloc_equipamento_id` int(11) NOT NULL,
  `aloc_quantidade` int(11) NOT NULL,
  PRIMARY KEY (`aloc_id`),
  UNIQUE KEY `uq_aloc_agen_equip` (`aloc_equipamento_id`,`aloc_agendamento_id`),
  KEY `fk_alocacao_agendamento_idx` (`aloc_agendamento_id`),
  KEY `fk_alocacao_equipamento_idx` (`aloc_equipamento_id`),
  CONSTRAINT `fk_alocacao_agendamento` FOREIGN KEY (`aloc_agendamento_id`) REFERENCES `agendamento` (`agen_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_alocacao_equipamento` FOREIGN KEY (`aloc_equipamento_id`) REFERENCES `equipamento` (`equip_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alocacao`
--

LOCK TABLES `alocacao` WRITE;
/*!40000 ALTER TABLE `alocacao` DISABLE KEYS */;
/*!40000 ALTER TABLE `alocacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `equipamento`
--

DROP TABLE IF EXISTS `equipamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipamento` (
  `equip_id` int(11) NOT NULL AUTO_INCREMENT,
  `equip_codigo` varchar(45) DEFAULT NULL,
  `equip_nome` varchar(150) NOT NULL,
  `equip_tipo` varchar(50) DEFAULT NULL,
  `equip_categoria` varchar(100) DEFAULT NULL,
  `equip_quantidade` int(11) NOT NULL DEFAULT 0,
  `equip_situacao` enum('Disponível','Indisponível','Em manutenção') NOT NULL DEFAULT 'Disponível',
  `equip_foto_url` mediumtext DEFAULT NULL,
  `equip_criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `equip_atualizado_em` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`equip_id`),
  UNIQUE KEY `equipamento_codigo_UNIQUE` (`equip_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipamento`
--

LOCK TABLES `equipamento` WRITE;
/*!40000 ALTER TABLE `equipamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mensagem`
--

DROP TABLE IF EXISTS `mensagem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensagem` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_nome` varchar(150) NOT NULL,
  `msg_email` varchar(150) NOT NULL,
  `msg_mensagem` text NOT NULL,
  `msg_status` enum('novo','lido','respondido') NOT NULL DEFAULT 'novo',
  `msg_criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensagem`
--

LOCK TABLES `mensagem` WRITE;
/*!40000 ALTER TABLE `mensagem` DISABLE KEYS */;
INSERT INTO `mensagem` VALUES (1,'Neemias','tiktokverificado21@gmail.com','testando mensagens para ver se eta chegando no email','novo','2026-10-05 09:03:46');
/*!40000 ALTER TABLE `mensagem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `usua_id` int(11) NOT NULL AUTO_INCREMENT,
  `usua_nome` varchar(150) NOT NULL,
  `usua_matricula` varchar(60) NOT NULL,
  `usua_email` varchar(150) DEFAULT NULL,
  `usua_senha_hash` varchar(255) NOT NULL,
  `usua_papel` enum('aluno','servidor','admin') NOT NULL DEFAULT 'aluno',
  `usua_ativo` tinyint(1) NOT NULL DEFAULT 1,
  `usua_aprovacao` varchar(25) NOT NULL DEFAULT 'pendente',
  `usua_motivo_recusa` longtext DEFAULT NULL,
  `usua_criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `usua_atualizado_em` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`usua_id`),
  UNIQUE KEY `usuario_matricula_UNIQUE` (`usua_matricula`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (1,'Administrador','admin',NULL,'$2y$10$2qwXDIK.nFfzizH8m0d/..xV7hCdgDYeIWP7/AiqZywIFRKr.Chny','admin',1,'aprovado',NULL,'2026-09-29 15:45:47','2026-09-29 15:45:47'),(2,'kallyRainhaDaCola','20304050',NULL,'$2y$10$fttd1SOZDfKX7AnYLlf82ew2AyBHAA4.ns3rgoJYcqpjhuSgf..Qi','servidor',1,'aprovado',NULL,'2026-09-29 11:55:41','2026-09-29 11:56:38'),(3,'neemias','210922',NULL,'$2y$10$nQ.63pMRyt/Pq5z1AAmtGut.tzG8xKM8/KLj9LpbwvhbHxoCvbFAS','servidor',1,'aprovado',NULL,'2026-10-05 09:06:22','2026-10-05 09:06:22'),(4,'cassio','2024109100066',NULL,'$2y$10$Bi.FhkSxmxSurXZ7fLbL0evOadhQF/0tIcuEltKjvoJZFzs1NJFdC','aluno',0,'recusado','seu cadastro foi recusado por você ser la ele','2026-10-05 09:18:06','2026-10-05 09:18:40');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-05 10:04:20
