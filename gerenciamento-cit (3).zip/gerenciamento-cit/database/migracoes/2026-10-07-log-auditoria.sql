-- Migração de 2026-10-07: log de auditoria das ações administrativas
-- (quem aprovou/recusou/editou/removeu o quê, e quando). Rode UMA vez
-- em bancos criados antes desta data.
CREATE TABLE IF NOT EXISTS `log_auditoria` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `log_usuario_id` int DEFAULT NULL,
  `log_usuario_nome` varchar(150) NOT NULL,
  `log_acao` varchar(60) NOT NULL,
  `log_entidade` varchar(30) NOT NULL,
  `log_entidade_id` int NOT NULL,
  `log_detalhes` text,
  `log_criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`log_id`),
  KEY `idx_log_criado_em` (`log_criado_em`),
  KEY `idx_log_acao` (`log_acao`),
  KEY `fk_log_usuario_idx` (`log_usuario_id`),
  CONSTRAINT `fk_log_usuario` FOREIGN KEY (`log_usuario_id`) REFERENCES `usuario` (`usua_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
