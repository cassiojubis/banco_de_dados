-- Migração de 2026-10-07: o dono pode cancelar o próprio agendamento
-- com justificativa. Antes o cancelamento APAGAVA o agendamento; agora
-- ele fica com a situação 'cancelled' e o motivo, para o admin ver.
-- Rode UMA vez em bancos criados antes desta data.
ALTER TABLE `agendamento`
  MODIFY `agen_status` enum('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  ADD COLUMN `agen_motivo_cancelamento` varchar(255) DEFAULT NULL AFTER `agen_motivo_recusa`;
