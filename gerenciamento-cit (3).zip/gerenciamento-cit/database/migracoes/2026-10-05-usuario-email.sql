-- Migração de 2026-10-05: e-mail do aluno/servidor, usado para avisar
-- quando o cadastro ou um agendamento é aprovado/recusado.
-- Rode UMA vez em bancos criados antes desta data (quem rodar o
-- database/schema.sql atual já ganha a coluna).
ALTER TABLE `usuario` ADD COLUMN `usua_email` varchar(150) DEFAULT NULL AFTER `usua_matricula`;
