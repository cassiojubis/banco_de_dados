-- Migração de 2026-10-05: pedidos de "Esqueci minha senha".
-- Guarda só o HASH (sha256) do código enviado por e-mail — quem tiver
-- acesso ao banco não consegue usar o link. Cada código vale 30 minutos
-- e uma única vez. Rode UMA vez em bancos criados antes desta data.
CREATE TABLE IF NOT EXISTS `senha_reset` (
  `rese_id` int NOT NULL AUTO_INCREMENT,
  `rese_usuario_id` int NOT NULL,
  `rese_token_hash` char(64) NOT NULL,
  `rese_expira_em` datetime NOT NULL,
  `rese_usado_em` datetime DEFAULT NULL,
  `rese_criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rese_id`),
  UNIQUE KEY `uq_senha_reset_token` (`rese_token_hash`),
  KEY `fk_senha_reset_usuario_idx` (`rese_usuario_id`),
  CONSTRAINT `fk_senha_reset_usuario` FOREIGN KEY (`rese_usuario_id`) REFERENCES `usuario` (`usua_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
