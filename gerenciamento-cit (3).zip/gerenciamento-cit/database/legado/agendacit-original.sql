-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: agendacit
-- ------------------------------------------------------
-- Server version	8.0.43
--
-- Ajustado por Claude em 2026-09-28: a acentuação (collation) trocada de
-- utf8mb4_0900_ai_ci para utf8mb4_unicode_ci em todo o arquivo — a
-- primeira só existe no MySQL 8 de verdade; o MySQL que vem dentro do
-- XAMPP para Windows é, na prática, o MariaDB, que não reconhece
-- utf8mb4_0900_ai_ci e travava a criação das tabelas logo na primeira
-- (erro "Unknown collation"). utf8mb4_unicode_ci funciona igual em
-- MySQL e MariaDB e não muda nada no funcionamento do site.
--
-- Revisado por Claude em 2026-09-28: corrige/completa o schema original
-- (agendacit.sql) para bater com tudo que o site usa hoje. Mudanças em
-- relação ao arquivo original, tabela por tabela:
--
--   usuario:
--     - UNIQUE KEY movida de usua_nome para usua_matricula (é a
--       matrícula que precisa ser única — duas pessoas podem ter o
--       mesmo nome, nunca a mesma matrícula; é por ela que o login
--       de aluno/servidor/admin acontece).
--     - usua_nome, usua_matricula, usua_senha_hash e usua_papel viram
--       NOT NULL (o site sempre preenche esses 4 campos).
--     - usua_ativo e usua_aprovacao ganham DEFAULT (1 / 'pendente').
--     - adicionadas usua_criado_em / usua_atualizado_em.
--
--   equipamento:
--     - equip_id ganha AUTO_INCREMENT (faltava — sem isso cada
--       INSERT precisaria informar o ID manualmente).
--     - adicionadas equip_tipo, equip_categoria, equip_quantidade,
--       equip_situacao e equip_foto_url — sem elas não há onde
--       salvar o que a tela de Equipamentos cadastra/edita hoje
--       (tipo, categoria, quantidade total, situação e foto).
--     - adicionadas equip_criado_em / equip_atualizado_em.
--     - UNIQUE KEY em equip_codigo (evita cadastrar o mesmo código
--       de patrimônio duas vezes). Se vocês não usam código único
--       por equipamento, é só remover essa linha antes de rodar.
--
--   agendamento:
--     - agen_participantes ganha DEFAULT '0'; agen_status ganha
--       DEFAULT 'pending'.
--     - adicionadas agen_criado_em / agen_atualizado_em — sem elas a
--       aba "Últimas Atividades" dos Relatórios (que ordena por data
--       de criação) não tem o que mostrar.
--     - adicionado índice (agen_data, agen_hora_inicio, agen_hora_fim)
--       para deixar rápida a checagem de conflito de horário, que vai
--       rodar a cada novo agendamento.
--
--   alocacao:
--     - sem mudanças — já estava completa.
--
-- Revisado de novo em 2026-09-28 (2ª passada, relendo script.js inteiro):
--   - equip_codigo: era NOT NULL UNIQUE, mas a tela de cadastro de
--     equipamento (addEquipment/submitEditEquipment) não tem campo de
--     código nenhum — todo INSERT ia falhar por coluna obrigatória sem
--     valor. Virou opcional (aceita NULL, mas continua único quando
--     preenchido). Se um dia vocês adicionarem um campo de código no
--     formulário, dá pra voltar a NOT NULL.
--   - equip_foto_url: era varchar(255), mas a foto não é uma URL — é a
--     imagem inteira em base64 (lerArquivoComoDataURL, no script.js),
--     que facilmente passa de 100 mil caracteres. Em varchar(255) isso
--     seria truncado. Trocado para MEDIUMTEXT (cabe até ~16MB). Se no
--     futuro vocês passarem a salvar a foto como arquivo de verdade no
--     servidor (upload real, com um endpoint em PHP) em vez de base64,
--     aí sim varchar(255) com o caminho do arquivo volta a fazer sentido
--     e é mais leve pro banco.
--
--   mensagem:
--     - adicionada msg_status (novo/lido/respondido), pra dar pro
--       admin marcar o que já foi visto/respondido.
--     - adicionada msg_criado_em — sem ela não dá pra ordenar as
--       mensagens por mais recente nem saber quando cada uma chegou.
--
-- ------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `agendacit` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `agendacit`;

--
-- Table structure for table `usuario`
-- (aluno, servidor OU admin — o papel é quem diferencia, todos logam
-- por matrícula + senha)
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario` (
  `usua_id` int NOT NULL AUTO_INCREMENT,
  `usua_nome` varchar(150) NOT NULL,
  `usua_matricula` varchar(60) NOT NULL,
  `usua_senha_hash` varchar(255) NOT NULL,
  `usua_papel` enum('aluno','servidor','admin') NOT NULL DEFAULT 'aluno',
  `usua_ativo` tinyint(1) NOT NULL DEFAULT '1',
  `usua_aprovacao` varchar(25) NOT NULL DEFAULT 'pendente',
  `usua_motivo_recusa` longtext,
  `usua_criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usua_atualizado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`usua_id`),
  UNIQUE KEY `usuario_matricula_UNIQUE` (`usua_matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Usuário administrador inicial — mesma credencial que o protótipo
-- sempre usou (matrícula "admin", senha "cit@2025"), agora dentro da
-- tabela usuario em vez de constantes fixas em config/config.php.
-- O hash abaixo é bcrypt de "cit@2025" (o mesmo que já estava em uso).
--
INSERT INTO `usuario`
  (`usua_nome`, `usua_matricula`, `usua_senha_hash`, `usua_papel`, `usua_ativo`, `usua_aprovacao`)
VALUES
  ('Administrador', 'admin', '$2y$10$2qwXDIK.nFfzizH8m0d/..xV7hCdgDYeIWP7/AiqZywIFRKr.Chny', 'admin', 1, 'aprovado');

--
-- Table structure for table `equipamento`
--

DROP TABLE IF EXISTS `equipamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipamento` (
  `equip_id` int NOT NULL AUTO_INCREMENT,
  `equip_codigo` varchar(45) DEFAULT NULL,
  `equip_nome` varchar(150) NOT NULL,
  `equip_tipo` varchar(50) DEFAULT NULL,
  `equip_categoria` varchar(100) DEFAULT NULL,
  `equip_quantidade` int NOT NULL DEFAULT '0',
  `equip_situacao` enum('Disponível','Indisponível','Em manutenção') NOT NULL DEFAULT 'Disponível',
  `equip_foto_url` mediumtext,
  `equip_criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `equip_atualizado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`equip_id`),
  UNIQUE KEY `equipamento_codigo_UNIQUE` (`equip_codigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `agendamento`
--

DROP TABLE IF EXISTS `agendamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agendamento` (
  `agen_id` int NOT NULL AUTO_INCREMENT,
  `agen_usuario_id` int DEFAULT NULL,
  `agen_responsavel` varchar(150) NOT NULL,
  `agen_data` date NOT NULL,
  `agen_hora_inicio` time NOT NULL,
  `agen_hora_fim` time NOT NULL,
  `agen_finalidade` varchar(150) NOT NULL,
  `agen_observacoes` text,
  `agen_participantes` int NOT NULL DEFAULT '0',
  `agen_status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `agen_motivo_recusa` varchar(255) DEFAULT NULL,
  `agen_criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `agen_atualizado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`agen_id`),
  KEY `fk_agendamento_usuario_idx` (`agen_usuario_id`),
  KEY `idx_agendamento_data_hora` (`agen_data`,`agen_hora_inicio`,`agen_hora_fim`),
  CONSTRAINT `fk_agendamento_usuario` FOREIGN KEY (`agen_usuario_id`) REFERENCES `usuario` (`usua_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `alocacao`
-- (equipamentos vinculados a cada agendamento, com a quantidade usada)
--

DROP TABLE IF EXISTS `alocacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alocacao` (
  `aloc_id` int NOT NULL AUTO_INCREMENT,
  `aloc_agendamento_id` int NOT NULL,
  `aloc_equipamento_id` int NOT NULL,
  `aloc_quantidade` int NOT NULL,
  PRIMARY KEY (`aloc_id`),
  UNIQUE KEY `uq_aloc_agen_equip` (`aloc_equipamento_id`,`aloc_agendamento_id`),
  KEY `fk_alocacao_agendamento_idx` (`aloc_agendamento_id`),
  KEY `fk_alocacao_equipamento_idx` (`aloc_equipamento_id`),
  CONSTRAINT `fk_alocacao_agendamento` FOREIGN KEY (`aloc_agendamento_id`) REFERENCES `agendamento` (`agen_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_alocacao_equipamento` FOREIGN KEY (`aloc_equipamento_id`) REFERENCES `equipamento` (`equip_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `mensagem`
-- (formulário de Contato)
--

DROP TABLE IF EXISTS `mensagem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mensagem` (
  `msg_id` int NOT NULL AUTO_INCREMENT,
  `msg_nome` varchar(150) NOT NULL,
  `msg_email` varchar(150) NOT NULL,
  `msg_mensagem` text NOT NULL,
  `msg_status` enum('novo','lido','respondido') NOT NULL DEFAULT 'novo',
  `msg_criado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`msg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump revisado concluído
