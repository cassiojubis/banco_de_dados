<?php
/**
 * acesso.php
 * ---------------------------------------------------------------------
 * Página dedicada à Área do aluno/servidor: login, solicitação de
 * cadastro e "Meus agendamentos". Antes esse bloco ficava empilhado em
 * cima do Calendário (index.php#calendario) — foi movido para cá para
 * não misturar dois assuntos diferentes na mesma seção.
 *
 * Assim como index.php, esta página é pública: qualquer visitante pode
 * abrir o formulário de login ou de solicitação de cadastro. Toda a
 * lógica (sessão do aluno/servidor, validação de senha, "meus
 * agendamentos") continua em assets/js/script.js, guiada pelos mesmos
 * IDs que já existiam.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/config/config.php';

include __DIR__ . '/includes/header.php';
?>
   <section class="py-16 px-4 bg-white min-h-[70vh]">
    <div class="max-w-2xl mx-auto">
     <div class="mb-10">
      <h1 class="text-3xl font-bold text-gray-900 mb-2">Login / Cadastro</h1>
      <p class="text-gray-600">Entre com a matrícula e a senha cadastradas pela coordenação do CIT para agendar a sala e acompanhar seus agendamentos.</p>
     </div>

     <div class="border border-gray-200 rounded-lg p-6" id="area-usuario">

      <!-- Tela inicial: pergunta se a pessoa já tem cadastro -->
      <div id="area-usuario-escolha">
       <p class="text-sm font-semibold text-gray-700 mb-3">Aluno ou servidor</p>
       <div class="flex flex-wrap gap-3">
        <button type="button" onclick="mostrarAreaUsuario('login')" class="px-5 py-2.5 bg-green-700 text-white rounded-md font-semibold hover:bg-green-800 transition-colors">Já tenho cadastro</button>
        <button type="button" onclick="mostrarAreaUsuario('cadastro')" class="px-5 py-2.5 border border-gray-300 text-gray-700 rounded-md font-semibold hover:bg-gray-50 transition-colors">Ainda não tenho cadastro</button>
       </div>
       <!-- Acesso da coordenação (sessão própria, via login.php) fica aqui
            no mesmo lugar, para não haver duas telas de login soltas. -->
       <div class="mt-5 pt-5 border-t border-gray-200">
        <p class="text-sm font-semibold text-gray-700 mb-3">Coordenação do CIT</p>
        <a href="login.php" class="inline-flex items-center gap-2 px-5 py-2.5 border-2 border-green-700 text-green-700 rounded-md font-semibold hover:bg-green-50 transition-colors">Entrar como coordenação →</a>
       </div>
      </div>

      <!-- Formulário de login -->
      <div id="login-usuario-form-wrap" class="hidden">
       <button type="button" onclick="mostrarAreaUsuario('escolha')" class="text-sm text-gray-500 hover:underline mb-4">← Voltar</button>
       <h2 class="font-semibold text-gray-900 mb-1 text-lg">Entrar</h2>
       <p class="text-sm text-gray-600 mb-4">Use a matrícula e a senha cadastradas pela coordenação do CIT.</p>
       <form id="login-usuario-form" onsubmit="handleLoginUsuario(event)" class="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:items-end">
        <div>
         <label for="login-usuario-matricula" class="block text-xs font-semibold text-gray-700 mb-1">Matrícula</label>
         <input id="login-usuario-matricula" type="text" required class="w-full px-3 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
        </div>
        <div>
         <label for="login-usuario-senha" class="block text-xs font-semibold text-gray-700 mb-1">Senha</label>
         <input id="login-usuario-senha" type="password" required class="w-full px-3 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
        </div>
        <button type="submit" class="px-4 py-2.5 bg-green-700 text-white rounded-md font-semibold hover:bg-green-800 transition-colors">Entrar</button>
       </form>
       <button type="button" onclick="mostrarAreaUsuario('esqueci')" class="mt-3 text-sm font-semibold text-green-700 hover:underline">Esqueci minha senha</button>
      </div>

      <!-- Esqueci minha senha: manda um link por e-mail (api/recuperar_senha.php) -->
      <div id="esqueci-senha-form-wrap" class="hidden">
       <button type="button" onclick="mostrarAreaUsuario('login')" class="text-sm text-gray-500 hover:underline mb-4">← Voltar</button>
       <h2 class="font-semibold text-gray-900 mb-1 text-lg">Esqueci minha senha</h2>
       <p class="text-sm text-gray-600 mb-4">Informe sua matrícula ou o e-mail do seu cadastro. Vamos mandar um link para você criar uma senha nova.</p>
       <form id="esqueci-senha-form" onsubmit="handleEsqueciSenha(event)" class="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:items-end">
        <div class="sm:col-span-2">
         <label for="esqueci-identificacao" class="block text-xs font-semibold text-gray-700 mb-1">Matrícula ou e-mail</label>
         <input id="esqueci-identificacao" type="text" required autocomplete="username" class="w-full px-3 py-2.5 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
        </div>
        <button type="submit" id="esqueci-senha-btn" class="px-4 py-2.5 bg-green-700 text-white rounded-md font-semibold hover:bg-green-800 transition-colors">Enviar link</button>
       </form>
       <p id="esqueci-senha-note" class="text-sm text-gray-600 mt-3"></p>
      </div>

      <!-- Formulário de solicitação de cadastro -->
      <div id="cadastro-servidor-form-wrap" class="hidden">
       <button type="button" onclick="mostrarAreaUsuario('escolha')" class="text-sm text-gray-500 hover:underline mb-4">← Voltar</button>
       <h2 class="font-semibold text-gray-900 mb-1 text-lg">Solicitar cadastro</h2>
       <p class="text-sm text-gray-600 mb-4">Seu cadastro fica pendente até o gestor do CIT aceitar.</p>
       <form id="cadastro-servidor-form" onsubmit="handleSolicitarCadastro(event)" class="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
         <label for="solicitar-nome" class="block text-xs font-semibold text-gray-700 mb-1">Nome completo</label>
         <input id="solicitar-nome" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
        </div>
        <div>
         <label for="solicitar-matricula" class="block text-xs font-semibold text-gray-700 mb-1">Matrícula</label>
         <input id="solicitar-matricula" type="text" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
        </div>
        <div class="sm:col-span-2">
         <label for="solicitar-email" class="block text-xs font-semibold text-gray-700 mb-1">E-mail</label>
         <input id="solicitar-email" type="email" required autocomplete="email" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
         <span class="block text-xs text-gray-500 mt-1">É para este e-mail que avisamos quando seu cadastro e seus agendamentos forem aprovados ou recusados.</span>
        </div>
        <div>
         <label for="solicitar-senha" class="block text-xs font-semibold text-gray-700 mb-1">Crie uma senha</label>
         <input id="solicitar-senha" type="password" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
        </div>
        <div>
         <label for="solicitar-senha-confirmar" class="block text-xs font-semibold text-gray-700 mb-1">Confirme a senha</label>
         <input id="solicitar-senha-confirmar" type="password" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600">
        </div>
        <div>
         <label for="solicitar-papel" class="block text-xs font-semibold text-gray-700 mb-1">Você é</label>
         <select id="solicitar-papel" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-600 focus:border-green-600"><option value="aluno">Aluno</option><option value="servidor">Servidor</option></select>
        </div>
        <div class="flex items-end">
         <button type="submit" class="w-full px-4 py-2.5 bg-green-700 text-white rounded-md font-semibold text-sm hover:bg-green-800 transition-colors">Enviar solicitação</button>
        </div>
       </form>
       <p id="solicitar-cadastro-note" class="text-xs text-gray-500 mt-2"></p>
      </div>

      <!-- Área logada: meus agendamentos -->
      <div id="area-usuario-logado" class="hidden">
       <div class="flex flex-wrap items-center justify-between gap-3 mb-5">
        <div>
         <h2 class="font-semibold text-gray-900 text-lg">Olá, <span id="usuario-logado-nome"></span></h2>
         <p class="text-sm text-gray-500" id="usuario-logado-papel"></p>
        </div>
        <button onclick="sairUsuario()" class="px-4 py-2 border border-gray-300 text-gray-700 rounded-md font-semibold text-sm hover:bg-gray-50 transition-colors">Sair</button>
       </div>
       <h3 class="font-semibold text-gray-700 mb-2 text-sm">Meus agendamentos</h3>
       <div id="meus-agendamentos-lista" class="space-y-2">
        <!-- gerado via JS: renderAreaUsuario() -->
       </div>
       <a href="index.php#calendario" class="inline-block mt-5 text-sm font-semibold text-green-700 hover:underline">Ir para o Calendário para agendar →</a>
      </div>

     </div>
    </div>
   </section>
<?php
include __DIR__ . '/includes/footer.php';
