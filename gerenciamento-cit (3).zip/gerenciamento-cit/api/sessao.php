<?php
/**
 * api/sessao.php
 * ---------------------------------------------------------------------
 * Apoio ao limite de 5 minutos de inatividade (config/config.php, seção
 * 1b), usado pelo monitor de inatividade do script.js:
 *
 *   GET    → "ainda estou aqui": a própria requisição já renova o tempo
 *            de inatividade (config.php faz isso em toda requisição).
 *            Devolve quem continua logado, para o navegador perceber se
 *            a sessão já tinha expirado.
 *   DELETE → encerra por inatividade o login de admin e de
 *            aluno/servidor desta sessão.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/_bootstrap.php';

$metodo = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($metodo === 'DELETE') {
    unset(
        $_SESSION['admin_logged_in'], $_SESSION['admin_usuario'], $_SESSION['admin_matricula'],
        $_SESSION['admin_id'], $_SESSION['usuario_id']
    );
    $_SESSION['sessao_expirada'] = true;
    jsonResponse(['ok' => true]);
}

if ($metodo !== 'GET') {
    jsonResponse(['erro' => 'Método não permitido.'], 405);
}

jsonResponse([
    'admin'             => isAuthenticated(),
    'usuario'           => usuarioLogadoId() !== null,
    'limite_segundos'   => SESSAO_INATIVIDADE_SEGUNDOS,
]);
