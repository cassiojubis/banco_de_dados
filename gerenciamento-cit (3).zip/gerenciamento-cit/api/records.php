<?php
/**
 * api/records.php
 * ---------------------------------------------------------------------
 * API única para os 4 tipos de registro do sistema: agendamentos
 * ("booking"), equipamentos ("equipment"), cadastros de aluno/servidor
 * ("usuario_autorizado") e mensagens de contato ("contact").
 *
 * Existe de propósito UM arquivo só, em vez de um por tabela: assim o
 * formato que ele devolve pode continuar IDÊNTICO ao que o
 * assets/js/script.js já usava quando tudo vinha do localStorage (os
 * mesmos nomes de campo: name, condition, photo_url, equipment_type,
 * responsible, purpose, equipment_quantities...) — a mudança real
 * (tabelas de verdade, com chaves e validação) fica escondida atrás
 * desse "tradutor", e o script.js precisou mudar bem menos do que
 * mudaria se cada endpoint devolvesse os nomes de coluna do banco
 * (usua_nome, agen_responsavel etc.) direto.
 *
 * Uso:
 *   GET    api/records.php                          → todos os registros (equivalente ao allRecords de antes)
 *   GET    api/records.php?tipo=equipment            → só equipamentos
 *   GET    api/records.php?tipo=booking&id=5         → um agendamento
 *   GET    api/records.php?tipo=auditoria            → log de auditoria (admin; &acao=... filtra)
 *   GET    api/records.php?tipo=estatisticas         → números dos gráficos de Relatórios (admin)
 *   POST   api/records.php?tipo=equipment            → cria (corpo em JSON)
 *   PUT    api/records.php?tipo=equipment&id=5       → atualiza
 *   PUT    api/records.php?tipo=booking&id=5&acao=aprovar
 *   PUT    api/records.php?tipo=booking&id=5&acao=recusar     (corpo: {"motivo":"..."})
 *   PUT    api/records.php?tipo=booking&id=5&acao=editar      (dono, só pendente; corpo igual ao POST)
 *   PUT    api/records.php?tipo=booking&id=5&acao=cancelar    (dono; corpo: {"motivo":"..."})
 *   PUT    api/records.php?tipo=usuario_autorizado&id=5&acao=aprovar
 *   PUT    api/records.php?tipo=usuario_autorizado&id=5&acao=recusar   (corpo: {"motivo":"..."})
 *   PUT    api/records.php?tipo=usuario_autorizado&id=5&acao=toggle-ativo
 *   PUT    api/records.php?tipo=usuario_autorizado&id=5&acao=redefinir-senha (corpo: {"senha":"..."})
 *   PUT    api/records.php?tipo=usuario_autorizado&id=5&acao=definir-email (corpo: {"email":"..."})
 *   DELETE api/records.php?tipo=equipment&id=5
 *
 * Ações que só a administração pode fazer (cadastrar/editar/remover
 * equipamento, aprovar/recusar/remover agendamento e cadastro) exigem
 * sessão de administrador (exigirAdmin(), em _bootstrap.php) — sem
 * isso, devolvem 401. Isso é mais forte do que o protótipo original,
 * que confiava só no JavaScript escondido (qualquer um podia editar o
 * localStorage direto pelo DevTools).
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/_bootstrap.php';
// Regras de negócio (conflito de horário, horários livres, disponibilidade
// de equipamento, matrícula) — num arquivo à parte para os testes
// automatizados (tests/) poderem usá-las sem executar a API.
require_once __DIR__ . '/../lib/regras-agendamento.php';

// HORARIO_ABERTURA / HORARIO_FECHAMENTO e diaDeFuncionamento() ficam em
// config/config.php (mesma fonte do calendário e do rodapé).

// Valores aceitos por equipamento.equip_situacao (ENUM no schema.sql).
// Conferidos aqui porque o MySQL do XAMPP roda sem modo estrito: um
// valor fora da lista não dá erro, vira texto vazio em silêncio.
const SITUACOES_EQUIPAMENTO = ['Disponível', 'Indisponível', 'Em manutenção'];

$pdo    = pdoOuFalha();
$metodo = $_SERVER['REQUEST_METHOD'];
$tipo   = $_GET['tipo'] ?? null;
$id     = isset($_GET['id']) ? (int) $_GET['id'] : null;
$acao   = $_GET['acao'] ?? null;

// ---------------------------------------------------------------------
// Funções que traduzem uma linha do banco para o formato que o
// script.js já conhece (ver comentário no topo do arquivo).
// ---------------------------------------------------------------------

function mapEquipamento(array $row): array
{
    return [
        'record_type'    => 'equipment',
        '__backendId'    => (string) $row['equip_id'],
        'name'           => $row['equip_nome'],
        'equipment_type' => $row['equip_tipo'],
        'category'       => $row['equip_categoria'],
        'quantity'       => (int) $row['equip_quantidade'],
        'condition'      => $row['equip_situacao'],
        'photo_url'      => $row['equip_foto_url'],
        'codigo'         => $row['equip_codigo'],
        'created_at'     => $row['equip_criado_em'],
        'updated_at'     => $row['equip_atualizado_em'],
    ];
}

function mapUsuario(array $row): array
{
    return [
        'record_type'   => 'usuario_autorizado',
        '__backendId'   => (string) $row['usua_id'],
        'nome'          => $row['usua_nome'],
        'matricula'     => $row['usua_matricula'],
        'email'         => $row['usua_email'] ?? null,
        'papel'         => $row['usua_papel'],
        'ativo'         => (bool) $row['usua_ativo'],
        'aprovacao'     => $row['usua_aprovacao'],
        'motivo_recusa' => $row['usua_motivo_recusa'],
        'created_at'    => $row['usua_criado_em'],
        'updated_at'    => $row['usua_atualizado_em'],
        // usua_senha_hash nunca é devolvida ao cliente.
    ];
}

function mapMensagem(array $row): array
{
    return [
        'record_type' => 'contact',
        '__backendId' => (string) $row['msg_id'],
        'name'        => $row['msg_nome'],
        'email'       => $row['msg_email'],
        'message'     => $row['msg_mensagem'],
        'status'      => $row['msg_status'],
        'created_at'  => $row['msg_criado_em'],
    ];
}

function mapAuditoria(array $row): array
{
    return [
        'record_type' => 'auditoria',
        '__backendId' => (string) $row['log_id'],
        'usuario_id'  => $row['log_usuario_id'] !== null ? (string) $row['log_usuario_id'] : null,
        'usuario'     => $row['log_usuario_nome'],
        'acao'        => $row['log_acao'],
        'entidade'    => $row['log_entidade'],
        'entidade_id' => (string) $row['log_entidade_id'],
        'detalhes'    => $row['log_detalhes'],
        'created_at'  => $row['log_criado_em'],
    ];
}

/**
 * Monta um agendamento no formato do script.js, incluindo os
 * equipamentos alocados (lidos da tabela alocacao) como
 * equipment_requests (texto) e equipment_quantities (JSON) — os dois
 * campos que renderEquipmentColumns()/getEquipmentPairs() já sabem ler.
 */
function mapAgendamento(PDO $pdo, array $row): array
{
    $stmt = $pdo->prepare(
        'SELECT al.aloc_equipamento_id, al.aloc_quantidade, e.equip_nome
           FROM alocacao al
           JOIN equipamento e ON e.equip_id = al.aloc_equipamento_id
          WHERE al.aloc_agendamento_id = ?'
    );
    $stmt->execute([$row['agen_id']]);
    $itens = $stmt->fetchAll();

    $quantidades = [];
    $nomes = [];
    $total = 0;
    foreach ($itens as $item) {
        $quantidade = (int) $item['aloc_quantidade'];
        $quantidades[] = [
            'equipment_id' => (string) $item['aloc_equipamento_id'],
            'name'         => $item['equip_nome'],
            'quantity'     => $quantidade,
        ];
        $nomes[] = $item['equip_nome'];
        $total += $quantidade;
    }

    $inicio = substr((string) $row['agen_hora_inicio'], 0, 5);
    $fim    = substr((string) $row['agen_hora_fim'], 0, 5);

    // Visitante sem login não recebe quem reservou nem as observações —
    // o calendário público só precisa saber que o horário está ocupado
    // ("Reservado"). Aluno/servidor logado e admin continuam vendo.
    $veDadosPessoais = isAuthenticated() || usuarioLogadoId() !== null;

    return [
        'record_type'             => 'booking',
        '__backendId'             => (string) $row['agen_id'],
        'usuario_id'              => $veDadosPessoais && $row['agen_usuario_id'] !== null ? (string) $row['agen_usuario_id'] : null,
        'date'                    => $row['agen_data'],
        'start_time'              => $inicio,
        'end_time'                => $fim,
        'time_slot'               => $inicio . ' - ' . $fim,
        'responsible'             => $veDadosPessoais ? $row['agen_responsavel'] : null,
        'purpose'                 => $row['agen_finalidade'],
        'description'             => $veDadosPessoais ? $row['agen_observacoes'] : '',
        'participants'            => (int) $row['agen_participantes'],
        'equipment_requests'      => implode(', ', $nomes),
        'equipment_quantities'    => json_encode($quantidades, JSON_UNESCAPED_UNICODE),
        'equipment_total_quantity'=> $total,
        // O motivo da recusa só vai para o administrador e para o próprio
        // dono do agendamento — antes ia para qualquer visitante e
        // aparecia na lista pública da página inicial.
        'rejection_reason'        => (isAuthenticated() || ($row['agen_usuario_id'] !== null && (int) $row['agen_usuario_id'] === usuarioLogadoId()))
                                        ? ($row['agen_motivo_recusa'] ?? '')
                                        : '',
        // Motivo do cancelamento (pelo próprio dono): mesma regra de quem vê.
        'cancellation_reason'     => (isAuthenticated() || ($row['agen_usuario_id'] !== null && (int) $row['agen_usuario_id'] === usuarioLogadoId()))
                                        ? ($row['agen_motivo_cancelamento'] ?? '')
                                        : '',
        'status'                  => $row['agen_status'],
        'created_at'              => $row['agen_criado_em'],
        'updated_at'              => $row['agen_atualizado_em'],
    ];
}

// ---------------------------------------------------------------------
// Roteamento
// ---------------------------------------------------------------------

switch ($metodo) {
    case 'GET':
        tratarGet($pdo, $tipo, $id);
        break;
    case 'POST':
        tratarPost($pdo, $tipo);
        break;
    case 'PUT':
        tratarPut($pdo, $tipo, $id, $acao);
        break;
    case 'DELETE':
        tratarDelete($pdo, $tipo, $id);
        break;
    default:
        jsonResponse(['erro' => 'Método não suportado.'], 405);
}

// ---------------------------------------------------------------------
// GET
// ---------------------------------------------------------------------

function tratarGet(PDO $pdo, ?string $tipo, ?int $id): void
{
    if ($tipo === null) {
        // Sem "tipo": devolve tudo, igual ao antigo allRecords.
        $tudo = [];
        foreach ($pdo->query('SELECT * FROM equipamento ORDER BY equip_id') as $row) {
            $tudo[] = mapEquipamento($row);
        }
        foreach ($pdo->query('SELECT * FROM agendamento ORDER BY agen_data, agen_hora_inicio') as $row) {
            $tudo[] = mapAgendamento($pdo, $row);
        }
        // Nome + matrícula de todo aluno/servidor cadastrado só entra na
        // lista para quem está logado como administrador — antes ia para
        // qualquer visitante (mesmo sem login), então bastava chamar a
        // API de fora do site para baixar a matrícula de todo mundo.
        if (isAuthenticated()) {
            $stmtUsuarios = $pdo->query("SELECT * FROM usuario WHERE usua_papel IN ('aluno','servidor') ORDER BY usua_id");
            foreach ($stmtUsuarios as $row) {
                $tudo[] = mapUsuario($row);
            }
        }
        // Mensagens de contato só entram na lista para quem está logado
        // como administrador — contêm e-mail de quem mandou a mensagem.
        if (isAuthenticated()) {
            foreach ($pdo->query('SELECT * FROM mensagem ORDER BY msg_criado_em DESC') as $row) {
                $tudo[] = mapMensagem($row);
            }
        }
        jsonResponse($tudo);
    }

    switch ($tipo) {
        case 'equipment':
            if ($id !== null) {
                $stmt = $pdo->prepare('SELECT * FROM equipamento WHERE equip_id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                jsonResponse($row ? mapEquipamento($row) : ['erro' => 'Equipamento não encontrado.'], $row ? 200 : 404);
            }
            $lista = array_map('mapEquipamento', $pdo->query('SELECT * FROM equipamento ORDER BY equip_id')->fetchAll());
            jsonResponse($lista);

        case 'booking':
            if ($id !== null) {
                $stmt = $pdo->prepare('SELECT * FROM agendamento WHERE agen_id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                jsonResponse($row ? mapAgendamento($pdo, $row) : ['erro' => 'Agendamento não encontrado.'], $row ? 200 : 404);
            }
            $linhas = $pdo->query('SELECT * FROM agendamento ORDER BY agen_data, agen_hora_inicio')->fetchAll();
            jsonResponse(array_map(fn ($linha) => mapAgendamento($pdo, $linha), $linhas));

        case 'usuario_autorizado':
            // Nome, matrícula e situação de cadastro de aluno/servidor só
            // podem ser consultados pela administração — ver comentário
            // equivalente acima, no branch "sem tipo".
            exigirAdmin();
            if ($id !== null) {
                $stmt = $pdo->prepare("SELECT * FROM usuario WHERE usua_id = ? AND usua_papel IN ('aluno','servidor')");
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                jsonResponse($row ? mapUsuario($row) : ['erro' => 'Cadastro não encontrado.'], $row ? 200 : 404);
            }
            $lista = array_map('mapUsuario', $pdo->query("SELECT * FROM usuario WHERE usua_papel IN ('aluno','servidor') ORDER BY usua_id")->fetchAll());
            jsonResponse($lista);

        case 'contact':
            exigirAdmin();
            if ($id !== null) {
                $stmt = $pdo->prepare('SELECT * FROM mensagem WHERE msg_id = ?');
                $stmt->execute([$id]);
                $row = $stmt->fetch();
                jsonResponse($row ? mapMensagem($row) : ['erro' => 'Mensagem não encontrada.'], $row ? 200 : 404);
            }
            $lista = array_map('mapMensagem', $pdo->query('SELECT * FROM mensagem ORDER BY msg_criado_em DESC')->fetchAll());
            jsonResponse($lista);

        case 'auditoria':
            // Últimas entradas do log de auditoria, mais recentes primeiro.
            // ?acao=aprovar_agendamento filtra por um tipo de ação.
            exigirAdmin();
            $acaoFiltro = trim((string) ($_GET['acao'] ?? ''));
            $limite = min(500, max(1, (int) ($_GET['limite'] ?? 200)));
            if ($acaoFiltro !== '') {
                $stmt = $pdo->prepare("SELECT * FROM log_auditoria WHERE log_acao = ? ORDER BY log_id DESC LIMIT {$limite}");
                $stmt->execute([$acaoFiltro]);
            } else {
                $stmt = $pdo->query("SELECT * FROM log_auditoria ORDER BY log_id DESC LIMIT {$limite}");
            }
            jsonResponse(array_map('mapAuditoria', $stmt->fetchAll()));

        case 'estatisticas':
            // Números dos gráficos da aba Relatórios (somente admin).
            exigirAdmin();

            // Agendamentos aprovados por dia da semana, no histórico todo.
            // DAYOFWEEK: 1 = domingo ... 7 = sábado. Devolve sempre os 7 dias
            // (com zero onde não houve uso), na ordem segunda → domingo.
            $porDia = array_fill(1, 7, 0);
            $stmt = $pdo->query("SELECT DAYOFWEEK(agen_data) AS dia, COUNT(*) AS total FROM agendamento WHERE agen_status = 'approved' GROUP BY dia");
            foreach ($stmt as $row) {
                $porDia[(int) $row['dia']] = (int) $row['total'];
            }
            $nomesDias = [2 => 'Segunda', 3 => 'Terça', 4 => 'Quarta', 5 => 'Quinta', 6 => 'Sexta', 7 => 'Sábado', 1 => 'Domingo'];
            $ocupacao = [];
            foreach ($nomesDias as $numero => $nome) {
                $ocupacao[] = ['dia' => $nome, 'total' => $porDia[$numero]];
            }

            // Equipamentos mais pedidos: em quantos agendamentos aparecem (e
            // quantas unidades no total), contando todos os pedidos —
            // aprovados, pendentes e recusados. Os 8 primeiros.
            $equipamentos = array_map(fn ($row) => [
                'nome'      => $row['equip_nome'],
                'pedidos'   => (int) $row['pedidos'],
                'unidades'  => (int) $row['unidades'],
            ], $pdo->query(
                'SELECT e.equip_nome, COUNT(DISTINCT al.aloc_agendamento_id) AS pedidos, SUM(al.aloc_quantidade) AS unidades
                   FROM alocacao al
                   JOIN equipamento e ON e.equip_id = al.aloc_equipamento_id
                  GROUP BY e.equip_id, e.equip_nome
                  ORDER BY pedidos DESC, unidades DESC, e.equip_nome
                  LIMIT 8'
            )->fetchAll());

            // Situação dos agendamentos (aprovados × pendentes × recusados).
            $situacao = ['approved' => 0, 'pending' => 0, 'rejected' => 0, 'cancelled' => 0];
            foreach ($pdo->query('SELECT agen_status, COUNT(*) AS total FROM agendamento GROUP BY agen_status') as $row) {
                $situacao[$row['agen_status']] = (int) $row['total'];
            }

            jsonResponse([
                'ocupacao_por_dia'  => $ocupacao,
                'equipamentos'      => $equipamentos,
                'situacao'          => [
                    'aprovados'  => $situacao['approved'],
                    'pendentes'  => $situacao['pending'],
                    'recusados'  => $situacao['rejected'],
                    'cancelados' => $situacao['cancelled'],
                ],
            ]);

        default:
            jsonResponse(['erro' => 'Tipo de registro desconhecido.'], 400);
    }
}

// ---------------------------------------------------------------------
// POST (criar)
// ---------------------------------------------------------------------

function tratarPost(PDO $pdo, ?string $tipo): void
{
    $dados = jsonInput();

    switch ($tipo) {
        case 'equipment':
            exigirAdmin();
            criarEquipamento($pdo, $dados);

        case 'booking':
            criarAgendamento($pdo, $dados);

        case 'usuario_autorizado':
            criarUsuario($pdo, $dados);

        case 'contact':
            criarMensagem($pdo, $dados);

        default:
            jsonResponse(['erro' => 'Tipo de registro desconhecido.'], 400);
    }
}

function criarEquipamento(PDO $pdo, array $dados): void
{
    $nome = trim((string) ($dados['name'] ?? ''));
    $quantidade = (int) ($dados['quantity'] ?? 0);

    if ($nome === '' || $quantidade < 1) {
        jsonResponse(['erro' => 'Informe o nome e uma quantidade válida.'], 422);
    }
    $situacao = $dados['condition'] ?? 'Disponível';
    if (!in_array($situacao, SITUACOES_EQUIPAMENTO, true)) {
        jsonResponse(['erro' => 'Situação do equipamento inválida.'], 422);
    }

    $codigo = trim((string) ($dados['codigo'] ?? ''));

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO equipamento (equip_codigo, equip_nome, equip_tipo, equip_categoria, equip_quantidade, equip_situacao, equip_foto_url)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $codigo !== '' ? $codigo : null,
            $nome,
            $dados['equipment_type'] ?? null,
            $dados['category'] ?? null,
            $quantidade,
            $situacao,
            $dados['photo_url'] ?? null,
        ]);
    } catch (PDOException $e) {
        // Código 23000 = violação de UNIQUE/chave — nesse caso só pode
        // ser o equip_codigo repetido (é a única UNIQUE da tabela).
        if ($e->getCode() === '23000') {
            jsonResponse(['erro' => 'Já existe um equipamento com esse código.'], 409);
        }
        error_log('[agendacit] Falha ao criar equipamento: ' . $e->getMessage());
        jsonResponse(['erro' => 'Não foi possível cadastrar o equipamento.'], 500);
    }

    $novoId = (int) $pdo->lastInsertId();
    registrarAuditoria($pdo, 'cadastrar_equipamento', 'equipamento', $novoId, "{$nome} ({$quantidade} un., {$situacao})");
    $stmt = $pdo->prepare('SELECT * FROM equipamento WHERE equip_id = ?');
    $stmt->execute([$novoId]);
    jsonResponse(mapEquipamento($stmt->fetch()), 201);
}

/**
 * Lê e valida os dados de um agendamento vindos do formulário (criar ou
 * editar). Responde o erro e encerra se algo não vale; senão devolve os
 * dados já normalizados, com o dono (usuario_id) — null quando é o
 * administrador fazendo uma reserva manual.
 *
 * @return array{data:string,inicio:string,fim:string,responsavel:string,finalidade:string,
 *               participantes:int,observacoes:string,pedidos:array<int,int>,usuario_id:?int}
 */
function lerDadosAgendamento(PDO $pdo, array $dados): array
{
    $data          = trim((string) ($dados['date'] ?? ''));
    $inicio        = trim((string) ($dados['start_time'] ?? ''));
    $fim           = trim((string) ($dados['end_time'] ?? ''));
    $responsavel   = trim((string) ($dados['responsible'] ?? ''));
    $finalidade    = trim((string) ($dados['purpose'] ?? ''));
    $participantes = (int) ($dados['participants'] ?? 0);
    $observacoes   = (string) ($dados['description'] ?? '');
    $equipamentos  = is_array($dados['equipamentos'] ?? null) ? $dados['equipamentos'] : [];

    // Quem pode agendar: administrador logado, OU aluno/servidor logado
    // (sessão PHP criada em api/login_usuario.php — usuarioDaSessao()
    // também confere se o cadastro continua aprovado e ativo). Antes a
    // API aceitava qualquer matrícula enviada no corpo da requisição:
    // bastava saber a matrícula de alguém para agendar no nome dela.
    //
    // Reserva manual do administrador só quando o pedido vem do botão
    // "Novo Agendamento" do painel (reserva_manual = true). Com aluno/
    // servidor logado, o pedido é DELE — mesmo que o admin também esteja
    // logado no mesmo navegador. Antes, nesse caso, o pedido do aluno
    // virava reserva do admin: ficava sem dono (fora de "Meus
    // agendamentos", sem e-mail de aprovação) e pulava as regras do aluno
    // (dava para reservar sábado).
    $usuario = usuarioDaSessao($pdo);
    $reservaDoAdmin = isAuthenticated() && (!empty($dados['reserva_manual']) || !$usuario);
    $usuarioId = null;
    if (!$reservaDoAdmin) {
        if (!$usuario) {
            jsonResponse(['erro' => 'Faça login ou solicite seu cadastro para agendar.'], 401);
        }
        // O responsável é sempre a própria pessoa logada.
        $responsavel = $usuario['usua_nome'];
        $usuarioId = (int) $usuario['usua_id'];
    }

    if ($data === '' || $inicio === '' || $fim === '' || $responsavel === '' || $finalidade === '') {
        jsonResponse(['erro' => 'Preencha data, horário, responsável e finalidade.'], 422);
    }
    // Formato inválido (ex.: "7:00" ou "2026-02-30") antes ia direto
    // para o banco e virava um erro 500 genérico.
    if (!dataValida($data) || !horaValida($inicio) || !horaValida($fim)) {
        jsonResponse(['erro' => 'Data ou horário em formato inválido.'], 422);
    }
    // O calendário já bloqueia dias passados, mas a API aceitava
    // qualquer data se chamada direto.
    if ($data < date('Y-m-d')) {
        jsonResponse(['erro' => 'Não é possível agendar em uma data que já passou.'], 422);
    }
    if ($participantes < 0) {
        jsonResponse(['erro' => 'Número de participantes inválido.'], 422);
    }
    if ($inicio >= $fim) {
        jsonResponse(['erro' => 'O horário de término deve ser posterior ao início.'], 422);
    }
    if (paraMinutos($inicio) < paraMinutos(HORARIO_ABERTURA) || paraMinutos($fim) > paraMinutos(HORARIO_FECHAMENTO)) {
        jsonResponse(['erro' => 'A sala do CIT funciona das ' . HORARIO_ABERTURA . ' às ' . HORARIO_FECHAMENTO . '. Ajuste o horário.'], 422);
    }
    if (!diaDeFuncionamento($data, $reservaDoAdmin)) {
        $diaSemana = (int) date('w', strtotime($data));
        jsonResponse(['erro' => $diaSemana === 0
            ? 'O CIT não funciona aos domingos.'
            : 'Aos sábados o CIT só abre para eventos e atividades combinados com a coordenação. Fale com a coordenação do CIT.'], 422);
    }
    // Hoje, mas num horário que já passou (a checagem de data acima só
    // olhava o dia).
    if ($data === date('Y-m-d') && $inicio < date('H:i')) {
        jsonResponse([
            'erro'             => 'Esse horário de hoje já passou. Escolha um dos horários livres.',
            'horarios_livres'  => horariosLivres($pdo, $data),
        ], 422);
    }

    // Junta pedidos repetidos do mesmo equipamento numa linha só — dois
    // itens com o mesmo equipment_id batiam na UNIQUE de alocacao
    // (uq_aloc_agen_equip) e o agendamento inteiro falhava com erro 500.
    $pedidos = [];
    foreach ($equipamentos as $item) {
        $equipId = (int) ($item['equipment_id'] ?? 0);
        $quantidadePedida = (int) ($item['quantity'] ?? 0);
        if ($equipId < 1 || $quantidadePedida < 1) {
            continue;
        }
        $pedidos[$equipId] = ($pedidos[$equipId] ?? 0) + $quantidadePedida;
    }

    return compact('data', 'inicio', 'fim', 'responsavel', 'finalidade', 'participantes', 'observacoes', 'pedidos')
        + ['usuario_id' => $usuarioId];
}

/**
 * Dentro de uma transação já aberta: confere conflito de horário e a
 * disponibilidade de cada equipamento pedido, com SELECT ... FOR UPDATE
 * (sem isso, duas pessoas clicando "agendar" quase ao mesmo tempo para o
 * mesmo horário — ou para a última unidade de um equipamento — podiam
 * passar as duas pela checagem antes de qualquer uma gravar; com a
 * trava, a segunda espera a primeira terminar e enxerga o conflito).
 * Desfaz a transação e responde o erro se não der; senão devolve os
 * equipamentos validados. $ignorarAgendamentoId: ao editar, o próprio
 * agendamento não conflita consigo mesmo.
 *
 * @return array<array{equip_id:int,quantidade:int}>
 */
function conferirDisponibilidade(PDO $pdo, array $d, ?int $ignorarAgendamentoId = null): array
{
    // Conflito de horário: considera pendentes E aprovados no mesmo dia.
    if (contarConflitosHorario($pdo, $d['data'], $d['inicio'], $d['fim'], true, $ignorarAgendamentoId) > 0) {
        $pdo->rollBack();
        // Junto com o erro, os intervalos livres do mesmo dia — o
        // script.js mostra cada um como botão que já preenche o
        // formulário (sugestão de horário). Ao editar, o horário atual
        // do próprio agendamento também conta como livre para ele.
        $stmt = $pdo->prepare(
            "SELECT LEFT(agen_hora_inicio, 5) AS inicio, LEFT(agen_hora_fim, 5) AS fim FROM agendamento
              WHERE agen_data = ? AND agen_status IN ('pending','approved') AND agen_id != ?"
        );
        $stmt->execute([$d['data'], $ignorarAgendamentoId ?? 0]);
        $ocupados = array_map(fn ($r) => [$r['inicio'], $r['fim']], $stmt->fetchAll());
        $agora = $d['data'] === date('Y-m-d') ? (int) date('G') * 60 + (int) date('i') : null;
        $livres = calcularIntervalosLivres($ocupados, HORARIO_ABERTURA, HORARIO_FECHAMENTO, $agora);
        jsonResponse([
            'erro'            => $livres
                ? 'Já existe um agendamento (aprovado ou pendente) nesse horário. Veja os horários livres desse dia.'
                : 'Já existe um agendamento (aprovado ou pendente) nesse horário, e não sobrou horário livre nesse dia. Escolha outra data.',
            'horarios_livres' => $livres,
        ], 409);
    }

    // Disponibilidade de cada equipamento — a linha do equipamento fica
    // travada (FOR UPDATE) até o commit.
    $itensValidados = [];
    foreach ($d['pedidos'] as $equipId => $quantidadePedida) {
        $stmt = $pdo->prepare('SELECT equip_nome, equip_quantidade, equip_situacao FROM equipamento WHERE equip_id = ? FOR UPDATE');
        $stmt->execute([$equipId]);
        $equip = $stmt->fetch();
        if (!$equip) {
            $pdo->rollBack();
            jsonResponse(['erro' => 'Equipamento selecionado não existe mais.'], 422);
        }
        // O formulário já desabilita equipamento em manutenção ou
        // indisponível, mas a API aceitava se chamada direto.
        if ($equip['equip_situacao'] !== 'Disponível') {
            $pdo->rollBack();
            jsonResponse(['erro' => "{$equip['equip_nome']} está {$equip['equip_situacao']} e não pode ser reservado."], 422);
        }

        $reservado = quantidadeReservada($pdo, $equipId, $d['data'], $d['inicio'], $d['fim'], $ignorarAgendamentoId);
        $disponivel = max(0, (int) $equip['equip_quantidade'] - $reservado);
        if ($quantidadePedida > $disponivel) {
            $pdo->rollBack();
            jsonResponse(['erro' => "A quantidade de {$equip['equip_nome']} não pode ser maior que {$disponivel} unidade(s) disponível(is)."], 422);
        }

        $itensValidados[] = ['equip_id' => $equipId, 'quantidade' => $quantidadePedida];
    }
    return $itensValidados;
}

/** Grava os equipamentos de um agendamento (tabela alocacao). */
function gravarAlocacoes(PDO $pdo, int $agendamentoId, array $itens): void
{
    $stmt = $pdo->prepare('INSERT INTO alocacao (aloc_agendamento_id, aloc_equipamento_id, aloc_quantidade) VALUES (?, ?, ?)');
    foreach ($itens as $item) {
        $stmt->execute([$agendamentoId, $item['equip_id'], $item['quantidade']]);
    }
}

/**
 * O erro do banco é de concorrência? Deadlock (duas gravações no mesmo
 * horário ao mesmo tempo, com o InnoDB escolhendo uma como "vítima") ou
 * espera de trava estourada. Nesses casos vale tentar de novo: na nova
 * tentativa o conflito já está gravado e a pessoa recebe a mensagem
 * certa (409, com os horários livres), em vez de um 500 genérico.
 */
function ehErroDeConcorrencia(Throwable $e): bool
{
    if (!$e instanceof PDOException) {
        return false;
    }
    $sqlState     = (string) $e->getCode();          // 40001 = deadlock
    $codigoDriver = $e->errorInfo[1] ?? null;         // 1213 = deadlock, 1205 = lock wait timeout
    return $sqlState === '40001' || in_array($codigoDriver, [1213, 1205], true);
}

function criarAgendamento(PDO $pdo, array $dados): void
{
    $d = lerDadosAgendamento($pdo, $dados);

    // Até 5 tentativas. Se duas pessoas clicarem "Agendar" no mesmo
    // horário ao mesmo tempo, a trava (FOR UPDATE em conferirDisponibilidade)
    // garante que só uma grave — mas o banco pode derrubar a outra com um
    // deadlock. Em vez de mostrar um erro genérico para ela, tentamos de
    // novo: aí o conflito já está gravado e conferirDisponibilidade
    // devolve a sugestão de horário (409), ou o horário ficou livre.
    $novoId   = null;
    $resposta = null;
    for ($tentativa = 1; ; $tentativa++) {
        $pdo->beginTransaction();
        try {
            $itens = conferirDisponibilidade($pdo, $d);

            $pdo->prepare(
                "INSERT INTO agendamento
                    (agen_usuario_id, agen_responsavel, agen_data, agen_hora_inicio, agen_hora_fim,
                     agen_finalidade, agen_observacoes, agen_participantes, agen_status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')"
            )->execute([$d['usuario_id'], $d['responsavel'], $d['data'], $d['inicio'], $d['fim'],
                        $d['finalidade'], $d['observacoes'], $d['participantes']]);
            $novoId = (int) $pdo->lastInsertId();
            gravarAlocacoes($pdo, $novoId, $itens);

            // Monta a resposta AINDA DENTRO da transação. Se isto falhar, o
            // catch desfaz tudo (rollBack) e responde erro — nunca sobra um
            // agendamento salvo junto com uma resposta de erro, que era o que
            // fazia "aparecer erro mas o agendamento chegar".
            $stmt = $pdo->prepare('SELECT * FROM agendamento WHERE agen_id = ?');
            $stmt->execute([$novoId]);
            $resposta = mapAgendamento($pdo, $stmt->fetch());

            $pdo->commit();
            break;
        } catch (Throwable $e) {
            // conferirDisponibilidade já faz rollBack + resposta 409 quando
            // há conflito (e encerra a requisição ali). Se caímos aqui é
            // outra coisa: desfaz o que estiver aberto e decide se tenta de
            // novo (deadlock) ou desiste.
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            if (ehErroDeConcorrencia($e) && $tentativa < 5) {
                usleep(40000 * $tentativa); // espera curta e crescente
                continue;
            }
            error_log('[agendacit] Falha ao criar agendamento: ' . $e->getMessage());
            jsonResponse(['erro' => 'Não foi possível salvar o agendamento.'], 500);
        }
    }

    // Depois do commit: o log de auditoria nunca desfaz nem bloqueia a
    // ação (registrarAuditoria engole o próprio erro). Reserva manual do
    // administrador (o aluno/servidor agendando o próprio horário não é
    // ação administrativa e não entra no log).
    if ($d['usuario_id'] === null) {
        registrarAuditoria($pdo, 'criar_agendamento', 'agendamento', $novoId, "{$d['responsavel']} — {$d['data']} {$d['inicio']}-{$d['fim']}");
    }

    jsonResponse($resposta, 201);
}

/**
 * Agendamento do aluno/servidor logado, para editar ou cancelar — só o
 * DONO (sessão de api/login_usuario.php) mexe no próprio agendamento.
 * Mesma resposta para "não existe" e "não é seu".
 */
function agendamentoDoDono(PDO $pdo, int $id): array
{
    $usuario = usuarioDaSessao($pdo);
    if (!$usuario && isAuthenticated()) {
        jsonResponse(['erro' => 'Só o próprio aluno/servidor edita ou cancela o agendamento. A coordenação pode recusar ou excluir.'], 403);
    }
    if (!$usuario) {
        jsonResponse(['erro' => 'Sua sessão expirou. Faça login de novo.'], 401);
    }
    $stmt = $pdo->prepare('SELECT * FROM agendamento WHERE agen_id = ? AND agen_usuario_id = ?');
    $stmt->execute([$id, $usuario['usua_id']]);
    $agendamento = $stmt->fetch();
    if (!$agendamento) {
        jsonResponse(['erro' => 'Agendamento não encontrado entre os seus.'], 404);
    }
    return $agendamento + ['__dono' => $usuario];
}

/**
 * O dono edita o próprio agendamento — só enquanto está PENDENTE (depois
 * de aprovado, mudar exigiria nova análise: o caminho é cancelar e pedir
 * outro). Valida tudo de novo, como ao criar; o agendamento continua
 * pendente, aguardando a coordenação.
 */
function editarAgendamentoProprio(PDO $pdo, int $id, array $dados): void
{
    $atual = agendamentoDoDono($pdo, $id);
    if ($atual['agen_status'] !== 'pending') {
        jsonResponse(['erro' => 'Só dá para editar um agendamento enquanto ele está pendente. Se precisar mudar um já aprovado, cancele e faça um novo pedido.'], 409);
    }

    $d = lerDadosAgendamento($pdo, $dados);

    $pdo->beginTransaction();
    try {
        // Trava a própria linha: se a coordenação aprovar/recusar ao mesmo
        // tempo, uma das duas ações espera a outra terminar.
        $stmt = $pdo->prepare('SELECT agen_status FROM agendamento WHERE agen_id = ? FOR UPDATE');
        $stmt->execute([$id]);
        if ($stmt->fetchColumn() !== 'pending') {
            $pdo->rollBack();
            jsonResponse(['erro' => 'Este agendamento acabou de ser analisado pela coordenação e não pode mais ser editado.'], 409);
        }

        $itens = conferirDisponibilidade($pdo, $d, $id);

        $pdo->prepare(
            'UPDATE agendamento
                SET agen_data = ?, agen_hora_inicio = ?, agen_hora_fim = ?, agen_finalidade = ?,
                    agen_observacoes = ?, agen_participantes = ?
              WHERE agen_id = ?'
        )->execute([$d['data'], $d['inicio'], $d['fim'], $d['finalidade'], $d['observacoes'], $d['participantes'], $id]);
        $pdo->prepare('DELETE FROM alocacao WHERE aloc_agendamento_id = ?')->execute([$id]);
        gravarAlocacoes($pdo, $id, $itens);

        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        error_log('[agendacit] Falha ao editar agendamento: ' . $e->getMessage());
        jsonResponse(['erro' => 'Não foi possível salvar as alterações.'], 500);
    }

    $antes = substr($atual['agen_hora_inicio'], 0, 5) . '-' . substr($atual['agen_hora_fim'], 0, 5);
    registrarAuditoria($pdo, 'editar_agendamento', 'agendamento', $id,
        "{$atual['agen_data']} {$antes} → {$d['data']} {$d['inicio']}-{$d['fim']} ({$d['finalidade']})",
        (int) $atual['__dono']['usua_id'], $atual['__dono']['usua_nome']);

    $stmt = $pdo->prepare('SELECT * FROM agendamento WHERE agen_id = ?');
    $stmt->execute([$id]);
    jsonResponse(mapAgendamento($pdo, $stmt->fetch()));
}

/**
 * O dono cancela o próprio agendamento (pendente ou aprovado), com
 * justificativa obrigatória. Antes o cancelamento APAGAVA o agendamento;
 * agora ele fica como 'cancelled', com o motivo, para a coordenação ver
 * — e a sala/os equipamentos voltam a ficar livres (cancelado não segura
 * horário). A coordenação é avisada por e-mail.
 */
function cancelarAgendamentoProprio(PDO $pdo, int $id, array $dados): void
{
    $atual = agendamentoDoDono($pdo, $id);
    if (!in_array($atual['agen_status'], ['pending', 'approved'], true)) {
        jsonResponse(['erro' => 'Este agendamento já foi recusado ou cancelado.'], 409);
    }
    $fimDoAgendamento = $atual['agen_data'] . ' ' . substr($atual['agen_hora_fim'], 0, 5);
    if ($fimDoAgendamento <= date('Y-m-d H:i')) {
        jsonResponse(['erro' => 'Este agendamento já aconteceu e não pode mais ser cancelado.'], 409);
    }

    $motivo = trim((string) ($dados['motivo'] ?? ''));
    if (mb_strlen($motivo) < 5) {
        jsonResponse(['erro' => 'Explique em poucas palavras o motivo do cancelamento.'], 422);
    }
    $motivo = mb_substr($motivo, 0, 255);

    $pdo->prepare(
        "UPDATE agendamento SET agen_status = 'cancelled', agen_motivo_cancelamento = ?
          WHERE agen_id = ? AND agen_status IN ('pending','approved')"
    )->execute([$motivo, $id]);

    $quando = date('d/m/Y', strtotime($atual['agen_data'])) . ' ' . substr($atual['agen_hora_inicio'], 0, 5)
        . '-' . substr($atual['agen_hora_fim'], 0, 5);
    registrarAuditoria($pdo, 'cancelar_agendamento', 'agendamento', $id,
        "{$quando} (" . ($atual['agen_status'] === 'approved' ? 'aprovado' : 'pendente') . ") — motivo: {$motivo}",
        (int) $atual['__dono']['usua_id'], $atual['__dono']['usua_nome']);
    enviarEmailCancelamento($atual['__dono']['usua_nome'], $quando, $atual['agen_finalidade'], $motivo, $atual['agen_status'] === 'approved');

    $stmt = $pdo->prepare('SELECT * FROM agendamento WHERE agen_id = ?');
    $stmt->execute([$id]);
    jsonResponse(mapAgendamento($pdo, $stmt->fetch()));
}

function criarUsuario(PDO $pdo, array $dados): void
{
    $nome      = trim((string) ($dados['nome'] ?? ''));
    $matricula = trim((string) ($dados['matricula'] ?? ''));
    $senha     = (string) ($dados['senha'] ?? '');
    $email     = trim((string) ($dados['email'] ?? ''));
    $papel     = $dados['papel'] ?? 'aluno';
    $origem    = $dados['origem'] ?? 'autocadastro'; // 'admin' | 'autocadastro'

    if ($origem === 'admin') {
        exigirAdmin();
    } else {
        // Autocadastro é público: limita pedidos por IP para ninguém
        // encher a fila de pendentes (e a caixa de e-mail) com cadastros
        // falsos. Uma pessoa de verdade faz 1 pedido.
        limitarRequisicoes('autocadastro', 5, 10 * 60, 'Muitos pedidos de cadastro feitos deste computador.');
    }

    if ($nome === '' || $matricula === '' || $senha === '') {
        jsonResponse(['erro' => 'Informe nome, matrícula e senha.'], 422);
    }
    // E-mail: obrigatório no autocadastro (é por ele que a pessoa fica
    // sabendo se o cadastro e os agendamentos foram aceitos/recusados);
    // opcional quando é o administrador quem cadastra.
    if ($email === '' && $origem !== 'admin') {
        jsonResponse(['erro' => 'Informe seu e-mail — é por ele que você recebe os avisos de aprovação.'], 422);
    }
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['erro' => 'Informe um e-mail válido.'], 422);
    }
    if (!in_array($papel, ['aluno', 'servidor'], true)) {
        jsonResponse(['erro' => 'Papel inválido.'], 422);
    }
    if (mb_strlen($senha) < SENHA_MIN_CARACTERES) {
        jsonResponse(['erro' => 'A senha precisa ter pelo menos ' . SENHA_MIN_CARACTERES . ' caracteres.'], 422);
    }

    $ativo     = $origem === 'admin' ? 1 : 0;
    $aprovacao = $origem === 'admin' ? 'aprovado' : 'pendente';

    $situacao = situacaoMatricula($pdo, $matricula);

    // Matrícula de um cadastro RECUSADO pode ser usada de novo: o pedido
    // antigo é reaproveitado (mesma linha, dados novos) e volta para a
    // fila de pendentes — ou já entra aprovado, se é o administrador
    // cadastrando. Antes o recusado sumia de todas as listas do painel,
    // mas continuava ocupando a matrícula, e ninguém conseguia mais se
    // cadastrar com ela ("Essa matrícula já está cadastrada").
    if ($situacao['acao'] === 'reaproveitar') {
        $pdo->prepare(
            'UPDATE usuario
                SET usua_nome = ?, usua_email = ?, usua_senha_hash = ?, usua_papel = ?,
                    usua_ativo = ?, usua_aprovacao = ?, usua_motivo_recusa = NULL
              WHERE usua_id = ?'
        )->execute([$nome, $email !== '' ? $email : null, password_hash($senha, PASSWORD_DEFAULT), $papel, $ativo, $aprovacao, $situacao['usua_id']]);

        if ($origem === 'admin') {
            registrarAuditoria($pdo, 'cadastrar_usuario', 'usuario', (int) $situacao['usua_id'], "{$nome} (matrícula {$matricula}, {$papel}) — reaproveitou cadastro recusado");
        }

        $stmt = $pdo->prepare('SELECT * FROM usuario WHERE usua_id = ?');
        $stmt->execute([$situacao['usua_id']]);
        jsonResponse(mapUsuario($stmt->fetch()), 201);
    }

    // Qualquer outro caso (pendente, aprovado — ou a matrícula do admin)
    // continua bloqueado.
    if ($situacao['acao'] === 'bloqueada') {
        jsonResponse(['erro' => 'Essa matrícula já está cadastrada.'], 409);
    }

    try {
        $stmt = $pdo->prepare(
            'INSERT INTO usuario (usua_nome, usua_matricula, usua_email, usua_senha_hash, usua_papel, usua_ativo, usua_aprovacao)
             VALUES (?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$nome, $matricula, $email !== '' ? $email : null, password_hash($senha, PASSWORD_DEFAULT), $papel, $ativo, $aprovacao]);
    } catch (PDOException $e) {
        // Código 23000 = violação de UNIQUE (usua_matricula) — acontece
        // quando duas solicitações com a mesma matrícula chegam quase ao
        // mesmo tempo (a checagem SELECT logo acima não pega esse caso;
        // só a UNIQUE do banco pega). Sem este catch, a segunda pessoa
        // via uma tela de erro técnico em vez da mensagem normal.
        if ($e->getCode() === '23000') {
            jsonResponse(['erro' => 'Essa matrícula já está cadastrada.'], 409);
        }
        error_log('[agendacit] Falha ao criar usuário: ' . $e->getMessage());
        jsonResponse(['erro' => 'Não foi possível concluir o cadastro.'], 500);
    }

    $novoId = (int) $pdo->lastInsertId();
    if ($origem === 'admin') {
        registrarAuditoria($pdo, 'cadastrar_usuario', 'usuario', $novoId, "{$nome} (matrícula {$matricula}, {$papel})");
    }
    $stmt = $pdo->prepare('SELECT * FROM usuario WHERE usua_id = ?');
    $stmt->execute([$novoId]);
    jsonResponse(mapUsuario($stmt->fetch()), 201);
}

function criarMensagem(PDO $pdo, array $dados): void
{
    // Formulário de Contato é público e cada envio grava no banco e
    // dispara um e-mail: sem limite, um robô lotaria a caixa da
    // coordenação (e o Gmail poderia bloquear a conta remetente).
    limitarRequisicoes('contato', 5, 10 * 60, 'Muitas mensagens enviadas deste computador.');

    $nome    = trim((string) ($dados['name'] ?? ''));
    $email   = trim((string) ($dados['email'] ?? ''));
    $mensagem = trim((string) ($dados['message'] ?? ''));

    if ($nome === '' || $email === '' || $mensagem === '') {
        jsonResponse(['erro' => 'Preencha nome, e-mail e mensagem.'], 422);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        jsonResponse(['erro' => 'Informe um e-mail válido.'], 422);
    }

    $stmt = $pdo->prepare('INSERT INTO mensagem (msg_nome, msg_email, msg_mensagem) VALUES (?, ?, ?)');
    $stmt->execute([$nome, $email, $mensagem]);

    $novoId = (int) $pdo->lastInsertId();
    $stmt = $pdo->prepare('SELECT * FROM mensagem WHERE msg_id = ?');
    $stmt->execute([$novoId]);

    // A mensagem já está salva no banco a essa altura, então uma falha
    // no envio do e-mail (SMTP fora do ar, credenciais erradas etc.)
    // não deve impedir a resposta de sucesso — ver o try/catch dentro
    // de enviarEmailContato().
    enviarEmailContato($nome, $email, $mensagem);

    jsonResponse(mapMensagem($stmt->fetch()), 201);
}

// ---------------------------------------------------------------------
// PUT (atualizar / ações)
// ---------------------------------------------------------------------

function tratarPut(PDO $pdo, ?string $tipo, ?int $id, ?string $acao): void
{
    if ($id === null) {
        jsonResponse(['erro' => 'Informe o id do registro (?id=).'], 400);
    }
    $dados = jsonInput();

    switch ($tipo) {
        case 'equipment':
            exigirAdmin();
            atualizarEquipamento($pdo, $id, $dados);

        case 'booking':
            // editar/cancelar: o DONO do agendamento (aluno/servidor
            // logado). aprovar/recusar: a administração.
            if ($acao === 'editar') {
                editarAgendamentoProprio($pdo, $id, $dados);
            }
            if ($acao === 'cancelar') {
                cancelarAgendamentoProprio($pdo, $id, $dados);
            }
            atualizarAgendamento($pdo, $id, $acao, $dados);

        case 'usuario_autorizado':
            atualizarUsuario($pdo, $id, $acao, $dados);

        case 'contact':
            exigirAdmin();
            atualizarMensagem($pdo, $id, $dados);

        default:
            jsonResponse(['erro' => 'Tipo de registro desconhecido.'], 400);
    }
}

function atualizarEquipamento(PDO $pdo, int $id, array $dados): void
{
    $stmt = $pdo->prepare('SELECT * FROM equipamento WHERE equip_id = ?');
    $stmt->execute([$id]);
    $atual = $stmt->fetch();
    if (!$atual) {
        jsonResponse(['erro' => 'Equipamento não encontrado.'], 404);
    }

    $nome = trim((string) ($dados['name'] ?? $atual['equip_nome']));
    $quantidade = (int) ($dados['quantity'] ?? $atual['equip_quantidade']);

    if ($nome === '' || $quantidade < 0) {
        jsonResponse(['erro' => 'Informe o nome e uma quantidade válida.'], 422);
    }
    $situacao = $dados['condition'] ?? $atual['equip_situacao'];
    if (!in_array($situacao, SITUACOES_EQUIPAMENTO, true)) {
        jsonResponse(['erro' => 'Situação do equipamento inválida.'], 422);
    }

    // O total não pode ficar abaixo do que já está reservado num mesmo
    // horário em agendamentos aprovados de hoje em diante. Antes somava
    // TODOS os aprovados de todas as datas (inclusive os já passados),
    // então com o tempo ficava impossível diminuir a quantidade.
    // Para cada agendamento aprovado futuro que usa o equipamento, soma
    // o que todos os aprovados sobrepostos a ele usam — e pega o maior.
    $stmt = $pdo->prepare(
        "SELECT COALESCE(MAX(pico), 0) FROM (
            SELECT SUM(al2.aloc_quantidade) AS pico
              FROM agendamento a1
              JOIN alocacao al1 ON al1.aloc_agendamento_id = a1.agen_id AND al1.aloc_equipamento_id = ?
              JOIN agendamento a2 ON a2.agen_data = a1.agen_data
                                 AND a2.agen_status = 'approved'
                                 AND a2.agen_hora_inicio < a1.agen_hora_fim
                                 AND a2.agen_hora_fim > a1.agen_hora_inicio
              JOIN alocacao al2 ON al2.aloc_agendamento_id = a2.agen_id AND al2.aloc_equipamento_id = ?
             WHERE a1.agen_status = 'approved' AND a1.agen_data >= CURDATE()
             GROUP BY a1.agen_id
         ) picos"
    );
    $stmt->execute([$id, $id]);
    $reservado = (int) $stmt->fetchColumn();
    if ($quantidade < $reservado) {
        jsonResponse(['erro' => "A quantidade total não pode ser menor que {$reservado} — já reservada em agendamentos aprovados."], 422);
    }

    $stmt = $pdo->prepare(
        'UPDATE equipamento
            SET equip_nome = ?, equip_tipo = ?, equip_categoria = ?, equip_quantidade = ?,
                equip_situacao = ?, equip_foto_url = ?, equip_codigo = ?
          WHERE equip_id = ?'
    );
    $stmt->execute([
        $nome,
        $dados['equipment_type'] ?? $atual['equip_tipo'],
        $dados['category'] ?? $atual['equip_categoria'],
        $quantidade,
        $situacao,
        array_key_exists('photo_url', $dados) ? $dados['photo_url'] : $atual['equip_foto_url'],
        $atual['equip_codigo'],
        $id,
    ]);

    // Detalhe do log: só o que mudou (ex.: "quantidade: 3 → 5").
    $mudancas = [];
    foreach ([
        'nome'       => [$atual['equip_nome'], $nome],
        'quantidade' => [(int) $atual['equip_quantidade'], $quantidade],
        'situação'   => [$atual['equip_situacao'], $situacao],
    ] as $campo => [$antes, $depois]) {
        if ((string) $antes !== (string) $depois) {
            $mudancas[] = "{$campo}: {$antes} → {$depois}";
        }
    }
    if (array_key_exists('photo_url', $dados) && $dados['photo_url'] !== $atual['equip_foto_url']) {
        $mudancas[] = 'foto alterada';
    }
    registrarAuditoria($pdo, 'editar_equipamento', 'equipamento', $id,
        $nome . ($mudancas ? ' — ' . implode('; ', $mudancas) : ' — sem mudanças nos campos principais'));

    $stmt = $pdo->prepare('SELECT * FROM equipamento WHERE equip_id = ?');
    $stmt->execute([$id]);
    jsonResponse(mapEquipamento($stmt->fetch()));
}

function atualizarAgendamento(PDO $pdo, int $id, ?string $acao, array $dados): void
{
    exigirAdmin(); // aprovar/recusar são sempre ação de administração

    $stmt = $pdo->prepare('SELECT * FROM agendamento WHERE agen_id = ?');
    $stmt->execute([$id]);
    $atual = $stmt->fetch();
    if (!$atual) {
        jsonResponse(['erro' => 'Agendamento não encontrado.'], 404);
    }

    if ($acao === 'aprovar') {
        $stmt = $pdo->prepare(
            "SELECT agen_responsavel, agen_hora_inicio, agen_hora_fim FROM agendamento
              WHERE agen_id != ? AND agen_data = ? AND agen_status = 'approved'
                AND agen_hora_inicio < ? AND agen_hora_fim > ?"
        );
        $stmt->execute([$id, $atual['agen_data'], $atual['agen_hora_fim'], $atual['agen_hora_inicio']]);
        $conflito = $stmt->fetch();
        if ($conflito) {
            $inicio = substr((string) $conflito['agen_hora_inicio'], 0, 5);
            $fim = substr((string) $conflito['agen_hora_fim'], 0, 5);
            jsonResponse(['erro' => "Já existe um agendamento aprovado de {$conflito['agen_responsavel']} nesse mesmo horário ({$inicio}-{$fim}). Recuse um dos dois antes de aprovar este."], 409);
        }

        // Confere de novo os equipamentos: entre o pedido e a aprovação,
        // o administrador pode ter diminuído a quantidade ou colocado o
        // item em manutenção. Antes a aprovação não olhava isso e podia
        // reservar mais unidades do que existem.
        $stmt = $pdo->prepare(
            'SELECT al.aloc_equipamento_id, al.aloc_quantidade, e.equip_nome, e.equip_quantidade, e.equip_situacao
               FROM alocacao al
               JOIN equipamento e ON e.equip_id = al.aloc_equipamento_id
              WHERE al.aloc_agendamento_id = ?'
        );
        $stmt->execute([$id]);
        foreach ($stmt->fetchAll() as $item) {
            if ($item['equip_situacao'] !== 'Disponível') {
                jsonResponse(['erro' => "{$item['equip_nome']} está {$item['equip_situacao']}. Recuse o agendamento ou altere a situação do equipamento antes de aprovar."], 409);
            }
            $reservado = quantidadeReservada($pdo, (int) $item['aloc_equipamento_id'], $atual['agen_data'], $atual['agen_hora_inicio'], $atual['agen_hora_fim'], $id);
            $disponivel = max(0, (int) $item['equip_quantidade'] - $reservado);
            if ((int) $item['aloc_quantidade'] > $disponivel) {
                jsonResponse(['erro' => "Este agendamento pede {$item['aloc_quantidade']} unidade(s) de {$item['equip_nome']}, mas só há {$disponivel} disponível(is) nesse horário."], 409);
            }
        }

        $pdo->prepare("UPDATE agendamento SET agen_status = 'approved' WHERE agen_id = ?")->execute([$id]);
    } elseif ($acao === 'recusar') {
        $motivo = trim((string) ($dados['motivo'] ?? ''));
        if ($motivo === '') {
            jsonResponse(['erro' => 'Informe o motivo da recusa.'], 422);
        }
        $pdo->prepare("UPDATE agendamento SET agen_status = 'rejected', agen_motivo_recusa = ? WHERE agen_id = ?")
            ->execute([$motivo, $id]);
    } else {
        jsonResponse(['erro' => 'Ação inválida. Use acao=aprovar ou acao=recusar.'], 400);
    }

    $stmt = $pdo->prepare('SELECT * FROM agendamento WHERE agen_id = ?');
    $stmt->execute([$id]);
    $agendamento = $stmt->fetch();

    $resumo = $agendamento['agen_responsavel'] . ' — ' . $agendamento['agen_data'] . ' '
        . substr((string) $agendamento['agen_hora_inicio'], 0, 5) . '-' . substr((string) $agendamento['agen_hora_fim'], 0, 5);
    registrarAuditoria($pdo, $acao === 'aprovar' ? 'aprovar_agendamento' : 'recusar_agendamento', 'agendamento', $id,
        $acao === 'aprovar' ? $resumo : "{$resumo} — motivo: {$agendamento['agen_motivo_recusa']}");

    // Avisa por e-mail quem fez o agendamento (se ele tem e-mail
    // cadastrado). Reservas manuais do administrador não têm usuário
    // vinculado (agen_usuario_id NULL) e não geram aviso.
    if ($agendamento['agen_usuario_id'] !== null) {
        $stmt = $pdo->prepare('SELECT usua_nome, usua_email FROM usuario WHERE usua_id = ?');
        $stmt->execute([$agendamento['agen_usuario_id']]);
        $dono = $stmt->fetch();
        if ($dono && !empty($dono['usua_email'])) {
            enviarEmailStatusAgendamento($dono['usua_email'], $dono['usua_nome'], $agendamento);
        }
    }

    jsonResponse(mapAgendamento($pdo, $agendamento));
}

function atualizarUsuario(PDO $pdo, int $id, ?string $acao, array $dados): void
{
    exigirAdmin(); // toda ação sobre cadastro (aprovar/recusar/ativo/senha) é da administração

    $stmt = $pdo->prepare("SELECT * FROM usuario WHERE usua_id = ? AND usua_papel IN ('aluno','servidor')");
    $stmt->execute([$id]);
    $atual = $stmt->fetch();
    if (!$atual) {
        jsonResponse(['erro' => 'Cadastro não encontrado.'], 404);
    }

    switch ($acao) {
        case 'aprovar':
            $pdo->prepare("UPDATE usuario SET usua_aprovacao = 'aprovado', usua_ativo = 1 WHERE usua_id = ?")->execute([$id]);
            if (!empty($atual['usua_email']) && $atual['usua_aprovacao'] !== 'aprovado') {
                enviarEmailStatusCadastro($atual['usua_email'], $atual['usua_nome'], true);
            }
            break;

        case 'recusar':
            // Recusar é uma atualização (mantém o histórico e o motivo),
            // não uma exclusão do cadastro. A matrícula fica livre para
            // um novo pedido (ver criarUsuario()).
            $motivo = trim((string) ($dados['motivo'] ?? ''));
            if ($motivo === '') {
                jsonResponse(['erro' => 'Informe o motivo da recusa.'], 422);
            }
            $pdo->prepare("UPDATE usuario SET usua_aprovacao = 'recusado', usua_ativo = 0, usua_motivo_recusa = ? WHERE usua_id = ?")
                ->execute([$motivo, $id]);
            if (!empty($atual['usua_email'])) {
                enviarEmailStatusCadastro($atual['usua_email'], $atual['usua_nome'], false, $motivo);
            }
            break;

        case 'definir-email':
            // Para o administrador preencher/corrigir o e-mail de quem foi
            // cadastrado antes de o campo existir. Vazio = apagar.
            $email = trim((string) ($dados['email'] ?? ''));
            if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                jsonResponse(['erro' => 'Informe um e-mail válido.'], 422);
            }
            $pdo->prepare('UPDATE usuario SET usua_email = ? WHERE usua_id = ?')
                ->execute([$email !== '' ? $email : null, $id]);
            break;

        case 'toggle-ativo':
            $novoAtivo = $atual['usua_ativo'] ? 0 : 1;
            $pdo->prepare('UPDATE usuario SET usua_ativo = ? WHERE usua_id = ?')->execute([$novoAtivo, $id]);
            break;

        case 'redefinir-senha':
            $senha = (string) ($dados['senha'] ?? '');
            if (mb_strlen($senha) < SENHA_MIN_CARACTERES) {
                jsonResponse(['erro' => 'A nova senha precisa ter pelo menos ' . SENHA_MIN_CARACTERES . ' caracteres.'], 422);
            }
            $pdo->prepare('UPDATE usuario SET usua_senha_hash = ? WHERE usua_id = ?')
                ->execute([password_hash($senha, PASSWORD_DEFAULT), $id]);
            break;

        default:
            jsonResponse(['erro' => 'Ação inválida.'], 400);
    }

    // Log de auditoria (a senha nova nunca vai para o log, só o fato).
    $quem = "{$atual['usua_nome']} (matrícula {$atual['usua_matricula']})";
    [$acaoLog, $detalhe] = match ($acao) {
        'aprovar'         => ['aprovar_cadastro', $quem],
        'recusar'         => ['recusar_cadastro', "{$quem} — motivo: {$motivo}"],
        'toggle-ativo'    => [$novoAtivo ? 'ativar_usuario' : 'desativar_usuario', $quem],
        'redefinir-senha' => ['redefinir_senha', $quem],
        'definir-email'   => ['definir_email', "{$quem} — " . ($email !== '' ? $email : 'e-mail apagado')],
    };
    registrarAuditoria($pdo, $acaoLog, 'usuario', $id, $detalhe);

    $stmt = $pdo->prepare('SELECT * FROM usuario WHERE usua_id = ?');
    $stmt->execute([$id]);
    jsonResponse(mapUsuario($stmt->fetch()));
}

function atualizarMensagem(PDO $pdo, int $id, array $dados): void
{
    $status = $dados['status'] ?? null;
    if (!in_array($status, ['novo', 'lido', 'respondido'], true)) {
        jsonResponse(['erro' => 'Status inválido.'], 422);
    }
    $stmt = $pdo->prepare('UPDATE mensagem SET msg_status = ? WHERE msg_id = ?');
    $stmt->execute([$status, $id]);
    if ($stmt->rowCount() > 0) {
        registrarAuditoria($pdo, 'atualizar_mensagem', 'mensagem', $id, "status: {$status}");
    }

    $stmt = $pdo->prepare('SELECT * FROM mensagem WHERE msg_id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    jsonResponse($row ? mapMensagem($row) : ['erro' => 'Mensagem não encontrada.'], $row ? 200 : 404);
}

// ---------------------------------------------------------------------
// DELETE
// ---------------------------------------------------------------------

function tratarDelete(PDO $pdo, ?string $tipo, ?int $id): void
{
    if ($id === null) {
        jsonResponse(['erro' => 'Informe o id do registro (?id=).'], 400);
    }

    // Aluno/servidor não apaga agendamento: cancela o próprio, com
    // justificativa, por PUT ?tipo=booking&id=&acao=cancelar — o registro
    // continua existindo (situação "cancelado"), para a coordenação ver.
    if ($tipo === 'booking' && !isAuthenticated()) {
        jsonResponse(['erro' => 'Para cancelar o seu agendamento, use a opção Cancelar e informe o motivo.'], 400);
    }

    exigirAdmin(); // toda outra exclusão continua sendo ação de administração

    $tabelas = [
        'equipment'           => ['equipamento', 'equip_id'],
        'booking'             => ['agendamento', 'agen_id'],
        'usuario_autorizado'  => ['usuario', 'usua_id'],
        'contact'             => ['mensagem', 'msg_id'],
    ];

    if (!isset($tabelas[$tipo])) {
        jsonResponse(['erro' => 'Tipo de registro desconhecido.'], 400);
    }

    [$tabela, $coluna] = $tabelas[$tipo];
    // Pela API só se removem cadastros de aluno/servidor — antes um id
    // qualquer apagava também a conta de administrador (inclusive a
    // única existente, travando o acesso à área administrativa).
    $filtroExtra = $tipo === 'usuario_autorizado' ? " AND usua_papel IN ('aluno','servidor')" : '';

    // Descrição do que vai ser apagado, para o log — depois do DELETE o
    // registro não existe mais para consultar.
    $descricoes = [
        'equipment'          => "SELECT CONCAT(equip_nome, ' (', equip_quantidade, ' un.)') FROM equipamento WHERE equip_id = ?",
        'booking'            => "SELECT CONCAT(agen_responsavel, ' — ', agen_data, ' ', LEFT(agen_hora_inicio, 5), '-', LEFT(agen_hora_fim, 5)) FROM agendamento WHERE agen_id = ?",
        'usuario_autorizado' => "SELECT CONCAT(usua_nome, ' (matrícula ', usua_matricula, ')') FROM usuario WHERE usua_id = ?",
        'contact'            => "SELECT CONCAT('mensagem de ', msg_nome, ' <', msg_email, '>') FROM mensagem WHERE msg_id = ?",
    ];
    $stmtDescricao = $pdo->prepare($descricoes[$tipo]);
    $stmtDescricao->execute([$id]);
    $descricao = $stmtDescricao->fetchColumn();

    $stmt = $pdo->prepare("DELETE FROM {$tabela} WHERE {$coluna} = ?{$filtroExtra}");
    $stmt->execute([$id]);

    if ($stmt->rowCount() > 0) {
        $entidades = ['equipment' => 'equipamento', 'booking' => 'agendamento', 'usuario_autorizado' => 'usuario', 'contact' => 'mensagem'];
        registrarAuditoria($pdo, 'remover_' . $entidades[$tipo], $entidades[$tipo], $id, $descricao !== false ? (string) $descricao : null);
    }

    jsonResponse(['ok' => true, 'removido' => $stmt->rowCount() > 0]);
}

