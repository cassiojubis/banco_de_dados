<?php
/**
 * api/docs.php
 * ---------------------------------------------------------------------
 * Documentação interativa da API (Swagger UI), lida de docs/openapi.yaml
 * (OpenAPI 3.0). Somente administrador — sem login, vai para login.php.
 *
 * A pasta docs/ é bloqueada para a web (.htaccess), então esta página
 * também entrega o próprio YAML (?spec=1), depois de conferir o login.
 * O Swagger UI vem do CDN jsdelivr. O "Try it out" chama a API de
 * verdade, com o cookie de sessão do admin logado — cuidado com
 * POST/PUT/DELETE: mexem nos dados reais.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/../config/config.php';

requireLogin('../login.php');

if (isset($_GET['spec'])) {
    header('Content-Type: application/yaml; charset=utf-8');
    readfile(PROJECT_ROOT . '/docs/openapi.yaml');
    exit;
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Documentação da API · <?= e(SITE_TITLE) ?></title>
<link rel="icon" type="image/png" href="../<?= e(assetVersion('assets/img/favicon.png')) ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.17.14/swagger-ui.css">
<style>
  body { margin: 0; background: #fafafa; font-family: system-ui, -apple-system, "Segoe UI", sans-serif; }
  .topo { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; padding: 12px 20px; background: #14532d; color: #fff; }
  .topo img { width: 40px; height: 40px; }
  .topo a { color: #bbf7d0; margin-left: auto; font-weight: 600; }
  .aviso { margin: 0; padding: 10px 20px; background: #fef3c7; color: #78350f; font-size: 14px; }
</style>
</head>
<body>
  <div class="topo">
    <img src="../<?= e(assetVersion('assets/img/logo-agendacit.png')) ?>" alt="">
    <strong>Documentação da API — <?= e(SITE_TITLE) ?></strong>
    <a href="../index.php#admin">← Voltar ao painel</a>
  </div>
  <p class="aviso">⚠️ O botão <strong>Try it out</strong> chama a API de verdade, logado como você: criar, editar e apagar aqui mexe nos dados reais.</p>
  <div id="swagger-ui"></div>
  <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.17.14/swagger-ui-bundle.js"></script>
  <script>
    window.ui = SwaggerUIBundle({
      url: 'docs.php?spec=1',
      dom_id: '#swagger-ui',
      deepLinking: true,
      docExpansion: 'list',
      defaultModelsExpandDepth: 0,
      // Envia o cookie de sessão nas chamadas do "Try it out".
      requestInterceptor: (req) => { req.credentials = 'same-origin'; return req; }
    });
  </script>
</body>
</html>
