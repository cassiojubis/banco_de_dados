<?php
/**
 * api/_bootstrap.php
 * ---------------------------------------------------------------------
 * Arquivo comum a todos os endpoints JSON da API (records.php,
 * login_usuario.php, recuperar_senha.php, sessao.php): conecta no banco,
 * define o cabeçalho JSON, aplica o limite de requisições por IP
 * (config/rate-limit.php) e reúne as funções auxiliares de
 * entrada/saída/autorização.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/mail-helpers.php';
require_once __DIR__ . '/../config/rate-limit.php';

header('Content-Type: application/json; charset=utf-8');

/**
 * Conta a requisição no balde e, se o IP passou do limite, encerra com
 * 429 Too Many Requests (com o cabeçalho Retry-After, em segundos).
 */
function limitarRequisicoes(string $balde, int $maximo, int $janelaSegundos, string $mensagem): void
{
    $espera = registrarRequisicao($balde, $maximo, $janelaSegundos);
    if ($espera > 0) {
        header('Retry-After: ' . $espera);
        http_response_code(429);
        echo json_encode(['erro' => $mensagem . ' Tente novamente em ' . tempoDeEspera($espera) . '.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// Limite geral de toda a API: 60 requisições por minuto por IP. Uso
// normal fica bem abaixo (a página aberta consulta novidades 4 vezes
// por minuto); só um robô ou um script em loop chega lá.
limitarRequisicoes('api', 60, 60, 'Muitas requisições seguidas deste computador.');

/**
 * Lê e decodifica o corpo JSON da requisição (POST/PUT). Devolve um
 * array vazio se não houver corpo ou se o JSON for inválido.
 */
function jsonInput(): array
{
    $bruto = file_get_contents('php://input');
    if ($bruto === '' || $bruto === false) {
        return [];
    }
    $dados = json_decode($bruto, true);
    return is_array($dados) ? $dados : [];
}

/**
 * Envia uma resposta JSON e encerra o script. Use sempre este helper
 * (em vez de echo + exit soltos) para toda resposta da API.
 */
function jsonResponse($dados, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Devolve a conexão PDO ou encerra a requisição com erro 500 caso o
 * banco não esteja configurado/disponível (schema.sql não rodado,
 * MySQL fora do ar, credenciais erradas em config/database.php).
 */
function pdoOuFalha(): PDO
{
    $pdo = getPDO();
    if (!$pdo) {
        jsonResponse(['erro' => 'Não foi possível conectar ao banco de dados. Confira se o MySQL está rodando e se database/schema.sql foi executado.'], 500);
    }
    return $pdo;
}

/**
 * Bloqueia a requisição (401) caso não haja uma sessão de administrador
 * válida. Use no início de toda ação restrita à área administrativa
 * (cadastrar/editar/remover equipamento, aprovar/recusar agendamento e
 * cadastro, etc.) — o mesmo isAuthenticated() que protege index.php.
 */
function exigirAdmin(): void
{
    if (!isAuthenticated()) {
        jsonResponse(['erro' => 'Ação restrita à administração. Faça login como administrador.'], 401);
    }
}

/**
 * Devolve a linha da tabela usuario do aluno/servidor logado nesta
 * sessão (ver api/login_usuario.php), ou null se ninguém estiver logado
 * ou se o cadastro deixou de valer (recusado, desativado ou removido
 * depois do login) — nesse caso a sessão também é encerrada.
 */
function usuarioDaSessao(PDO $pdo): ?array
{
    $id = usuarioLogadoId();
    if ($id === null) {
        return null;
    }
    $stmt = $pdo->prepare(
        "SELECT * FROM usuario
          WHERE usua_id = ? AND usua_papel IN ('aluno','servidor')
            AND usua_aprovacao = 'aprovado' AND usua_ativo = 1"
    );
    $stmt->execute([$id]);
    $usuario = $stmt->fetch();
    if (!$usuario) {
        unset($_SESSION['usuario_id']);
        return null;
    }
    return $usuario;
}

/**
 * Registra no log de auditoria (tabela log_auditoria) uma ação feita
 * pelo administrador logado (ou pelo aluno/servidor, sobre o próprio
 * agendamento) — quem fez, o quê, em qual registro e
 * quando. Chamada depois que a mudança já foi gravada; o nome do admin
 * é copiado para a linha do log para continuar aparecendo mesmo se a
 * conta for apagada depois (log_usuario_id vira NULL nesse caso).
 *
 * Uma falha ao gravar o log não desfaz nem bloqueia a ação principal
 * (que já aconteceu) — só vai para o log de erros do servidor.
 */
function registrarAuditoria(PDO $pdo, string $acao, string $entidade, int $entidadeId, ?string $detalhes = null,
                            ?int $autorId = null, ?string $autorNome = null): void
{
    // Quem fez: o admin logado — ou, nas ações do próprio aluno/servidor
    // sobre o agendamento dele (editar, cancelar), o autor informado.
    try {
        $pdo->prepare(
            'INSERT INTO log_auditoria (log_usuario_id, log_usuario_nome, log_acao, log_entidade, log_entidade_id, log_detalhes)
             VALUES (?, ?, ?, ?, ?, ?)'
        )->execute([
            $autorId ?? (isset($_SESSION['admin_id']) ? (int) $_SESSION['admin_id'] : null),
            $autorNome ?? (string) ($_SESSION['admin_usuario'] ?? 'Administrador'),
            $acao,
            $entidade,
            $entidadeId,
            $detalhes !== null && $detalhes !== '' ? mb_substr($detalhes, 0, 2000) : null,
        ]);
    } catch (PDOException $e) {
        error_log('[agendacit] Falha ao gravar auditoria (' . $acao . '): ' . $e->getMessage());
    }
}
