<?php
/**
 * api/exportar-ics.php
 * ---------------------------------------------------------------------
 * "Adicionar ao calendário": devolve um arquivo .ics (iCalendar, RFC
 * 5545) com um agendamento APROVADO, para importar no Google Agenda,
 * Outlook ou no calendário do celular. Uso: ?id=<agen_id>.
 *
 * Quem pode baixar: o administrador (qualquer agendamento) ou o
 * aluno/servidor dono do agendamento (sessão de api/login_usuario.php).
 * Pendente ou recusado não é compromisso confirmado e não é exportado.
 *
 * Não usa biblioteca — o formato é texto simples. Detalhes do padrão
 * que importam: linhas terminadas em CRLF; vírgula, ponto e vírgula,
 * barra invertida e quebra de linha escapados nos textos; linhas com
 * mais de 75 bytes "dobradas" (continuação começando com espaço); e o
 * horário convertido para UTC (sufixo Z), que todo calendário entende
 * sem precisar de definição de fuso.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

/** Responde um erro em texto simples (é um download, não JSON). */
function erroIcs(int $status, string $mensagem): void
{
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    echo $mensagem;
    exit;
}

/** Escapa um valor TEXT do iCalendar (RFC 5545, 3.3.11). */
function textoIcs(string $texto): string
{
    $texto = str_replace(['\\', ';', ',', "\r\n", "\r", "\n"], ['\\\\', '\\;', '\\,', '\n', '\n', '\n'], $texto);
    return $texto;
}

/** Dobra linhas com mais de 75 bytes, sem cortar caractere UTF-8 no meio. */
function dobrarLinhaIcs(string $linha): string
{
    $partes = [];
    while (strlen($linha) > 75) {
        $corte = 75;
        // Não corta no meio de um caractere de vários bytes (bytes 10xxxxxx).
        while ($corte > 0 && (ord($linha[$corte]) & 0xC0) === 0x80) {
            $corte--;
        }
        $partes[] = substr($linha, 0, $corte);
        $linha = ' ' . substr($linha, $corte);
    }
    $partes[] = $linha;
    return implode("\r\n", $partes);
}

$id = (int) ($_GET['id'] ?? 0);
if ($id < 1) {
    erroIcs(400, 'Informe o agendamento (?id=).');
}

$pdo = getPDO();
if (!$pdo) {
    erroIcs(500, 'Não foi possível conectar ao banco de dados. Tente novamente em alguns minutos.');
}

$stmt = $pdo->prepare(
    "SELECT a.*, GROUP_CONCAT(CONCAT(e.equip_nome, ' (', al.aloc_quantidade, ')') ORDER BY e.equip_nome SEPARATOR ', ') AS equipamentos
       FROM agendamento a
       LEFT JOIN alocacao al ON al.aloc_agendamento_id = a.agen_id
       LEFT JOIN equipamento e ON e.equip_id = al.aloc_equipamento_id
      WHERE a.agen_id = ?
      GROUP BY a.agen_id"
);
$stmt->execute([$id]);
$agendamento = $stmt->fetch();

// Mesma resposta para "não existe" e "não é seu": não revela quais
// agendamentos existem para quem não tem acesso a eles.
$ehDono = $agendamento && $agendamento['agen_usuario_id'] !== null
    && usuarioLogadoId() !== null && (int) $agendamento['agen_usuario_id'] === usuarioLogadoId();
if (!$agendamento || (!isAuthenticated() && !$ehDono)) {
    erroIcs(404, 'Agendamento não encontrado. Se ele é seu, entre na sua conta e tente de novo.');
}
if ($agendamento['agen_status'] !== 'approved') {
    erroIcs(409, 'Só agendamentos aprovados podem ser adicionados ao calendário.');
}

// Horário local do CIT (config.php fixa America/Porto_Velho) → UTC.
$utc = new DateTimeZone('UTC');
$inicio = (new DateTime($agendamento['agen_data'] . ' ' . $agendamento['agen_hora_inicio']))->setTimezone($utc);
$fim    = (new DateTime($agendamento['agen_data'] . ' ' . $agendamento['agen_hora_fim']))->setTimezone($utc);

$descricao = 'Finalidade: ' . $agendamento['agen_finalidade']
    . "\nResponsável: " . $agendamento['agen_responsavel']
    . ((int) $agendamento['agen_participantes'] > 0 ? "\nParticipantes: " . (int) $agendamento['agen_participantes'] : '')
    . ($agendamento['equipamentos'] ? "\nEquipamentos: " . $agendamento['equipamentos'] : '')
    . "\n\n" . SITE_TITLE . ' — ' . INSTITUTION_NAME;

$linhas = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//' . INSTITUTION_NAME . '//AgendaCIT//PT-BR',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    // UID estável: importar o mesmo agendamento de novo atualiza o
    // evento em vez de duplicar.
    'UID:agendamento-' . $id . '@agendacit',
    'DTSTAMP:' . gmdate('Ymd\THis\Z'),
    'DTSTART:' . $inicio->format('Ymd\THis\Z'),
    'DTEND:' . $fim->format('Ymd\THis\Z'),
    'SUMMARY:' . textoIcs('Sala do CIT — ' . $agendamento['agen_finalidade']),
    'LOCATION:' . textoIcs('Sala do CIT — ' . INSTITUTION_NAME),
    'DESCRIPTION:' . textoIcs($descricao),
    'STATUS:CONFIRMED',
    'BEGIN:VALARM',
    'ACTION:DISPLAY',
    'DESCRIPTION:' . textoIcs('Agendamento na Sala do CIT em 30 minutos'),
    'TRIGGER:-PT30M',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
];

header('Content-Type: text/calendar; charset=utf-8');
header('Content-Disposition: attachment; filename="agendamento-cit-' . $agendamento['agen_data'] . '.ics"');
echo implode("\r\n", array_map('dobrarLinhaIcs', $linhas)) . "\r\n";
