<?php
/**
 * api/recuperar_senha.php
 * ---------------------------------------------------------------------
 * "Esqueci minha senha" do aluno/servidor. Recebe POST { identificacao }
 * (matrícula OU e-mail) e, se existir um cadastro aprovado e ativo com
 * e-mail, gera um código de uso único, guarda só o hash dele na tabela
 * senha_reset e manda por e-mail o link para redefinir-senha.php.
 *
 * A resposta é SEMPRE a mesma mensagem, exista ou não o cadastro — senão
 * esta tela viraria um jeito de descobrir quais matrículas/e-mails estão
 * cadastrados. Pedidos seguidos são limitados (por sessão e por usuário)
 * para ninguém usar o formulário para encher a caixa de e-mail de outra
 * pessoa.
 *
 * O administrador não usa este fluxo (não tem e-mail cadastrado); a
 * senha dele continua sendo trocada direto no banco.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/_bootstrap.php';

const RESET_VALIDADE_MINUTOS = 30;
const RESET_INTERVALO_MINIMO_SEGUNDOS = 60; // entre dois e-mails para a mesma pessoa

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    jsonResponse(['erro' => 'Método não permitido. Use POST.'], 405);
}

$respostaPadrao = [
    'ok'       => true,
    'mensagem' => 'Se houver um cadastro ativo com esses dados e e-mail registrado, enviamos um link para redefinir a senha. '
        . 'Confira sua caixa de entrada (e o spam). O link vale por ' . RESET_VALIDADE_MINUTOS . ' minutos. '
        . 'Se você não cadastrou e-mail, procure a coordenação do CIT.',
];

// Limite por IP: 5 pedidos a cada 10 minutos. O da sessão, logo abaixo,
// um robô contorna descartando o cookie; este não.
limitarRequisicoes('recuperacao', 5, 10 * 60, 'Muitos pedidos de recuperação de senha deste computador.');

// Cada pedido conta como "tentativa": 5 seguidos bloqueiam por 60 s.
if (loginBloqueado('recuperacao')) {
    jsonResponse(['erro' => 'Muitos pedidos seguidos. Tente novamente em ' . loginSegundosRestantes('recuperacao') . ' segundos.'], 429);
}
registrarTentativaFalha('recuperacao');

$identificacao = trim((string) (jsonInput()['identificacao'] ?? ''));
if ($identificacao === '') {
    jsonResponse(['erro' => 'Informe sua matrícula ou seu e-mail.'], 422);
}

$pdo = pdoOuFalha();

$stmt = $pdo->prepare(
    "SELECT usua_id, usua_nome, usua_email FROM usuario
      WHERE (usua_matricula = ? OR usua_email = ?)
        AND usua_papel IN ('aluno','servidor')
        AND usua_aprovacao = 'aprovado' AND usua_ativo = 1
        AND usua_email IS NOT NULL AND usua_email <> ''
      LIMIT 1"
);
$stmt->execute([$identificacao, $identificacao]);
$usuario = $stmt->fetch();

if (!$usuario) {
    jsonResponse($respostaPadrao);
}

// Já mandamos um link para essa pessoa há menos de 1 minuto: não manda
// outro (a resposta continua igual).
$stmt = $pdo->prepare(
    'SELECT COUNT(*) FROM senha_reset
      WHERE rese_usuario_id = ? AND rese_criado_em > (NOW() - INTERVAL ? SECOND)'
);
$stmt->execute([$usuario['usua_id'], RESET_INTERVALO_MINIMO_SEGUNDOS]);
if ((int) $stmt->fetchColumn() > 0) {
    jsonResponse($respostaPadrao);
}

// Só o pedido mais recente vale: os anteriores ainda não usados deixam
// de funcionar.
$pdo->prepare('UPDATE senha_reset SET rese_usado_em = NOW() WHERE rese_usuario_id = ? AND rese_usado_em IS NULL')
    ->execute([$usuario['usua_id']]);

$token = bin2hex(random_bytes(32));
$pdo->prepare(
    'INSERT INTO senha_reset (rese_usuario_id, rese_token_hash, rese_expira_em)
     VALUES (?, ?, NOW() + INTERVAL ? MINUTE)'
)->execute([$usuario['usua_id'], hash('sha256', $token), RESET_VALIDADE_MINUTOS]);

$link = rtrim(SITE_URL, '/') . '/redefinir-senha.php?token=' . $token;
if (!enviarEmailRecuperacaoSenha($usuario['usua_email'], $usuario['usua_nome'], $link, RESET_VALIDADE_MINUTOS)) {
    error_log('[agendacit] Pedido de recuperação de senha do usuário ' . $usuario['usua_id'] . ' não pôde ser enviado por e-mail.');
}

jsonResponse($respostaPadrao);
