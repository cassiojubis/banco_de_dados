<?php
/**
 * api/exportar-pdf.php
 * ---------------------------------------------------------------------
 * Relatório de Uso em PDF (somente administrador): os mesmos dados da aba
 * Histórico do painel — agendamentos APROVADOS, com data, horário,
 * responsável, finalidade, participantes e equipamentos —, em ordem
 * cronológica, com cabeçalho (logo, nome do sistema e da instituição),
 * período, resumo e data de geração.
 *
 * Não faz parte da API JSON: devolve o arquivo PDF direto (download).
 * Aceita os mesmos filtros da aba Histórico:
 *   ?mes=AAAA-MM      → só aquele mês
 *   ?data=AAAA-MM-DD  → só aquele dia
 *
 * Gerado com a biblioteca dompdf (vendor/dompdf/, embutida no projeto
 * sem Composer, como o PHPMailer). A logo vai em JPG
 * (assets/img/logo-agendacit-relatorio.jpg) porque a extensão GD do PHP
 * vem desligada no XAMPP e o dompdf precisaria dela para PNG com
 * transparência.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../vendor/dompdf/autoload.inc.php';

use Dompdf\Dompdf;
use Dompdf\Options;

requireLogin('../login.php');

$pdo = getPDO();
if (!$pdo) {
    http_response_code(500);
    exit('Não foi possível conectar ao banco de dados. Tente novamente em alguns minutos.');
}

// Filtros (mesmos da aba Histórico). Valores fora do formato são ignorados.
$mes  = preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', (string) ($_GET['mes'] ?? '')) ? $_GET['mes'] : '';
$data = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string) ($_GET['data'] ?? '')) ? $_GET['data'] : '';

$condicoes = ["a.agen_status = 'approved'"];
$parametros = [];
if ($mes !== '') {
    $condicoes[] = "DATE_FORMAT(a.agen_data, '%Y-%m') = ?";
    $parametros[] = $mes;
}
if ($data !== '') {
    $condicoes[] = 'a.agen_data = ?';
    $parametros[] = $data;
}

$stmt = $pdo->prepare(
    "SELECT a.agen_data, a.agen_hora_inicio, a.agen_hora_fim, a.agen_responsavel, a.agen_finalidade,
            a.agen_participantes,
            GROUP_CONCAT(CONCAT(e.equip_nome, ' (', al.aloc_quantidade, ')') ORDER BY e.equip_nome SEPARATOR ', ') AS equipamentos
       FROM agendamento a
       LEFT JOIN alocacao al ON al.aloc_agendamento_id = a.agen_id
       LEFT JOIN equipamento e ON e.equip_id = al.aloc_equipamento_id
      WHERE " . implode(' AND ', $condicoes) . "
      GROUP BY a.agen_id
      ORDER BY a.agen_data, a.agen_hora_inicio"
);
$stmt->execute($parametros);
$linhas = $stmt->fetchAll();

// Resumo: quantidade de usos, horas de sala e participantes.
$totalMinutos = 0;
$totalParticipantes = 0;
foreach ($linhas as $l) {
    [$hi, $mi] = array_map('intval', explode(':', $l['agen_hora_inicio']));
    [$hf, $mf] = array_map('intval', explode(':', $l['agen_hora_fim']));
    $totalMinutos += ($hf * 60 + $mf) - ($hi * 60 + $mi);
    $totalParticipantes += (int) $l['agen_participantes'];
}

$meses = ['', 'janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
if ($data !== '') {
    $periodo = 'Dia ' . date('d/m/Y', strtotime($data));
} elseif ($mes !== '') {
    [$ano, $m] = explode('-', $mes);
    $periodo = ucfirst($meses[(int) $m]) . " de {$ano}";
} else {
    $periodo = 'Todo o histórico';
}

// Logo embutida no próprio HTML (data URI): o dompdf não precisa buscar
// nenhum arquivo nem endereço externo.
$logo = 'data:image/jpeg;base64,' . base64_encode((string) file_get_contents(PROJECT_ROOT . '/assets/img/logo-agendacit-relatorio.jpg'));

ob_start();
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<style>
  @page { margin: 22mm 14mm 18mm 14mm; }
  body { font-family: "DejaVu Sans", sans-serif; font-size: 9.5pt; color: #1f2937; }
  .cabecalho { border-bottom: 2px solid #15803d; padding-bottom: 8px; margin-bottom: 12px; }
  .cabecalho td { vertical-align: middle; }
  .logo { width: 62px; height: 62px; }
  h1 { font-size: 15pt; margin: 0; color: #14532d; }
  .sub { color: #4b5563; margin-top: 2px; }
  .meta { text-align: right; color: #4b5563; font-size: 8.5pt; }
  .resumo { width: 100%; margin: 0 0 12px; border-collapse: separate; border-spacing: 6px 0; }
  .resumo td { background: #f0fdf4; border: 1px solid #bbf7d0; padding: 6px 8px; width: 33%; }
  .resumo .valor { font-size: 14pt; font-weight: bold; color: #14532d; }
  .resumo .rotulo { font-size: 8pt; color: #4b5563; }
  table.dados { width: 100%; border-collapse: collapse; }
  table.dados th { background: #15803d; color: #fff; text-align: left; padding: 5px 6px; font-size: 8.5pt; }
  table.dados td { padding: 5px 6px; border-bottom: 1px solid #e5e7eb; vertical-align: top; }
  table.dados tr:nth-child(even) td { background: #f9fafb; }
  .num { text-align: right; white-space: nowrap; }
  .nowrap { white-space: nowrap; }
  .vazio { text-align: center; color: #6b7280; padding: 24px; border: 1px dashed #d1d5db; }
</style>
</head>
<body>
  <table class="cabecalho" width="100%">
    <tr>
      <td width="72"><img class="logo" src="<?= $logo ?>" alt=""></td>
      <td>
        <h1>Sistema de Agendamento CIT — Relatório de Uso</h1>
        <div class="sub"><?= e(INSTITUTION_NAME) ?></div>
        <div class="sub"><strong>Período:</strong> <?= e($periodo) ?></div>
      </td>
      <td class="meta" width="150">
        Gerado em <?= date('d/m/Y \à\s H:i') ?><br>
        por <?= e((string) ($_SESSION['admin_usuario'] ?? 'Administrador')) ?>
      </td>
    </tr>
  </table>

  <table class="resumo">
    <tr>
      <td><div class="valor"><?= count($linhas) ?></div><div class="rotulo">uso<?= count($linhas) !== 1 ? 's' : '' ?> da sala (agendamentos aprovados)</div></td>
      <td><div class="valor"><?= intdiv($totalMinutos, 60) ?>h<?= $totalMinutos % 60 ? sprintf('%02d', $totalMinutos % 60) : '' ?></div><div class="rotulo">de sala reservada</div></td>
      <td><div class="valor"><?= $totalParticipantes ?></div><div class="rotulo">participantes no total</div></td>
    </tr>
  </table>

  <?php if (!$linhas): ?>
    <div class="vazio">Nenhum agendamento aprovado no período selecionado.</div>
  <?php else: ?>
    <table class="dados">
      <thead>
        <tr><th>Data</th><th>Horário</th><th>Responsável</th><th>Finalidade</th><th class="num">Partic.</th><th>Equipamentos</th></tr>
      </thead>
      <tbody>
      <?php foreach ($linhas as $l): ?>
        <tr>
          <td class="nowrap"><?= date('d/m/Y', strtotime($l['agen_data'])) ?></td>
          <td class="nowrap"><?= substr($l['agen_hora_inicio'], 0, 5) ?>–<?= substr($l['agen_hora_fim'], 0, 5) ?></td>
          <td><?= e($l['agen_responsavel']) ?></td>
          <td><?= e($l['agen_finalidade']) ?></td>
          <td class="num"><?= (int) $l['agen_participantes'] ?></td>
          <td><?= $l['equipamentos'] !== null ? e($l['equipamentos']) : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  <?php endif; ?>
</body>
</html>
<?php
$html = ob_get_clean();

$opcoes = new Options();
$opcoes->set('isRemoteEnabled', false);   // nada de buscar arquivos/URLs de fora
$opcoes->set('defaultFont', 'DejaVu Sans'); // fonte com acentos (ç, ã, é...)
$opcoes->set('chroot', PROJECT_ROOT);

$dompdf = new Dompdf($opcoes);
$dompdf->loadHtml($html, 'UTF-8');
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Rodapé com número da página em todas as folhas.
$canvas = $dompdf->getCanvas();
$fonte = $dompdf->getFontMetrics()->getFont('DejaVu Sans');
$canvas->page_text(
    $canvas->get_width() - 110, $canvas->get_height() - 32,
    'Página {PAGE_NUM} de {PAGE_COUNT}', $fonte, 8, [0.42, 0.45, 0.5]
);
$canvas->page_text(40, $canvas->get_height() - 32, SITE_TITLE, $fonte, 8, [0.42, 0.45, 0.5]);

$sufixo = $data !== '' ? $data : ($mes !== '' ? $mes : 'completo');
$dompdf->stream("relatorio-uso-cit-{$sufixo}.pdf", ['Attachment' => true]);
