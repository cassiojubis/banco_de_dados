<?php
/**
 * api/login_usuario.php
 * ---------------------------------------------------------------------
 * Sessão de aluno/servidor (não-admin), validada contra a tabela
 * usuario real.
 *
 *   POST   { matricula, senha } → faz login: grava o usuário na sessão
 *          PHP ($_SESSION['usuario_id']) e devolve { nome, matricula,
 *          papel, backendId } — o mesmo formato que script.js guarda em
 *          localStorage (CHAVE_USUARIO_LOGADO) só para exibir na tela.
 *   GET    → devolve o usuário logado nesta sessão (401 se não houver),
 *          usado pelo script.js para descartar um localStorage antigo
 *          quando a sessão do servidor já expirou.
 *   DELETE → encerra a sessão do aluno/servidor (botão "Sair").
 *
 * A sessão PHP é o que vale para a API (api/records.php): agendar e
 * cancelar o próprio agendamento usam usuarioLogadoId(), nunca uma
 * matrícula enviada pelo navegador.
 *
 * Só autentica usuários com usua_papel IN ('aluno','servidor'),
 * usua_aprovacao = 'aprovado' e usua_ativo = 1 — administradores
 * continuam usando login.php, e cadastros pendentes/recusados ou
 * desativados não conseguem entrar. Tentativas erradas seguidas
 * bloqueiam o login por um tempo (loginBloqueado('usuario'), em
 * config/config.php).
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/_bootstrap.php';

$metodo = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($metodo === 'DELETE') {
    unset($_SESSION['usuario_id']);
    jsonResponse(['ok' => true]);
}

$pdo = pdoOuFalha();

if ($metodo === 'GET') {
    $usuario = usuarioDaSessao($pdo);
    if (!$usuario) {
        $expirou = !empty($_SESSION['sessao_expirada']);
        unset($_SESSION['sessao_expirada']);
        jsonResponse(['erro' => 'Nenhum aluno/servidor logado.', 'expirada' => $expirou], 401);
    }
    jsonResponse(dadosPublicosUsuario($usuario));
}

if ($metodo !== 'POST') {
    jsonResponse(['erro' => 'Método não permitido.'], 405);
}

// Limite por IP (10 tentativas a cada 5 minutos). O bloqueio da sessão
// logo abaixo pode ser contornado por um robô que descarta o cookie a
// cada tentativa; este não.
limitarRequisicoes('login', 10, 5 * 60, 'Muitas tentativas de login deste computador.');

if (loginBloqueado('usuario')) {
    jsonResponse(['erro' => 'Muitas tentativas incorretas. Tente novamente em ' . loginSegundosRestantes('usuario') . ' segundos.'], 429);
}

$dados = jsonInput();

$matricula = trim((string) ($dados['matricula'] ?? ''));
$senha     = (string) ($dados['senha'] ?? '');

if ($matricula === '' || $senha === '') {
    jsonResponse(['erro' => 'Informe matrícula e senha.'], 400);
}

$stmt = $pdo->prepare(
    'SELECT usua_id, usua_nome, usua_matricula, usua_senha_hash, usua_papel,
            usua_aprovacao, usua_ativo
       FROM usuario
      WHERE usua_matricula = ?
        AND usua_papel IN (\'aluno\', \'servidor\')
      LIMIT 1'
);
$stmt->execute([$matricula]);
$usuario = $stmt->fetch();

if (!$usuario || !password_verify($senha, $usuario['usua_senha_hash'])) {
    registrarTentativaFalha('usuario');
    jsonResponse(['erro' => loginBloqueado('usuario')
        ? 'Muitas tentativas incorretas. Tente novamente em ' . loginSegundosRestantes('usuario') . ' segundos.'
        : 'Matrícula ou senha inválidos.'], 401);
}

limparTentativasLogin('usuario');

if ($usuario['usua_aprovacao'] !== 'aprovado') {
    $motivoTexto = $usuario['usua_aprovacao'] === 'recusado'
        ? 'Seu cadastro foi recusado pela administração.'
        : 'Seu cadastro ainda está aguardando aprovação da administração.';
    jsonResponse(['erro' => $motivoTexto], 403);
}

if ((int) $usuario['usua_ativo'] !== 1) {
    jsonResponse(['erro' => 'Este cadastro está desativado. Procure a administração do CIT.'], 403);
}

// Renova o ID de sessão (evita session fixation), igual ao login.php.
session_regenerate_id(true);
$_SESSION['usuario_id'] = (int) $usuario['usua_id'];
unset($_SESSION['sessao_expirada']);

jsonResponse(dadosPublicosUsuario($usuario));

/** Só os campos que o navegador precisa — nunca o hash da senha. */
function dadosPublicosUsuario(array $usuario): array
{
    return [
        'nome'      => $usuario['usua_nome'],
        'matricula' => $usuario['usua_matricula'],
        'papel'     => $usuario['usua_papel'],
        'backendId' => (int) $usuario['usua_id'],
    ];
}
