<?php
/**
 * acessibilidade.php
 * ---------------------------------------------------------------------
 * Página de Acessibilidade: tamanho da fonte, modo escuro e idioma.
 * As preferências ficam salvas no localStorage do navegador (ver
 * assets/js/acessibilidade.js) e valem para o site inteiro, não só
 * para esta página.
 * ---------------------------------------------------------------------
 */

require_once __DIR__ . '/config/config.php';

include __DIR__ . '/includes/header.php';
?>
   <section class="py-16 px-4 bg-white min-h-[70vh]">
    <div class="max-w-2xl mx-auto">
     <div class="mb-10">
      <h1 class="text-4xl font-bold text-gray-900 mb-3">Acessibilidade</h1>
      <p class="text-lg text-gray-600">Ajuste o tamanho do texto, ative o modo escuro ou traduza o site. As escolhas aqui valem para todas as páginas.</p>
     </div>

     <div class="space-y-6">

      <!-- Tamanho da fonte -->
      <div class="border border-gray-200 rounded-lg p-6">
       <h2 class="text-xl font-semibold text-gray-900 mb-1">Tamanho da fonte</h2>
       <p class="text-base text-gray-600 mb-4">Aumenta ou diminui o texto de todo o site.</p>
       <div class="flex flex-wrap items-center gap-3">
        <button type="button" onclick="diminuirFonte()" aria-label="Diminuir fonte" class="w-11 h-11 flex items-center justify-center border border-gray-300 rounded-md font-bold text-lg hover:bg-gray-50">A-</button>
        <span id="fonte-nivel-atual" class="min-w-[4.5rem] text-center text-xl font-bold text-gray-800">100%</span>
        <button type="button" onclick="aumentarFonte()" aria-label="Aumentar fonte" class="w-11 h-11 flex items-center justify-center border border-gray-300 rounded-md font-bold text-lg hover:bg-gray-50">A+</button>
        <button type="button" onclick="restaurarFonte()" class="px-4 py-2.5 border border-gray-300 rounded-md text-base font-semibold text-gray-700 hover:bg-gray-50">Restaurar padrão</button>
       </div>
      </div>

      <!-- Modo escuro -->
      <div class="border border-gray-200 rounded-lg p-6">
       <div class="flex items-center justify-between gap-4">
        <div>
         <h2 class="text-xl font-semibold text-gray-900 mb-1">Modo escuro</h2>
         <p class="text-base text-gray-600">Reduz o brilho da tela, útil em ambientes com pouca luz.</p>
        </div>
        <label class="interruptor">
         <input type="checkbox" id="toggle-modo-escuro" onchange="alternarModoEscuro()">
         <span class="trilho"></span>
        </label>
       </div>
      </div>

      <!-- Idioma -->
      <div class="border border-gray-200 rounded-lg p-6">
       <h2 class="text-xl font-semibold text-gray-900 mb-1">Idioma</h2>
       <p class="text-base text-gray-600 mb-4">Traduz o conteúdo do site automaticamente, usando o Google Tradutor. A tradução é automática e pode não ser perfeita em todos os trechos.</p>
       <div class="flex flex-wrap gap-3">
        <button type="button" data-idioma="pt" onclick="definirIdioma('pt')" class="px-4 py-2.5 border border-gray-300 rounded-md font-semibold text-base hover:bg-gray-50">Português</button>
        <button type="button" data-idioma="en" onclick="definirIdioma('en')" class="px-4 py-2.5 border border-gray-300 rounded-md font-semibold text-base hover:bg-gray-50">English</button>
        <button type="button" data-idioma="es" onclick="definirIdioma('es')" class="px-4 py-2.5 border border-gray-300 rounded-md font-semibold text-base hover:bg-gray-50">Español</button>
       </div>
      </div>

     </div>
    </div>
   </section>
<?php
include __DIR__ . '/includes/footer.php';
