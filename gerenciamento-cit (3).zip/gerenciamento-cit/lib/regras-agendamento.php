<?php
/**
 * lib/regras-agendamento.php
 * ---------------------------------------------------------------------
 * Regras de negócio do agendamento, separadas da API para poderem ser
 * testadas (tests/, PHPUnit): api/records.php executa a API assim que é
 * carregado (lê a requisição, responde e encerra), então um teste não
 * consegue incluí-lo. Aqui só há funções — nada roda ao incluir.
 *
 * Usado por api/records.php e pelos testes automatizados. As funções que
 * consultam o banco recebem o PDO por parâmetro (os testes passam a
 * conexão do banco de teste, agendacit_test).
 *
 * Horários são strings "HH:MM" (sempre com dois dígitos, como vêm do
 * formulário e do banco). Um intervalo [início, fim) inclui o início e
 * exclui o fim: uma reserva até 10:00 não conflita com outra que começa
 * às 10:00.
 * ---------------------------------------------------------------------
 */

/** Converte "HH:MM" em minutos desde 00:00. */
function paraMinutos(string $hhmm): int
{
    [$h, $m] = array_map('intval', explode(':', $hhmm));
    return $h * 60 + $m;
}

/** Converte minutos desde 00:00 em "HH:MM". */
function paraHHMM(int $minutos): string
{
    return sprintf('%02d:%02d', intdiv($minutos, 60), $minutos % 60);
}

/** true se $data é uma data real no formato AAAA-MM-DD. */
function dataValida(string $data): bool
{
    $d = DateTime::createFromFormat('!Y-m-d', $data);
    return $d !== false && $d->format('Y-m-d') === $data;
}

/** true se $hora está no formato HH:MM (00:00 a 23:59). */
function horaValida(string $hora): bool
{
    return (bool) preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $hora);
}

/**
 * Se dois intervalos de horário se sobrepõem — a regra de conflito da
 * sala: basta os períodos se cruzarem (não precisa ser o mesmo horário
 * exato). Encostar (um termina quando o outro começa) não é conflito.
 */
function intervalosSeSobrepoem(string $inicio1, string $fim1, string $inicio2, string $fim2): bool
{
    return paraMinutos($inicio1) < paraMinutos($fim2) && paraMinutos($inicio2) < paraMinutos($fim1);
}

/**
 * Quantos agendamentos (aprovados OU pendentes — um pedido pendente já
 * segura o horário) se sobrepõem a [$inicio, $fim) no dia. Com $travar,
 * usa SELECT ... FOR UPDATE (precisa estar dentro de uma transação): a
 * segunda de duas requisições simultâneas espera a primeira terminar e
 * então enxerga o conflito, em vez de as duas gravarem.
 * Recusados e cancelados não seguram horário. $ignorarAgendamentoId
 * deixa de fora o próprio agendamento (ao editar, ele não pode
 * conflitar consigo mesmo).
 */
function contarConflitosHorario(PDO $pdo, string $data, string $inicio, string $fim, bool $travar = false, ?int $ignorarAgendamentoId = null): int
{
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM agendamento
          WHERE agen_data = ?
            AND agen_status IN ('pending','approved')
            AND agen_hora_inicio < ?
            AND agen_hora_fim > ?
            AND agen_id != ?"
        . ($travar ? ' FOR UPDATE' : '')
    );
    $stmt->execute([$data, $fim, $inicio, $ignorarAgendamentoId ?? 0]);
    return (int) $stmt->fetchColumn();
}

/**
 * Intervalos livres de um dia, a partir dos intervalos ocupados — função
 * pura (sem banco), usada por horariosLivres() e testada direto.
 *
 * @param array<array{0:string,1:string}> $ocupados  pares [início, fim] em "HH:MM", em qualquer ordem
 * @param int|null $agoraMinutos  se informado (data = hoje), o que já passou não entra
 *                               (arredondado para os próximos 5 minutos)
 * @return array<array{inicio:string,fim:string}>
 */
function calcularIntervalosLivres(array $ocupados, string $abertura, string $fechamento, ?int $agoraMinutos = null): array
{
    $cursor = paraMinutos($abertura);
    $limite = paraMinutos($fechamento);
    if ($agoraMinutos !== null) {
        $cursor = max($cursor, (int) ceil($agoraMinutos / 5) * 5);
    }

    usort($ocupados, fn ($a, $b) => paraMinutos($a[0]) <=> paraMinutos($b[0]));

    $livres = [];
    foreach ($ocupados as [$inicioOcupado, $fimOcupado]) {
        $inicio = paraMinutos($inicioOcupado);
        if ($inicio > $cursor) {
            $livres[] = ['inicio' => paraHHMM($cursor), 'fim' => paraHHMM(min($inicio, $limite))];
        }
        $cursor = max($cursor, paraMinutos($fimOcupado));
    }
    if ($cursor < $limite) {
        $livres[] = ['inicio' => paraHHMM($cursor), 'fim' => paraHHMM($limite)];
    }
    return array_values(array_filter($livres, fn ($l) => $l['inicio'] < $l['fim']));
}

/**
 * Intervalos livres da sala num dia, dentro do horário de funcionamento,
 * considerando os agendamentos aprovados E pendentes (mesma regra de
 * contarConflitosHorario). Se a data é hoje, o que já passou não entra.
 * $abertura/$fechamento usam HORARIO_ABERTURA/HORARIO_FECHAMENTO
 * (config/config.php) quando não informados.
 *
 * @return array<array{inicio:string,fim:string}>
 */
function horariosLivres(PDO $pdo, string $data, ?string $abertura = null, ?string $fechamento = null): array
{
    $stmt = $pdo->prepare(
        "SELECT LEFT(agen_hora_inicio, 5) AS inicio, LEFT(agen_hora_fim, 5) AS fim FROM agendamento
          WHERE agen_data = ? AND agen_status IN ('pending','approved')"
    );
    $stmt->execute([$data]);
    $ocupados = array_map(fn ($r) => [$r['inicio'], $r['fim']], $stmt->fetchAll(PDO::FETCH_ASSOC));

    $agora = $data === date('Y-m-d') ? (int) date('G') * 60 + (int) date('i') : null;
    return calcularIntervalosLivres($ocupados, $abertura ?? HORARIO_ABERTURA, $fechamento ?? HORARIO_FECHAMENTO, $agora);
}

/**
 * Quantas unidades de um equipamento já estão reservadas por
 * agendamentos APROVADOS no mesmo dia e com horário sobreposto a
 * [$inicio, $fim). Só conta o mesmo dia e horário sobreposto — antes a
 * conta somava todos os aprovados de todas as datas e, com o tempo, o
 * equipamento aparecia como esgotado para sempre. $ignorarAgendamentoId
 * deixa de fora o próprio agendamento (usado ao aprovar).
 */
function quantidadeReservada(PDO $pdo, int $equipId, string $data, string $inicio, string $fim, ?int $ignorarAgendamentoId = null): int
{
    $stmt = $pdo->prepare(
        "SELECT COALESCE(SUM(al.aloc_quantidade), 0)
           FROM alocacao al
           JOIN agendamento a ON a.agen_id = al.aloc_agendamento_id
          WHERE al.aloc_equipamento_id = ?
            AND a.agen_status = 'approved'
            AND a.agen_data = ?
            AND a.agen_hora_inicio < ?
            AND a.agen_hora_fim > ?
            AND a.agen_id != ?"
    );
    $stmt->execute([$equipId, $data, $fim, $inicio, $ignorarAgendamentoId ?? 0]);
    return (int) $stmt->fetchColumn();
}

/**
 * Unidades de um equipamento livres em [$inicio, $fim) no dia: total
 * cadastrado menos o que está reservado em aprovados sobrepostos (nunca
 * negativo). Equipamento inexistente = 0.
 */
function disponibilidadeEquipamento(PDO $pdo, int $equipId, string $data, string $inicio, string $fim, ?int $ignorarAgendamentoId = null): int
{
    $stmt = $pdo->prepare('SELECT equip_quantidade FROM equipamento WHERE equip_id = ?');
    $stmt->execute([$equipId]);
    $total = $stmt->fetchColumn();
    if ($total === false) {
        return 0;
    }
    return max(0, (int) $total - quantidadeReservada($pdo, $equipId, $data, $inicio, $fim, $ignorarAgendamentoId));
}

/**
 * O que fazer com um pedido de cadastro para esta matrícula:
 *   'nova'        → matrícula livre, pode cadastrar;
 *   'reaproveitar'→ existe um cadastro de aluno/servidor RECUSADO com ela:
 *                   reaproveita a mesma linha (volta para a fila);
 *   'bloqueada'   → já em uso (pendente, aprovado — ou é a do admin).
 *
 * @return array{acao:string,usua_id:int|null}
 */
function situacaoMatricula(PDO $pdo, string $matricula): array
{
    $stmt = $pdo->prepare('SELECT usua_id, usua_papel, usua_aprovacao FROM usuario WHERE usua_matricula = ?');
    $stmt->execute([$matricula]);
    $existente = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$existente) {
        return ['acao' => 'nova', 'usua_id' => null];
    }
    if (in_array($existente['usua_papel'], ['aluno', 'servidor'], true) && $existente['usua_aprovacao'] === 'recusado') {
        return ['acao' => 'reaproveitar', 'usua_id' => (int) $existente['usua_id']];
    }
    return ['acao' => 'bloqueada', 'usua_id' => (int) $existente['usua_id']];
}
