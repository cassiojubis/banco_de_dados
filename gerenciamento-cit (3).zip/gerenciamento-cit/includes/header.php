<?php
/**
 * includes/header.php
 * ---------------------------------------------------------------------
 * Cabeçalho comum a todas as páginas restritas do sistema: metadados
 * do documento, folha de estilos e barra de navegação superior.
 *
 * Pressupõe que config.php já foi incluído (usa e(), INSTITUTION_NAME,
 * SITE_TITLE e $_SESSION['admin_usuario']) e que requireLogin() já foi
 * chamado pela página que faz o include.
 * ---------------------------------------------------------------------
 */
?>
<!doctype html>
<html lang="pt-BR" class="h-full">
 <head><meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e(SITE_TITLE) ?> IFRO</title>
  <link rel="icon" type="image/png" href="<?= e(assetVersion('assets/img/favicon.png')) ?>">
  <link rel="stylesheet" href="<?= e(assetVersion('assets/css/tailwind-local.css')) ?>">
  <!-- Fonte de sistema como fallback: evita bloqueio de renderização por Google Fonts. -->
  <link rel="stylesheet" href="<?= e(assetVersion('assets/css/style.css')) ?>">
  <link rel="stylesheet" href="<?= e(assetVersion('assets/css/acessibilidade.css')) ?>">
  <script>
    // Aplica fonte/modo escuro salvos ANTES da página desenhar, para
    // não piscar a versão clara/tamanho padrão por uma fração de
    // segundo antes de assets/js/acessibilidade.js carregar.
    (function () {
      try {
        var fonte = localStorage.getItem('CIT_ACESSIBILIDADE_FONTE_V3');
        if (fonte) document.documentElement.style.fontSize = fonte + '%';
        if (localStorage.getItem('CIT_ACESSIBILIDADE_MODO_ESCURO') === 'true') {
          document.documentElement.classList.add('dark');
        }
      } catch (e) {}
    })();
  </script>
  <!-- Google Tradutor é inicializado aqui, mas o <div> alvo do widget
       precisa ficar no <body> (ver logo abaixo, após a tag <body>) -->
  <script>
    function googleTranslateElementInit() {
      new google.translate.TranslateElement({ pageLanguage: 'pt', includedLanguages: 'pt,en,es', autoDisplay: false }, 'google_translate_element');
    }
    // Só baixa o Google Tradutor (script externo que pode travar em
    // conexão ruim) quando o usuário escolheu outro idioma. Para quem
    // usa português — a maioria — nada é baixado e a página não depende
    // de servidor externo. Quando baixa, é de forma assíncrona, sem
    // bloquear o desenho da tela.
    (function () {
      try {
        var idioma = localStorage.getItem('CIT_IDIOMA');
        if (idioma && idioma !== 'pt') {
          var s = document.createElement('script');
          s.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
          s.async = true;
          document.head.appendChild(s);
        }
      } catch (e) {}
    })();
  </script>
  </head>
 <body class="bg-gray-50 text-gray-800">
  <div id="google_translate_element" style="display:none;"></div>
  <div class="w-full min-h-full">
   <!-- Navigation -->
   <nav id="barra-navegacao" class="bg-white shadow-md sticky top-0 z-50 border-b-4 border-green-600">
    <div class="max-w-screen-2xl mx-auto px-4 sm:px-6 lg:px-8">
     <div id="barra-navegacao-linha" class="flex justify-between items-center gap-4 min-h-16 py-1">
      <div id="barra-navegacao-marca" class="flex items-center gap-2 sm:gap-3 min-w-0">
       <a href="index.php" class="shrink-0" aria-label="AgendaCIT — página inicial">
        <img src="<?= e(assetVersion('assets/img/logo-agendacit.png')) ?>" alt="AgendaCIT" width="56" height="56" class="w-12 h-12 sm:w-14 sm:h-14 object-contain">
       </a>
       <div>
        <span id="nav-title" class="font-bold text-lg text-gray-800 whitespace-nowrap">CIT IFRO</span> <span id="nav-institution" class="text-[0.7rem] sm:text-xs leading-tight text-green-600 font-semibold block sm:whitespace-nowrap"><?= e(INSTITUTION_NAME) ?></span>
       </div>
      </div>
      <?php
      // Links do menu. Relatórios e Administração só aparecem para o
      // administrador logado — para os demais eles só levavam a uma tela
      // de login que não era para eles.
      $linksMenu = [
          ['index.php#inicio', 'Início'],
          ['index.php#como-funciona', 'Como Funciona'],
          ['index.php#calendario', 'Calendário'],
          ['index.php#recursos', 'Recursos'],
      ];
      if (isAuthenticated()) {
          $linksMenu[] = ['index.php#relatorios', 'Relatórios'];
      }
      $linksMenu[] = ['index.php#contato', 'Contato'];
      $linksMenu[] = ['acessibilidade.php', 'Acessibilidade'];
      if (isAuthenticated()) {
          $linksMenu[] = ['index.php#admin', 'Administração'];
      }
      ?>
      <div id="menu-desktop" class="hidden xl:flex items-center gap-1 shrink-0">
       <?php foreach ($linksMenu as [$href, $rotulo]): ?>
       <a href="<?= e($href) ?>" class="nav-link px-3 py-2 text-sm font-medium text-gray-600 hover:text-green-600 rounded-lg hover:bg-green-50"><?= e($rotulo) ?></a>
       <?php endforeach; ?>
       <span class="mx-2 h-5 border-l border-gray-200"></span>
       <!-- Aluno/servidor: o login fica no navegador (script.js), então
            quem mostra "Olá, Fulano · Sair" ou "Área do aluno" é o
            atualizarMenuUsuario(). -->
       <?php if (!isAuthenticated()): /* o admin acha a Área do aluno no menu ☰ e no rodapé — no topo não cabia */ ?>
       <a href="acesso.php" data-menu-sem-aluno class="nav-link px-4 py-2 text-sm font-semibold text-green-700 border border-green-300 hover:bg-green-50 hover:border-green-400 rounded-lg transition-colors">Área de login</a>
       <?php endif; ?>
       <span data-menu-com-aluno class="hidden items-center gap-1">
        <a href="index.php#calendario" class="px-3 py-2 text-sm font-semibold text-green-700 whitespace-nowrap rounded-lg hover:bg-green-50" title="Ver meus agendamentos">Olá, <span data-menu-nome-aluno></span></a>
        <button type="button" onclick="sairUsuario()" class="px-3 py-2 text-sm font-bold text-red-600 hover:text-red-700 rounded-lg hover:bg-red-50">Sair</button>
       </span>
       <?php if (isAuthenticated()): ?>
       <a href="logout.php" title="Sair da coordenação (<?= e($_SESSION['admin_usuario'] ?? 'admin') ?>)" aria-label="Sair da coordenação" class="nav-link px-3 py-2 text-sm font-bold text-red-600 hover:text-red-700 rounded-lg hover:bg-red-50">Sair</a>
       <?php else: ?>
       <a href="login.php" class="nav-link px-3 py-2 text-sm font-medium text-gray-500 hover:text-green-700 rounded-lg hover:bg-green-50" title="Acesso da coordenação do CIT">Coordenação</a>
       <?php endif; ?>
      </div><button id="botao-menu-mobile" onclick="toggleMobileMenu()" aria-label="Abrir menu" class="xl:hidden shrink-0 p-2 rounded-lg hover:bg-gray-100">
       <?= icone('menu', 'w-6 h-6') ?></button>
     </div>
    </div><!-- Mobile Menu -->
    <div id="mobile-menu" class="hidden xl:hidden bg-white border-t border-gray-200 px-4 py-3">
     <a href="acesso.php" data-menu-sem-aluno class="block text-center py-2.5 mb-2 rounded-lg border border-green-300 text-green-700 font-semibold hover:bg-green-50">Área de login</a>
     <div data-menu-com-aluno class="hidden items-center justify-between gap-2 py-2 mb-2 border-b border-gray-200">
      <a href="index.php#calendario" class="text-green-700 font-semibold">Olá, <span data-menu-nome-aluno></span></a>
      <button type="button" onclick="sairUsuario()" class="text-red-600 font-bold">Sair</button>
     </div>
     <?php foreach ($linksMenu as [$href, $rotulo]): ?>
     <a href="<?= e($href) ?>" class="block py-2 text-gray-600 hover:text-green-600"><?= e($rotulo) ?></a>
     <?php endforeach; ?>
     <div class="border-t border-gray-200 mt-2 pt-2">
      <?php if (isAuthenticated()): ?>
      <a href="logout.php" class="block py-2 text-red-600 font-bold hover:text-red-700">Sair da coordenação (<?= e($_SESSION['admin_usuario'] ?? 'admin') ?>)</a>
      <?php else: ?>
      <a href="login.php" class="block py-2 text-gray-500 font-medium hover:text-green-700">Acesso da coordenação</a>
      <?php endif; ?>
     </div>
    </div>
   </nav>
