<?php
/**
 * includes/main-content.php
 * ---------------------------------------------------------------------
 * Conteúdo principal da aplicação (seções Início, Benefícios, Como
 * Funciona, Calendário, IA, Administração, Relatórios e Contato).
 * Extraído do protótipo original (index.html) sem alterações visuais;
 * os únicos pontos dinamizados foram o e-mail e telefone de contato,
 * que agora vêm das constantes definidas em config.php.
 *
 * Toda a interatividade (calendário, modais, agendamentos, relatórios)
 * continua sendo tratada no lado do cliente por assets/js/script.js,
 * como no protótipo original.
 * ---------------------------------------------------------------------
 */
?>
   <section id="inicio" class="gradient-ifro text-white py-14 sm:py-24 px-4 relative overflow-hidden">
    <div class="absolute inset-0 opacity-10">
     <div class="absolute top-20 right-20 w-72 h-72 bg-white rounded-full blur-3xl"></div>
     <div class="absolute bottom-20 left-20 w-96 h-96 bg-white rounded-full blur-3xl"></div>
    </div>
    <div class="max-w-7xl mx-auto relative z-10">
     <div class="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-12 items-center">
      <div>
       <div class="inline-flex items-center gap-2 bg-white/15 backdrop-blur px-4 py-2 rounded-full text-sm mb-6 border border-white/20">
        <span class="w-2 h-2 bg-emerald-300 rounded-full"></span> Disponibilidade em tempo real
       </div>
       <h1 id="hero-title" class="text-3xl min-[400px]:text-4xl sm:text-5xl md:text-6xl font-black mb-6 leading-tight">Sistema de Agendamento CIT</h1>
       <p class="text-lg text-green-100 mb-8 leading-relaxed">Consulte a disponibilidade da sala do CIT, evite conflitos de horário e organize o uso do espaço em um só lugar.</p>
       <div class="flex flex-wrap gap-4">
        <a href="#calendario" class="bg-white text-green-600 px-7 py-3 rounded-lg font-bold hover:bg-gray-100 transition-all shadow-lg"> Ver Calendário </a> <a href="#como-funciona" class="border-2 border-white/40 text-white px-7 py-3 rounded-lg font-bold hover:bg-white/10 transition-all"> Como Funciona </a>
       </div>
      </div>
      <!-- Painel "Hoje": dados reais da sala no dia (preenchido pelo
           script.js em renderPainelHoje — antes eram números e horários
           de exemplo escritos aqui, como "Prof. Silva"). -->
      <div class="hidden md:block">
       <div class="bg-white/10 backdrop-blur rounded-2xl p-6 border border-white/20 shadow-2xl">
        <div id="painel-hoje-titulo" class="text-sm font-semibold text-green-100 mb-3">Hoje</div>
        <div class="grid grid-cols-3 gap-3 mb-4">
         <div class="bg-emerald-500/30 rounded-lg p-2 sm:p-3 text-center border border-white/10">
          <div class="text-2xl font-bold" id="stat-available">–</div>
          <div class="text-xs leading-tight text-green-100">Horas livres hoje</div>
         </div>
         <div class="bg-red-500/30 rounded-lg p-2 sm:p-3 text-center border border-white/10">
          <div class="text-2xl font-bold" id="stat-occupied">–</div>
          <div class="text-xs leading-tight text-green-100">Reservas hoje</div>
         </div>
         <div class="bg-amber-500/30 rounded-lg p-2 sm:p-3 text-center border border-white/10">
          <div class="text-2xl font-bold" id="stat-pending">–</div>
          <div class="text-xs leading-tight text-green-100">Pedidos em análise</div>
         </div>
        </div>
        <div id="painel-hoje-lista" class="space-y-2">
         <p class="text-sm text-green-100">Carregando a agenda de hoje...</p>
        </div>
       </div>
      </div>
     </div>
    </div>
   </section><!-- Benefits Section -->
   <section class="py-14 sm:py-20 px-4 bg-white">
    <div class="max-w-7xl mx-auto">
     <div class="text-center mb-12">
      <h2 class="text-3xl sm:text-4xl font-black text-gray-800 mb-4">Benefícios para Todos</h2>
      <p class="text-gray-600 max-w-2xl mx-auto text-lg">O sistema foi desenvolvido pensando nas necessidades de professores, alunos e coordenação.</p>
     </div>
     <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
      <div class="card-hover bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-5 sm:p-8 border-2 border-blue-200">
       <div class="w-14 h-14 gradient-ifro rounded-xl flex items-center justify-center mb-6 shadow-lg">
        <?= icone('livro', 'w-7 h-7 text-white') ?>
       </div>
       <h3 class="text-2xl font-bold text-gray-800 mb-3">Para Professores</h3>
       <ul class="text-gray-700 space-y-3 text-sm font-medium">
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Reserve horários para aulas práticas</li>
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Visualize disponibilidade em tempo real</li>
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Receba sugestões de horários alternativos</li>
       </ul>
      </div>
      <div class="card-hover bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-5 sm:p-8 border-2 border-purple-200">
       <div class="w-14 h-14 gradient-ifro rounded-xl flex items-center justify-center mb-6 shadow-lg">
        <?= icone('usuarios', 'w-7 h-7 text-white') ?>
       </div>
       <h3 class="text-2xl font-bold text-gray-800 mb-3">Para Alunos</h3>
       <ul class="text-gray-700 space-y-3 text-sm font-medium">
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Consulte horários disponíveis facilmente</li>
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Solicite uso para projetos e estudos</li>
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Acompanhe status das solicitações</li>
       </ul>
      </div>
      <div class="card-hover bg-gradient-to-br from-amber-50 to-amber-100 rounded-2xl p-5 sm:p-8 border-2 border-amber-200">
       <div class="w-14 h-14 gradient-ifro rounded-xl flex items-center justify-center mb-6 shadow-lg">
        <?= icone('escudo-check', 'w-7 h-7 text-white') ?>
       </div>
       <h3 class="text-2xl font-bold text-gray-800 mb-3">Para Coordenação</h3>
       <ul class="text-gray-700 space-y-3 text-sm font-medium">
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Controle centralizado de agendamentos</li>
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Relatórios de utilização do espaço</li>
        <li class="flex items-start gap-2">
         <?= icone('check', 'w-5 h-5 text-green-600 flex-shrink-0 mt-0.5') ?> Gestão eficiente de conflitos</li>
       </ul>
      </div>
     </div>
    </div>
   </section><!-- How It Works Section -->
   <section id="como-funciona" class="py-14 sm:py-20 px-4 bg-gray-100">
    <div class="max-w-7xl mx-auto">
     <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl font-black text-gray-800 mb-4">Como Funciona o Agendamento</h2>
      <p class="text-gray-600 max-w-2xl mx-auto text-lg">Processo simples e rápido em apenas 4 passos</p>
     </div>
     <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      <div class="relative">
       <div class="bg-white rounded-2xl p-5 sm:p-8 border-l-4 border-green-600 card-hover h-full shadow-lg">
        <div class="w-12 h-12 gradient-ifro text-white rounded-full flex items-center justify-center font-bold mb-4 text-lg shadow-lg">
         1
        </div>
        <h3 class="font-bold text-gray-800 mb-2 text-lg">Consulte o Calendário</h3>
        <p class="text-sm text-gray-600">Verifique os horários disponíveis no calendário interativo.</p>
       </div>
       <div class="hidden lg:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
        <?= icone('seta-direita', 'w-6 h-6 text-green-600') ?>
       </div>
      </div>
      <div class="relative">
       <div class="bg-white rounded-2xl p-5 sm:p-8 border-l-4 border-green-600 card-hover h-full shadow-lg">
        <div class="w-12 h-12 gradient-ifro text-white rounded-full flex items-center justify-center font-bold mb-4 text-lg shadow-lg">
         2
        </div>
        <h3 class="font-bold text-gray-800 mb-2 text-lg">Selecione Data e Horário</h3>
        <p class="text-sm text-gray-600">Escolha o período desejado e informe a finalidade do uso.</p>
       </div>
       <div class="hidden lg:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
        <?= icone('seta-direita', 'w-6 h-6 text-green-600') ?>
       </div>
      </div>
      <div class="relative">
       <div class="bg-white rounded-2xl p-5 sm:p-8 border-l-4 border-green-600 card-hover h-full shadow-lg">
        <div class="w-12 h-12 gradient-ifro text-white rounded-full flex items-center justify-center font-bold mb-4 text-lg shadow-lg">
         3
        </div>
        <h3 class="font-bold text-gray-800 mb-2 text-lg">Envie a Solicitação</h3>
        <p class="text-sm text-gray-600">Preencha seus dados e envie para análise da coordenação.</p>
       </div>
       <div class="hidden lg:block absolute top-1/2 -right-3 transform -translate-y-1/2 z-10">
        <?= icone('seta-direita', 'w-6 h-6 text-green-600') ?>
       </div>
      </div>
      <div>
       <div class="bg-white rounded-2xl p-5 sm:p-8 border-l-4 border-green-600 card-hover h-full shadow-lg">
        <div class="w-12 h-12 gradient-ifro text-white rounded-full flex items-center justify-center font-bold mb-4 text-lg shadow-lg">
         4
        </div>
        <h3 class="font-bold text-gray-800 mb-2 text-lg">Receba Confirmação</h3>
        <p class="text-sm text-gray-600">Acompanhe o status e receba a aprovação do agendamento.</p>
       </div>
      </div>
     </div>
    </div>
   </section><!-- Calendar Section -->
   <section id="calendario" class="py-14 sm:py-20 px-4 bg-white">
    <div class="max-w-7xl mx-auto">
     <div class="text-center mb-12">
      <h2 class="text-3xl sm:text-4xl font-black text-gray-800 mb-4">Calendário de Horários</h2>
      <p class="text-gray-600 max-w-2xl mx-auto text-lg">Visualize a disponibilidade do CIT e faça seu agendamento</p>
     </div>

     <div id="faixa-entrar-calendario" class="max-w-3xl mx-auto mb-8 flex flex-wrap items-center justify-between gap-3 border border-gray-200 rounded-lg px-5 py-4 bg-gray-50">
      <p class="text-sm text-gray-600">Para reservar um horário, entre na sua área de aluno ou servidor.</p>
      <a href="acesso.php" class="px-4 py-2 text-sm font-bold text-white bg-green-600 hover:bg-green-700 rounded-lg shadow transition-colors whitespace-nowrap">Login / Cadastro →</a>
     </div>

     <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <!-- Calendar Widget -->
      <div id="calendario-card" class="lg:col-span-2 bg-white rounded-2xl p-3 sm:p-6 xl:p-8 border-2 border-green-200 shadow-lg sm:min-h-[620px] transition-all">
       <div class="flex items-center justify-between mb-6">
        <button onclick="changeMonth(-1)" aria-label="Mês anterior" class="p-2 hover:bg-green-100 rounded-lg transition-colors">
         <?= icone('chevron-esquerda', 'w-6 h-6 text-green-600') ?></button>
        <h3 id="calendar-month" class="text-2xl font-bold text-gray-800"><?= ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'][(int) date('n') - 1] . ' ' . date('Y') ?></h3>
        <div class="flex items-center gap-1">
         <button onclick="changeMonth(1)" aria-label="Próximo mês" class="p-2 hover:bg-green-100 rounded-lg transition-colors">
          <?= icone('chevron-direita', 'w-6 h-6 text-green-600') ?></button>
         <button onclick="toggleCalendarioExpandido()" id="btn-expandir-calendario" title="Expandir calendário" class="p-2 hover:bg-green-100 rounded-lg transition-colors">
          <?= icone('expandir', 'w-6 h-6 text-green-600') ?></button>
        </div>
       </div>
       <div class="grid grid-cols-7 gap-1 mb-2">
        <div class="text-center text-xs font-bold text-green-600 py-2 sm:py-3">
         <span class="sm:hidden" aria-hidden="true">D</span><span class="sr-only sm:not-sr-only">DOM</span>
        </div>
        <div class="text-center text-xs font-bold text-green-600 py-2 sm:py-3">
         <span class="sm:hidden" aria-hidden="true">S</span><span class="sr-only sm:not-sr-only">SEG</span>
        </div>
        <div class="text-center text-xs font-bold text-green-600 py-2 sm:py-3">
         <span class="sm:hidden" aria-hidden="true">T</span><span class="sr-only sm:not-sr-only">TER</span>
        </div>
        <div class="text-center text-xs font-bold text-green-600 py-2 sm:py-3">
         <span class="sm:hidden" aria-hidden="true">Q</span><span class="sr-only sm:not-sr-only">QUA</span>
        </div>
        <div class="text-center text-xs font-bold text-green-600 py-2 sm:py-3">
         <span class="sm:hidden" aria-hidden="true">Q</span><span class="sr-only sm:not-sr-only">QUI</span>
        </div>
        <div class="text-center text-xs font-bold text-green-600 py-2 sm:py-3">
         <span class="sm:hidden" aria-hidden="true">S</span><span class="sr-only sm:not-sr-only">SEX</span>
        </div>
        <div class="text-center text-xs font-bold text-green-600 py-2 sm:py-3">
         <span class="sm:hidden" aria-hidden="true">S</span><span class="sr-only sm:not-sr-only">SÁB</span>
        </div>
       </div>
       <div id="calendar-days" class="grid grid-cols-7 gap-1">
        <!-- Days will be generated by JavaScript -->
       </div>
       <div class="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 mt-6 sm:mt-8 pt-4 sm:pt-6 border-t-2 border-green-200">
        <div class="flex items-center gap-2">
         <div class="w-3 h-3 bg-emerald-500 rounded-full"></div><span class="text-sm font-medium text-gray-600">Disponível</span>
        </div>
        <div class="flex items-center gap-2">
         <div class="w-3 h-3 bg-red-500 rounded-full"></div><span class="text-sm font-medium text-gray-600">Ocupado</span>
        </div>
        <div class="flex items-center gap-2">
         <div class="w-3 h-3 bg-amber-500 rounded-full"></div><span class="text-sm font-medium text-gray-600">Em Análise</span>
        </div>
       </div>
      </div><!-- Time Slots -->
      <div class="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-5 sm:p-8 border-2 border-green-200 shadow-lg">
       <h3 class="font-bold text-gray-800 mb-4 text-lg">Horários do dia <span id="selected-date" class="text-green-600"></span></h3>
       <div id="time-slots" class="space-y-2">
        <p class="text-gray-600 text-sm">Selecione uma data no calendário para ver os horários disponíveis.</p>
       </div>
      </div>
     </div><!-- Booking List -->
     <div class="mt-8 bg-white rounded-2xl p-5 sm:p-8 border-2 border-green-200 shadow-lg">
      <div class="flex flex-wrap items-center justify-between gap-2 mb-6">
       <h3 id="bookings-list-title" class="font-bold text-gray-800 text-lg">Agendamentos Registrados</h3><span id="booking-count" class="text-sm font-medium bg-green-100 text-green-700 px-3 py-1 rounded-full">0 agendamentos</span>
      </div>
      <div id="bookings-list" class="space-y-2">
       <p class="text-gray-500 text-sm text-center py-4">Nenhum agendamento registrado ainda.</p>
      </div>
     </div>
    </div>
   </section><!-- Booking Form Modal -->
   <div id="booking-modal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl max-w-md w-full p-5 sm:p-8 fade-in max-h-[90%] overflow-auto shadow-2xl border-2 border-green-200">
     <div class="flex items-center justify-between mb-6">
      <h3 id="booking-modal-title" class="min-w-0 text-2xl font-bold text-gray-800">Novo Agendamento</h3><button onclick="closeBookingModal()" aria-label="Fechar" class="shrink-0 p-2 hover:bg-green-100 rounded-lg">
       <?= icone('fechar', 'w-6 h-6') ?></button>
     </div>
     <form id="booking-form" onsubmit="handleBookingSubmit(event)">
      <div class="space-y-4">
       <div>
        <label for="booking-date" class="block text-sm font-bold text-gray-700 mb-2">Data</label> <input type="date" id="booking-date" required class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium">
       </div>
       <div class="grid grid-cols-2 gap-3">
        <div class="min-w-0">
         <label for="booking-start" class="block text-sm font-bold text-gray-700 mb-2">Início</label><input type="time" id="booking-start" required min="<?= e(HORARIO_ABERTURA) ?>" max="<?= e(HORARIO_FECHAMENTO) ?>" class="w-full px-3 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 font-medium">
        </div>
        <div class="min-w-0">
         <label for="booking-end" class="block text-sm font-bold text-gray-700 mb-2">Término</label><input type="time" id="booking-end" required min="<?= e(HORARIO_ABERTURA) ?>" max="<?= e(HORARIO_FECHAMENTO) ?>" class="w-full px-3 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 font-medium">
        </div>
       </div>
       <p class="text-xs text-gray-500 -mt-2">A sala do CIT funciona de segunda a sexta, das <?= e(HORARIO_ABERTURA) ?> às <?= e(HORARIO_FECHAMENTO) ?> (sábado só para eventos combinados com a coordenação).</p>
       <div>
        <label for="booking-responsible" class="block text-sm font-bold text-gray-700 mb-2">Responsável</label> <input type="text" id="booking-responsible" required placeholder="Nome completo" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium"> <span class="block text-xs text-gray-500 mt-1">Preenchido automaticamente após o login na Área do aluno/servidor, no Calendário.</span>
       </div>
       <div>
        <label for="booking-participants" class="block text-sm font-bold text-gray-700 mb-2">Quantidade aproximada de participantes</label><input type="number" id="booking-participants" min="1" required placeholder="Ex.: 20" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 font-medium">
       </div>
       <div>
        <label class="block text-sm font-bold text-gray-700 mb-2">Equipamentos necessários</label>
        <span class="block text-xs text-gray-500 mt-1">Selecione os equipamentos que serão usados. O sistema mostrará quantas unidades existem no CIT e perguntará a quantidade de cada equipamento.</span>
        <div id="booking-equipment-list" class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm mt-3">
         <!-- gerado via JS: renderBookingEquipmentChoices() -->
        </div>
       </div>
       <div>
        <label for="booking-purpose" class="block text-sm font-bold text-gray-700 mb-2">Finalidade</label> <select id="booking-purpose" required class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium"> <option value="">Selecione a finalidade</option> <option value="Aula">Aula</option> <option value="Projeto">Projeto</option> <option value="Reunião">Reunião</option> <option value="Treinamento">Treinamento</option> <option value="Evento">Evento</option> <option value="Outro">Outro</option> </select>
       </div>
       <div>
        <label for="booking-description" class="block text-sm font-bold text-gray-700 mb-2">Descrição</label> <textarea id="booking-description" rows="3" placeholder="Descreva brevemente o uso do CIT" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium"></textarea>
       </div>
      </div>
      <div id="booking-suggestion" class="hidden mt-4 p-4 bg-green-50 border-2 border-green-300 rounded-lg">
       <p class="text-sm text-green-900 font-medium"><strong>💡 Sugestão:</strong> <span id="suggestion-text"></span></p>
      </div>
      <div class="flex flex-wrap gap-3 mt-6">
       <button type="button" onclick="closeBookingModal()" class="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg text-gray-700 font-bold hover:bg-gray-100 transition-colors"> Cancelar </button> <button type="submit" id="submit-booking-btn" class="flex-1 px-4 py-3 gradient-ifro text-white rounded-lg font-bold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"> Agendar </button>
      </div>
     </form>
    </div>
   </div><!-- AI Section -->
   <section id="recursos" class="py-14 sm:py-20 px-4 bg-gray-50">
    <div class="max-w-7xl mx-auto">
     <div class="text-center mb-12">
      <h2 class="text-3xl font-bold text-gray-900 mb-3">Como o sistema evita conflitos de horário</h2>
      <p class="text-gray-600 max-w-2xl mx-auto">Antes de confirmar qualquer reserva, o sistema verifica automaticamente a disponibilidade da sala.</p>
     </div>

     <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-start">
      <div class="space-y-6">
       <div class="flex items-start gap-4">
        <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
         <?= icone('check-circulo', 'w-5 h-5 text-green-700') ?>
        </div>
        <div>
         <h3 class="font-semibold text-gray-900 mb-1">Verificação de conflitos</h3>
         <p class="text-sm text-gray-600">Ao enviar um agendamento, o sistema confere se o período pedido cruza com alguma reserva já aprovada para o mesmo dia — e recusa o envio se houver sobreposição.</p>
        </div>
       </div>
       <div class="flex items-start gap-4">
        <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
         <?= icone('raio', 'w-5 h-5 text-green-700') ?>
        </div>
        <div>
         <h3 class="font-semibold text-gray-900 mb-1">Sugestão de horário alternativo</h3>
         <p class="text-sm text-gray-600">Quando o horário pedido está ocupado, o sistema mostra os intervalos livres daquele dia como botões: um clique já preenche o formulário com o novo horário.</p>
        </div>
       </div>
       <div class="flex items-start gap-4">
        <div class="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
         <?= icone('relogio', 'w-5 h-5 text-green-700') ?>
        </div>
        <div>
         <h3 class="font-semibold text-gray-900 mb-1">Cálculo de horários livres</h3>
         <p class="text-sm text-gray-600">O painel do Calendário mostra os intervalos realmente livres do dia, considerando reservas aprovadas e pedidos pendentes, em vez de uma lista fixa de horários.</p>
        </div>
       </div>
      </div>

      <div class="bg-white rounded-xl p-6 border border-gray-200">
       <div class="text-xs font-semibold text-gray-500 uppercase mb-4">Exemplo</div>
       <div class="space-y-3">
        <div class="bg-red-50 rounded-lg p-4 border border-red-200">
         <div class="flex items-center gap-2 mb-1">
          <div class="w-2 h-2 bg-red-500 rounded-full"></div><span class="text-sm font-semibold text-gray-800">Conflito detectado</span>
         </div>
         <p class="text-sm text-gray-600">O horário 10:00–12:00 de 15/01 já está reservado para "Aula de Programação".</p>
        </div>
        <div class="flex justify-center text-gray-400">
         <?= icone('seta-baixo', 'w-5 h-5') ?>
        </div>
        <div class="bg-green-50 rounded-lg p-4 border border-green-200">
         <div class="flex items-center gap-2 mb-1">
          <div class="w-2 h-2 bg-green-600 rounded-full"></div><span class="text-sm font-semibold text-gray-800">Horário alternativo sugerido</span>
         </div>
         <p class="text-sm text-gray-600">Livre no mesmo dia: <span class="font-semibold">08:00 – 10:00</span> · <span class="font-semibold">12:00 – 14:00</span></p>
        </div>
       </div>
      </div>
     </div>
    </div>
   </section><!-- Reports Section -->
   <!-- Relatórios e Área Administrativa: só existem para o admin. Para os
        demais, a seção inteira fica escondida (antes aparecia um quadro de
        cadeado com "Fazer login", que só confundia aluno e visitante). -->
   <section id="relatorios" class="py-14 sm:py-20 px-4 bg-gray-100<?= isAuthenticated() ? '' : ' hidden' ?>">
    <div class="max-w-7xl mx-auto">
     <?php if (isAuthenticated()): ?>
     <div class="text-center mb-12">
      <h2 class="text-3xl sm:text-4xl font-black text-gray-800 mb-4">Relatórios de Uso do CIT</h2>
      <p class="text-gray-600 max-w-2xl mx-auto text-lg">Acompanhe estatísticas e métricas de utilização do espaço</p>
     </div>
     <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <div class="bg-white rounded-2xl p-6 border-l-4 border-green-600 shadow-lg">
       <div class="flex items-center justify-between mb-2">
        <span class="text-sm font-bold text-gray-600">Total de Agendamentos</span>
        <?= icone('calendario', 'w-6 h-6 text-green-600') ?>
       </div>
       <div id="report-total" class="text-4xl font-black text-gray-800">
        0
       </div>
      </div>
      <div class="bg-white rounded-2xl p-6 border-l-4 border-emerald-600 shadow-lg">
       <div class="flex items-center justify-between mb-2">
        <span class="text-sm font-bold text-gray-600">Aprovados</span>
        <?= icone('check-circulo', 'w-6 h-6 text-emerald-600') ?>
       </div>
       <div id="report-approved" class="text-4xl font-black text-emerald-600">
        0
       </div>
      </div>
      <div class="bg-white rounded-2xl p-6 border-l-4 border-amber-600 shadow-lg">
       <div class="flex items-center justify-between mb-2">
        <span class="text-sm font-bold text-gray-600">Pendentes</span>
        <?= icone('relogio', 'w-6 h-6 text-amber-600') ?>
       </div>
       <div id="report-pending" class="text-4xl font-black text-amber-600">
        0
       </div>
      </div>
      <div class="bg-white rounded-2xl p-6 border-l-4 border-blue-600 shadow-lg">
       <div class="flex items-center justify-between mb-2">
        <span class="text-sm font-bold text-gray-600" title="Horas aprovadas no mês ÷ horas de funcionamento do mês (seg. a sex.)">Ocupação do mês</span>
        <?= icone('grafico', 'w-6 h-6 text-blue-600') ?>
       </div>
       <div id="report-rate" class="text-4xl font-black text-blue-600">
        0%
       </div>
      </div>
     </div>
     <!-- Gráficos (Chart.js), alimentados por api/records.php?tipo=estatisticas
          — ver carregarEstatisticas() em assets/js/script.js. Cada um tem
          uma tabela com os mesmos números ("Ver como tabela"), para leitor
          de tela e para quem não distingue as cores. -->
     <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
      <figure class="bg-white rounded-2xl p-5 border-2 border-green-200 shadow-lg min-w-0">
       <figcaption class="font-bold text-gray-800 text-lg">Ocupação por dia da semana</figcaption>
       <p class="text-xs text-gray-500 mb-3">Agendamentos aprovados, histórico completo</p>
       <div class="relative h-60"><canvas id="grafico-ocupacao" role="img" aria-label="Gráfico de barras: agendamentos aprovados por dia da semana"></canvas></div>
       <details class="mt-3 text-sm"><summary class="cursor-pointer text-green-700 font-semibold">Ver como tabela</summary><div id="tabela-ocupacao" class="mt-2"></div></details>
      </figure>
      <figure class="bg-white rounded-2xl p-5 border-2 border-green-200 shadow-lg min-w-0">
       <figcaption class="font-bold text-gray-800 text-lg">Equipamentos mais pedidos</figcaption>
       <p class="text-xs text-gray-500 mb-3">Em quantos agendamentos cada um foi pedido</p>
       <div class="relative h-60"><canvas id="grafico-equipamentos" role="img" aria-label="Gráfico de barras horizontais: equipamentos mais pedidos"></canvas></div>
       <details class="mt-3 text-sm"><summary class="cursor-pointer text-green-700 font-semibold">Ver como tabela</summary><div id="tabela-equipamentos" class="mt-2"></div></details>
      </figure>
      <figure class="bg-white rounded-2xl p-5 border-2 border-green-200 shadow-lg min-w-0">
       <figcaption class="font-bold text-gray-800 text-lg">Situação dos agendamentos</figcaption>
       <p class="text-xs text-gray-500 mb-3">Aprovados, pendentes, recusados e cancelados</p>
       <div class="relative h-60"><canvas id="grafico-situacao" role="img" aria-label="Gráfico de rosca: agendamentos aprovados, pendentes, recusados e cancelados"></canvas></div>
       <details class="mt-3 text-sm"><summary class="cursor-pointer text-green-700 font-semibold">Ver como tabela</summary><div id="tabela-situacao" class="mt-2"></div></details>
      </figure>
     </div>
     <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div class="bg-white rounded-2xl p-5 sm:p-8 border-2 border-green-200 shadow-lg">
       <h3 class="font-bold text-gray-800 mb-4 text-lg">Uso por Finalidade</h3>
       <div id="purpose-chart" class="space-y-4">
        <div class="flex items-center gap-3">
         <span class="text-sm font-bold text-gray-600 w-24">Aula</span>
         <div class="flex-1 bg-gray-200 rounded-full h-4 overflow-hidden">
          <div id="bar-aula" class="bg-blue-600 rounded-full h-4 transition-all width-zero"></div>
         </div><span id="count-aula" class="text-sm font-black text-gray-800 w-8">0</span>
        </div>
        <div class="flex items-center gap-3">
         <span class="text-sm font-bold text-gray-600 w-24">Projeto</span>
         <div class="flex-1 bg-gray-200 rounded-full h-4 overflow-hidden">
          <div id="bar-projeto" class="bg-emerald-600 rounded-full h-4 transition-all width-zero"></div>
         </div><span id="count-projeto" class="text-sm font-black text-gray-800 w-8">0</span>
        </div>
        <div class="flex items-center gap-3">
         <span class="text-sm font-bold text-gray-600 w-24">Reunião</span>
         <div class="flex-1 bg-gray-200 rounded-full h-4 overflow-hidden">
          <div id="bar-reuniao" class="bg-purple-600 rounded-full h-4 transition-all width-zero"></div>
         </div><span id="count-reuniao" class="text-sm font-black text-gray-800 w-8">0</span>
        </div>
        <div class="flex items-center gap-3">
         <span class="text-sm font-bold text-gray-600 w-24">Treinamento</span>
         <div class="flex-1 bg-gray-200 rounded-full h-4 overflow-hidden">
          <div id="bar-treinamento" class="bg-amber-600 rounded-full h-4 transition-all width-zero"></div>
         </div><span id="count-treinamento" class="text-sm font-black text-gray-800 w-8">0</span>
        </div>
        <div class="flex items-center gap-3">
         <span class="text-sm font-bold text-gray-600 w-24">Outros</span>
         <div class="flex-1 bg-gray-200 rounded-full h-4 overflow-hidden">
          <div id="bar-outros" class="bg-slate-600 rounded-full h-4 transition-all width-zero"></div>
         </div><span id="count-outros" class="text-sm font-black text-gray-800 w-8">0</span>
        </div>
       </div>
      </div>
      <div class="bg-white rounded-2xl p-5 sm:p-8 border-2 border-green-200 shadow-lg">
       <h3 class="font-bold text-gray-800 mb-4 text-lg">Últimas Atividades</h3>
       <div id="activity-log" class="space-y-3">
        <p class="text-gray-600 text-sm text-center py-4 font-medium">Nenhuma atividade registrada.</p>
       </div>
      </div>
     </div>
     <?php endif; ?>
    </div>
   </section><!-- Contact Section -->
   <section id="contato" class="py-14 sm:py-20 px-4 bg-white">
    <div class="max-w-7xl mx-auto">
     <div class="text-center mb-12">
      <h2 class="text-3xl sm:text-4xl font-black text-gray-800 mb-4">Contato e Suporte</h2>
      <p class="text-gray-600 max-w-2xl mx-auto text-lg">Precisa de ajuda? Entre em contato com nossa equipe</p>
     </div>
     <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
      <div class="bg-gradient-to-br from-emerald-50 to-green-50 rounded-2xl p-5 sm:p-8 border-2 border-emerald-200 text-center card-hover">
       <div class="w-14 h-14 gradient-ifro rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
        <?= icone('email', 'w-7 h-7 text-white') ?>
       </div>
       <h3 class="font-bold text-gray-800 mb-2 text-lg">E-mail</h3>
       <p id="contact-email-display" class="text-gray-600 font-medium"><?= e(CONTACT_EMAIL) ?></p>
      </div>
      <div class="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-5 sm:p-8 border-2 border-blue-200 text-center card-hover">
       <div class="w-14 h-14 gradient-ifro rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
        <?= icone('telefone', 'w-7 h-7 text-white') ?>
       </div>
       <h3 class="font-bold text-gray-800 mb-2 text-lg">Telefone</h3>
       <p id="contact-phone-display" class="text-gray-600 font-medium"><?= e(CONTACT_PHONE) ?></p>
      </div>
      <div class="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-5 sm:p-8 border-2 border-purple-200 text-center card-hover">
       <div class="w-14 h-14 gradient-ifro rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
        <?= icone('localizacao', 'w-7 h-7 text-white') ?>
       </div>
       <h3 class="font-bold text-gray-800 mb-2 text-lg">Localização</h3>
       <p class="text-gray-600 font-medium">Bloco C, Sala 101<br>
         Campus Principal</p>
      </div>
     </div>
     <div class="mt-12 bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-5 sm:p-8 border-2 border-green-200">
      <h3 class="font-bold text-gray-800 mb-6 text-center text-lg">Envie uma Mensagem</h3>
      <form id="contact-form" onsubmit="handleContactSubmit(event)" class="max-w-xl mx-auto">
       <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
         <label for="contact-name" class="block text-sm font-bold text-gray-700 mb-2">Nome</label> <input type="text" id="contact-name" required class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium">
        </div>
        <div>
         <label for="contact-email-input" class="block text-sm font-bold text-gray-700 mb-2">E-mail</label> <input type="email" id="contact-email-input" required class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium">
        </div>
       </div>
       <div class="mb-4">
        <label for="contact-message" class="block text-sm font-bold text-gray-700 mb-2">Mensagem</label> <textarea id="contact-message" rows="4" required class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 font-medium"></textarea>
       </div><button type="submit" class="w-full gradient-ifro text-white py-3 rounded-lg font-bold hover:shadow-lg transition-all text-lg"> Enviar Mensagem </button>
      </form>
      <div id="contact-success" class="hidden mt-4 p-4 bg-emerald-50 border-2 border-emerald-300 rounded-lg text-center">
       <p class="text-emerald-800 font-bold">✅ Mensagem enviada com sucesso! Entraremos em contato em breve.</p>
      </div>
     </div>
    </div>
   </section><!-- Admin Section -->
   <section id="admin" class="py-14 sm:py-20 px-4 bg-white<?= isAuthenticated() ? '' : ' hidden' ?>">
    <div class="max-w-7xl mx-auto">
     <?php if (isAuthenticated()): ?>
     <div class="text-center mb-12">
      <h2 class="text-3xl sm:text-4xl font-black text-gray-800 mb-4">Área Administrativa</h2>
      <p class="text-gray-600 max-w-2xl mx-auto text-lg">Aprove pedidos, acompanhe a agenda e gerencie usuários, equipamentos e relatórios do CIT.</p>
     </div>

     <div class="max-w-3xl mx-auto mb-12 bg-gradient-to-br from-amber-50 to-green-50 rounded-2xl p-5 sm:p-8 border-2 border-amber-200">
      <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2 text-lg">
       <?= icone('relogio', 'w-6 h-6 text-amber-600') ?> Cadastros Pendentes de Aprovação</h3>
      <p class="text-sm text-gray-600 mb-4">Alunos e servidores que se cadastraram sozinhos, pela Área do aluno/servidor no Calendário, aparecem aqui até você aceitar ou recusar.</p>
      <div id="cadastros-pendentes-lista" class="space-y-2">
       <!-- gerado via JS: renderCadastrosPendentes() -->
      </div>
     </div>

     <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div class="bg-gradient-to-br from-yellow-50 to-green-50 rounded-2xl p-5 sm:p-8 border-2 border-green-200">
       <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2 text-lg">
        <?= icone('relogio', 'w-6 h-6 text-green-600') ?> Solicitações Pendentes</h3>
       <div id="pending-requests" class="space-y-3">
        <p class="text-gray-600 text-sm text-center py-4 font-medium">Nenhuma solicitação pendente.</p>
       </div>
      </div>
      <div class="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-5 sm:p-8 border-2 border-green-200">
       <h3 class="font-bold text-gray-800 mb-4 flex items-center gap-2 text-lg">
        <?= icone('check-circulo', 'w-6 h-6 text-green-600') ?> Ações Rápidas</h3>
       <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-1 lg:grid-cols-2 gap-3">
        <button onclick="openBookingModal()" class="p-4 bg-white border-2 border-green-300 rounded-xl hover:border-green-600 hover:shadow-lg transition-all text-left font-bold">
         <?= icone('mais', 'w-7 h-7 text-green-600 mb-2') ?>
         <div class="font-bold text-gray-800">
          Novo Agendamento
         </div>
         <div class="text-xs text-gray-500">
          Criar reserva manual
         </div></button> <button onclick="scrollToSection('relatorios')" class="p-4 bg-white border-2 border-blue-300 rounded-xl hover:border-blue-600 hover:shadow-lg transition-all text-left font-bold">
         <?= icone('grafico', 'w-7 h-7 text-blue-600 mb-2') ?>
         <div class="font-bold text-gray-800">
          Ver Relatórios
         </div>
         <div class="text-xs text-gray-500">
          Estatísticas de uso
         </div></button> <button onclick="scrollToSection('calendario')" class="p-4 bg-white border-2 border-purple-300 rounded-xl hover:border-purple-600 hover:shadow-lg transition-all text-left font-bold">
         <?= icone('calendario', 'w-7 h-7 text-purple-600 mb-2') ?>
         <div class="font-bold text-gray-800">
          Calendário
         </div>
         <div class="text-xs text-gray-500">
          Visualizar agenda
         </div></button> <button onclick="exportData()" class="p-4 bg-white border-2 border-amber-300 rounded-xl hover:border-amber-600 hover:shadow-lg transition-all text-left font-bold">
         <?= icone('download', 'w-7 h-7 text-amber-600 mb-2') ?>
         <div class="font-bold text-gray-800">
          Exportar Dados
         </div>
         <div class="text-xs text-gray-500">
          Planilha para o Excel (CSV)
         </div></button>
       </div>
      </div>
     </div>
     <div class="mt-8 bg-slate-50 rounded-2xl p-4 sm:p-6 border-2 border-green-200 shadow-lg">
      <div class="flex flex-wrap items-center justify-between gap-4 mb-6">
       <div class="min-w-0">
        <h3 class="text-2xl font-black text-gray-800">Central de Gerenciamento</h3>
        <p class="text-sm text-gray-600 mt-1">Consulte e organize todos os recursos do CIT.</p>
       </div>
       <div class="flex flex-wrap gap-2" role="tablist" aria-label="Gerenciamento administrativo">
        <button onclick="showAdminPanel('agenda')" id="admin-tab-agenda" class="admin-tab px-4 py-2 rounded-lg bg-green-600 text-white font-bold text-sm">Agenda</button> <button onclick="showAdminPanel('historico')" id="admin-tab-historico" class="admin-tab px-4 py-2 rounded-lg bg-white border-2 border-green-200 text-gray-700 font-bold text-sm">Histórico</button> <button onclick="showAdminPanel('equipamentos')" id="admin-tab-equipamentos" class="admin-tab px-4 py-2 rounded-lg bg-white border-2 border-green-200 text-gray-700 font-bold text-sm">Equipamentos</button> <button onclick="showAdminPanel('usuarios')" id="admin-tab-usuarios" class="admin-tab px-4 py-2 rounded-lg bg-white border-2 border-green-200 text-gray-700 font-bold text-sm">Usuários</button> <button onclick="showAdminPanel('auditoria')" id="admin-tab-auditoria" class="admin-tab px-4 py-2 rounded-lg bg-white border-2 border-green-200 text-gray-700 font-bold text-sm">Auditoria</button>
       </div>
      </div>
      <div id="admin-panel-agenda" class="admin-panel"></div>
      <div id="admin-panel-historico" class="admin-panel hidden"></div>
      <div id="admin-panel-equipamentos" class="admin-panel hidden"></div>
      <div id="admin-panel-auditoria" class="admin-panel hidden"></div>
      <!-- Aba Usuários: cadastro de aluno/servidor pelo admin + lista com
           busca e filtro (antes ficava solto no topo da Área Administrativa). -->
      <div id="admin-panel-usuarios" class="admin-panel hidden">
       <div class="grid grid-cols-1 lg:grid-cols-[minmax(0,22rem)_minmax(0,1fr)] gap-6">
        <div class="bg-green-50 border-2 border-green-200 rounded-2xl p-4 self-start">
         <label for="novo-usuario-nome" class="block text-sm font-bold text-gray-700 mb-2">Cadastrar aluno ou servidor</label>
         <input id="novo-usuario-nome" type="text" placeholder="Nome completo do aluno ou servidor" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg bg-white font-medium mb-2">
         <label for="novo-usuario-matricula" class="block text-xs font-bold text-gray-700 mb-1">Matrícula</label>
         <input id="novo-usuario-matricula" type="text" placeholder="Número de matrícula do aluno ou servidor" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg bg-white font-medium mb-2">
         <label for="novo-usuario-email" class="block text-xs font-bold text-gray-700 mb-1">E-mail (opcional)</label>
         <input id="novo-usuario-email" type="email" placeholder="Para avisos de aprovação/recusa de agendamento" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg bg-white font-medium mb-2">
         <label for="novo-usuario-senha" class="block text-xs font-bold text-gray-700 mb-1">Senha de acesso</label>
         <input id="novo-usuario-senha" type="text" placeholder="Defina uma senha para essa pessoa" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg bg-white font-medium mb-2">
         <label for="novo-usuario-senha-confirmar" class="block text-xs font-bold text-gray-700 mb-1">Confirmar senha</label>
         <input id="novo-usuario-senha-confirmar" type="text" placeholder="Digite a mesma senha de novo" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg bg-white font-medium mb-2">
         <p class="text-xs text-gray-500 mb-2">Você vai precisar repassar essa matrícula e senha para o aluno ou servidor — é com elas que ele entra na área própria dele, no Calendário.</p>
         <div class="flex flex-wrap gap-2">
          <select id="novo-usuario-papel" class="px-3 py-2 border-2 border-green-300 rounded-lg bg-white"><option value="aluno">Aluno</option><option value="servidor">Servidor</option></select>
          <button onclick="cadastrarUsuarioAutorizado()" class="flex-1 px-4 py-3 rounded-lg bg-green-600 text-white font-bold text-sm whitespace-nowrap">Cadastrar</button>
         </div>
         <p id="usuario-cadastro-note" class="mt-2 text-xs text-gray-600">Só quem estiver cadastrado aqui e marcado como Ativo consegue agendar a sala pelo Calendário.</p>
        </div>
        <div class="min-w-0">
         <div class="flex flex-wrap items-end gap-3 mb-4">
          <div class="flex-1 basis-48 min-w-0">
           <label for="usuarios-busca" class="block text-xs font-bold text-gray-700 mb-1">Buscar por nome ou matrícula</label>
           <input id="usuarios-busca" type="search" oninput="renderUsuariosAutorizadosList()" placeholder="Ex.: Maria ou 2024109100001" class="w-full px-3 py-2 rounded-lg border-2 border-green-200 bg-white text-sm">
          </div>
          <div class="min-w-0 max-w-full">
           <label for="usuarios-filtro" class="block text-xs font-bold text-gray-700 mb-1">Situação</label>
           <select id="usuarios-filtro" onchange="renderUsuariosAutorizadosList()" class="max-w-full px-3 py-2 rounded-lg border-2 border-green-200 bg-white text-sm font-medium">
            <option value="aprovados">Cadastrados (ativos e inativos)</option>
            <option value="ativos">Só ativos</option>
            <option value="inativos">Só inativos</option>
            <option value="recusados">Pedidos recusados</option>
           </select>
          </div>
         </div>
         <p id="usuarios-contagem" class="text-xs text-gray-500 mb-2"></p>
         <div id="lista-usuarios-autorizados" class="space-y-2">
          <!-- gerado via JS: renderUsuariosAutorizadosList() -->
         </div>
        </div>
       </div>
      </div>
     </div>
     <?php endif; ?>
    </div>
