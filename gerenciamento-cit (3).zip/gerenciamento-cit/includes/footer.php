   </section><!-- Footer -->
   <footer class="gradient-dark-ifro text-white py-16 px-4">
    <div class="max-w-7xl mx-auto">
     <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
      <div>
       <div class="flex items-center gap-3 mb-4">
        <img src="<?= e(assetVersion('assets/img/logo-agendacit.png')) ?>" alt="AgendaCIT" width="56" height="56" class="w-14 h-14 object-contain">

        <div>
         <span id="footer-title" class="font-black text-lg">CIT IFRO</span> <span id="footer-institution" class="text-xs text-green-300 block font-bold"><?= e(INSTITUTION_NAME) ?></span>
        </div>
       </div>
       <p class="text-sm text-green-100">Sistema inteligente de agendamento para o Centro de Informática e Tecnologia.</p>
      </div>
      <div>
       <h4 class="font-bold mb-4 text-lg">Links Rápidos</h4>
       <ul class="space-y-2 text-sm text-green-100">
        <li><a href="index.php#inicio" class="hover:text-white transition-colors font-medium">Início</a></li>
        <li><a href="index.php#como-funciona" class="hover:text-white transition-colors font-medium">Como Funciona</a></li>
        <li><a href="index.php#calendario" class="hover:text-white transition-colors font-medium">Calendário</a></li>
        <li><a href="acesso.php" class="hover:text-white transition-colors font-medium">Minha Área</a></li>
       </ul>
      </div>
      <div>
       <?php if (isAuthenticated()): ?>
       <h4 class="font-bold mb-4 text-lg">Administração</h4>
       <ul class="space-y-2 text-sm text-green-100">
        <li><a href="index.php#admin" class="hover:text-white transition-colors font-medium">Área Administrativa</a></li>
        <li><a href="index.php#relatorios" class="hover:text-white transition-colors font-medium">Relatórios</a></li>
        <li><a href="index.php#contato" class="hover:text-white transition-colors font-medium">Suporte</a></li>
       </ul>
       <?php else: ?>
       <!-- Para aluno e visitante, os links da administração só levavam a
            uma tela de login que não era para eles. -->
       <h4 class="font-bold mb-4 text-lg">Ajuda</h4>
       <ul class="space-y-2 text-sm text-green-100">
        <li><a href="acesso.php" class="hover:text-white transition-colors font-medium">Área de login</a></li>
        <li><a href="acessibilidade.php" class="hover:text-white transition-colors font-medium">Acessibilidade</a></li>
        <li><a href="index.php#contato" class="hover:text-white transition-colors font-medium">Fale com a coordenação</a></li>
       </ul>
       <?php endif; ?>
      </div>
      <div>
       <h4 class="font-bold mb-4 text-lg">Horário de Funcionamento</h4>
       <ul class="space-y-2 text-sm text-green-100">
        <li class="font-medium">Segunda a Sexta: <?= e(HORARIO_ABERTURA) ?> às <?= e(HORARIO_FECHAMENTO) ?></li>
        <li class="font-medium">Sábado: fechado, exceto em eventos e atividades previamente agendadas</li>
        <li class="font-medium">Domingo: Fechado</li>
       </ul>
      </div>
     </div>
     <div class="border-t-2 border-green-400 pt-8 text-center text-sm text-green-100">
      <p class="font-medium">© <?= date('Y') ?> <?= e(SITE_TITLE) ?> - <?= e(INSTITUTION_NAME) ?>. Todos os direitos reservados.</p>
      <p class="mt-2 text-xs">Desenvolvido por
       <a href="https://github.com/cassiojubis" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 align-middle font-bold text-white underline underline-offset-2 hover:text-green-200">
        <?= icone('github', 'w-4 h-4') ?>
        Cassio Souza
       </a>
       e
       <a href="https://github.com/Namez-01" target="_blank" rel="noopener noreferrer" class="inline-flex items-center gap-1 align-middle font-bold text-white underline underline-offset-2 hover:text-green-200">
        <?= icone('github', 'w-4 h-4') ?>
        Sabrina Yumi
       </a>
      </p>
     </div>
    </div>
   </footer><!-- Rejection Reason Modal -->
   <div id="rejection-modal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl max-w-md w-full p-5 sm:p-8 shadow-2xl border-2 border-red-200">
     <div class="flex items-center justify-between mb-5">
      <h3 class="text-xl font-bold text-gray-800">Justificar recusa</h3><button type="button" onclick="closeRejectionModal()" class="p-2 hover:bg-red-50 rounded-lg" aria-label="Fechar">✕</button>
     </div>
     <p class="text-sm text-gray-600 mb-4">Explique ao solicitante por que este agendamento foi recusado.</p><label for="rejection-reason" class="block text-sm font-bold text-gray-700 mb-2">Motivo da recusa</label> <textarea id="rejection-reason" rows="4" required placeholder="Ex.: Sala reservada para manutenção no período informado." class="w-full px-4 py-3 border-2 border-red-200 rounded-lg focus:ring-2 focus:ring-red-400 font-medium"></textarea>
     <div class="flex flex-wrap gap-3 mt-5">
      <button type="button" onclick="closeRejectionModal()" class="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg text-gray-700 font-bold hover:bg-gray-50">Cancelar</button> <button type="button" id="confirm-rejection-btn" onclick="confirmRejection()" class="flex-1 px-4 py-3 bg-red-600 text-white rounded-lg font-bold hover:bg-red-700">Confirmar recusa</button>
     </div>
     <p id="rejection-note" class="mt-3 text-xs text-red-700 font-medium"></p>
    </div>
   </div><!-- Equipment Edit Modal -->
   <div id="equipment-edit-modal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl max-w-md w-full p-5 sm:p-8 fade-in max-h-[90%] overflow-auto shadow-2xl border-2 border-green-200">
     <div class="flex items-center justify-between mb-6">
      <h3 class="text-xl font-bold text-gray-800">Editar equipamento</h3><button type="button" onclick="closeEditEquipmentModal()" class="p-2 hover:bg-green-100 rounded-lg" aria-label="Fechar">✕</button>
     </div>
     <form id="equipment-edit-form" onsubmit="submitEditEquipment(event)">
      <input type="hidden" id="edit-equipment-id">
      <div class="space-y-4">
       <div>
        <label for="edit-equipment-name" class="block text-sm font-bold text-gray-700 mb-2">Nome</label>
        <input id="edit-equipment-name" type="text" required class="w-full px-4 py-3 border-2 border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 font-medium">
       </div>
       <div class="grid grid-cols-2 gap-3">
        <div>
         <label for="edit-equipment-type" class="block text-sm font-bold text-gray-700 mb-2">Tipo</label>
         <select id="edit-equipment-type" class="w-full px-3 py-3 border-2 border-green-300 rounded-lg font-medium">
          <option value="Informática">Informática</option>
          <option value="Audiovisual">Audiovisual</option>
          <option value="Mobiliário">Mobiliário</option>
          <option value="Outro">Outro</option>
         </select>
        </div>
        <div>
         <label for="edit-equipment-condition" class="block text-sm font-bold text-gray-700 mb-2">Situação</label>
         <select id="edit-equipment-condition" class="w-full px-3 py-3 border-2 border-green-300 rounded-lg font-medium">
          <option>Disponível</option>
          <option>Indisponível</option>
          <option>Em manutenção</option>
         </select>
        </div>
       </div>
       <div>
        <label for="edit-equipment-category" class="block text-sm font-bold text-gray-700 mb-2">Classificação</label>
        <input id="edit-equipment-category" type="text" placeholder="Ex.: Projeção" class="w-full px-4 py-3 border-2 border-green-300 rounded-lg font-medium">
       </div>
       <div>
        <label for="edit-equipment-quantity" class="block text-sm font-bold text-gray-700 mb-2">Quantidade total</label>
        <input id="edit-equipment-quantity" type="number" min="0" required class="w-full px-4 py-3 border-2 border-green-300 rounded-lg font-medium">
        <span id="edit-equipment-quantity-hint" class="block text-xs text-gray-500 mt-1"></span>
       </div>
       <div>
        <label for="edit-equipment-photo" class="block text-sm font-bold text-gray-700 mb-2">Trocar foto (opcional)</label>
        <input id="edit-equipment-photo" type="file" accept="image/*" class="w-full px-3 py-2.5 border-2 border-green-300 rounded-lg bg-white text-sm">
       </div>
      </div>
      <div class="flex flex-wrap gap-3 mt-6">
       <button type="button" onclick="closeEditEquipmentModal()" class="flex-1 px-4 py-3 border-2 border-gray-300 rounded-lg text-gray-700 font-bold hover:bg-gray-100 transition-colors">Cancelar</button>
       <button type="submit" class="flex-1 px-4 py-3 gradient-ifro text-white rounded-lg font-bold hover:shadow-lg transition-all">Salvar alterações</button>
      </div>
     </form>
    </div>
   </div><!-- Toast Notification -->
   <div id="toast" class="fixed bottom-4 left-1/2 -translate-x-1/2 w-[90%] max-w-sm text-center sm:left-auto sm:right-4 sm:translate-x-0 sm:w-auto sm:max-w-md sm:text-left gradient-ifro text-white px-6 py-3 rounded-lg shadow-xl transform translate-y-20 opacity-0 transition-all duration-300 z-50 font-bold border-2 border-green-300">
    <span id="toast-message"></span>
   </div>
  </div>
  <script>
    /**
     * Configuração vinda do servidor (config.php), consumida por
     * assets/js/script.js em applyConfig(). Mantém a fonte da verdade
     * dos textos institucionais no PHP, em vez de duplicá-los no JS.
     * is_admin informa ao script.js se quem está navegando é o
     * administrador autenticado via login.php (sessão PHP real) — usado
     * para não exigir o login de aluno/servidor (localStorage) de quem
     * já é administrador.
     */
    window.SERVER_CONFIG = <?php echo json_encode([
        'site_title'       => SITE_TITLE,
        'institution_name' => INSTITUTION_NAME,
        'contact_email'    => CONTACT_EMAIL,
        'contact_phone'    => CONTACT_PHONE,
        'is_admin'         => isAuthenticated(),
        'senha_min_caracteres' => SENHA_MIN_CARACTERES,
        'sessao_inatividade_segundos' => SESSAO_INATIVIDADE_SEGUNDOS,
        'horario_abertura'   => HORARIO_ABERTURA,
        'horario_fechamento' => HORARIO_FECHAMENTO,
    ], JSON_UNESCAPED_UNICODE); ?>;
  </script>
  <script src="<?= e(assetVersion('assets/js/acessibilidade.js')) ?>"></script>
  <?php if (isAuthenticated()): ?>
  <!-- Chart.js: gráficos da aba Relatórios, que só o administrador vê —
       visitantes não baixam a biblioteca. -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
  <?php endif; ?>
  <script src="<?= e(assetVersion('assets/js/script.js')) ?>"></script>
 </body>
</html>
