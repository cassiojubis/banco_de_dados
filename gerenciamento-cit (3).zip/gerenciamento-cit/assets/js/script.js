  /**
   * assets/js/script.js
   * -------------------------------------------------------------------
   * Lógica de interatividade do Sistema de Agendamento CIT.
   * O "banco de dados" deste sistema é o MySQL de verdade, acessado por
   * este arquivo através da API em PHP (api/records.php e
   * api/login_usuario.php) via fetch() — agendamentos, equipamentos,
   * cadastros de aluno/servidor e mensagens de contato são gravados no
   * banco e lidos de lá, não mais do localStorage do navegador. O
   * localStorage aqui só guarda duas coisas pequenas e não sensíveis:
   * preferências de acessibilidade e a sessão do aluno/servidor logado
   * neste navegador (CHAVE_USUARIO_LOGADO, mais abaixo).
   *
   * A autenticação do administrador (quem pode acessar esta página, e
   * quem pode chamar as ações restritas da API) é feita no lado do
   * servidor por config.php/login.php/api/_bootstrap.php; este arquivo
   * cuida apenas do comportamento da interface já autenticada.
   * -------------------------------------------------------------------
   */

  let bookings = [];
  let allRecords = [];
    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();
    let selectedDate = null;

    // Configuração padrão (fallback), usada caso window.SERVER_CONFIG
    // não tenha sido definido pelo footer.php — por exemplo, se este
    // script for aberto fora do fluxo normal da aplicação PHP.
    const defaultConfig = {
      site_title: 'Sistema de Agendamento CIT',
      institution_name: 'Instituto Federal de Rondônia',
      contact_email: 'cit@ifro.edu.br',
      contact_phone: '(69) 3211-0000'
    };

    // Mescla o padrão acima com o que veio do servidor (config.php),
    // dando prioridade aos valores do servidor quando existirem.
    const resolvedConfig = Object.assign({}, defaultConfig, window.SERVER_CONFIG || {});

    // Horário de funcionamento da sala — vem de config/config.php (via
    // window.SERVER_CONFIG), a mesma fonte que a API usa para validar e
    // que o rodapé mostra. A disponibilidade de cada dia é calculada a
    // partir dos agendamentos aprovados daquele dia — ver
    // calcularIntervalosLivres().
    const HORARIO_ABERTURA = resolvedConfig.horario_abertura || '08:00';
    const HORARIO_FECHAMENTO = resolvedConfig.horario_fechamento || '22:00';

    // Dias em que a sala pode ser agendada (mesma regra de
    // diaDeFuncionamento() em config/config.php): domingo nunca; sábado
    // só o administrador (eventos combinados); segunda a sexta, todos.
    // Devolve null se pode, ou o motivo (texto curto) se não pode.
    // comoAdmin: se a regra do sábado vale como admin (padrão: quem está
    // logado como admin). No formulário, só a reserva manual do painel é
    // "como admin" — pedido do aluno segue a regra do aluno.
    function motivoDiaFechado(dateStr, comoAdmin = Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin)) {
      const [ano, mes, dia] = dateStr.split('-').map(Number);
      const diaSemana = new Date(ano, mes - 1, dia).getDay();
      if (diaSemana === 0) return 'Fechado';
      if (diaSemana === 6 && !comoAdmin) return 'Só eventos';
      return null;
    }

    // Tamanho mínimo de senha de aluno/servidor — o mesmo valor de
    // SENHA_MIN_CARACTERES em config/config.php, que é quem realmente
    // valida (este aqui só evita uma ida ao servidor à toa).
    const SENHA_MIN_CARACTERES = (window.SERVER_CONFIG && window.SERVER_CONFIG.senha_min_caracteres) || 6;


    // Converte "HH:MM" em minutos desde 00:00, para facilitar
    // comparações e somas de horário.
    function paraMinutos(hhmm) {
      const [h, m] = hhmm.split(':').map(Number);
      return h * 60 + m;
    }

    // Converte minutos desde 00:00 de volta para o formato "HH:MM".
    function paraHHMM(minutos) {
      const h = Math.floor(minutos / 60);
      const m = minutos % 60;
      return String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0');
    }

    // Escapa caracteres especiais de HTML (<, >, &, aspas) antes de
    // inserir texto vindo do usuário (nome, finalidade, descrição etc.)
    // dentro de innerHTML. Sem isso, alguém poderia digitar algo como
    // "<script>...</script>" num campo de formulário público e esse
    // código seria executado na tela de quem visualizasse o dado (por
    // exemplo, o gestor vendo as solicitações pendentes) — um ataque
    // conhecido como XSS armazenado. Use em TODO texto de usuário
    // inserido via innerHTML.
    function escapeHtml(valor) {
      const texto = String(valor ?? '');
      const mapa = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
      return texto.replace(/[&<>"']/g, (c) => mapa[c]);
    }

    // Rótulo e cor do selo de cada situação de agendamento — um lugar só,
    // usado em todas as listas (antes cada lista tinha a sua versão, e a
    // Agenda do admin mostrava um recusado como "Pendente").
    function situacaoAgendamento(status) {
      return {
        approved: { texto: 'Aprovado', classe: 'bg-emerald-100 text-emerald-800' },
        pending: { texto: 'Pendente', classe: 'bg-amber-100 text-amber-800' },
        rejected: { texto: 'Recusado', classe: 'bg-red-100 text-red-800' },
        cancelled: { texto: 'Cancelado', classe: 'bg-gray-200 text-gray-700' }
      }[status] || { texto: status, classe: 'bg-gray-200 text-gray-700' };
    }

    // Motivo de recusa ou de cancelamento, quando quem está vendo tem
    // direito a ele (a API só manda para o admin e para o dono).
    function motivoDoAgendamento(b) {
      if (b.status === 'rejected' && b.rejection_reason) {
        return `<div class="text-xs text-red-700 mt-1 font-semibold">Motivo da recusa: ${escapeHtml(b.rejection_reason)}</div>`;
      }
      if (b.status === 'cancelled' && b.cancellation_reason) {
        return `<div class="text-xs text-gray-600 mt-1 font-semibold">Cancelado pelo responsável: ${escapeHtml(b.cancellation_reason)}</div>`;
      }
      return '';
    }

    // Calcula os intervalos livres de um dia, dentro do horário de
    // funcionamento — mesma regra de horariosLivres() em api/records.php:
    //   - aprovados E pendentes seguram o horário (o servidor recusa
    //     qualquer pedido sobreposto a um pendente; antes só os aprovados
    //     contavam aqui, e a tela oferecia horários que dariam erro);
    //   - o próximo intervalo começa exatamente quando a reserva termina
    //     (reserva até 10:00 libera a partir das 10:00 — antes era 10:01);
    //   - hoje, o que já passou não entra (arredondado para os próximos
    //     5 minutos).
    // Devolve [{ inicio, fim }] em minutos desde 00:00.
    function calcularIntervalosLivres(dateStr, ignorarAgendamentoId = null) {
      const ocupados = bookings
        .filter(b => b.date === dateStr && (b.status === 'approved' || b.status === 'pending'))
        .filter(b => b.__backendId !== ignorarAgendamentoId) // ao editar, o próprio não ocupa
        .map(b => ({ inicio: paraMinutos(b.start_time), fim: paraMinutos(b.end_time) }))
        .sort((a, b) => a.inicio - b.inicio);

      const livres = [];
      let cursor = paraMinutos(HORARIO_ABERTURA);
      const fechamento = paraMinutos(HORARIO_FECHAMENTO);

      const agora = new Date();
      const hojeStr = `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, '0')}-${String(agora.getDate()).padStart(2, '0')}`;
      if (dateStr === hojeStr) {
        cursor = Math.max(cursor, Math.ceil((agora.getHours() * 60 + agora.getMinutes()) / 5) * 5);
      }

      ocupados.forEach(({ inicio, fim }) => {
        if (inicio > cursor) {
          livres.push({ inicio: cursor, fim: Math.min(inicio, fechamento) });
        }
        cursor = Math.max(cursor, fim);
      });

      if (cursor < fechamento) {
        livres.push({ inicio: cursor, fim: fechamento });
      }

      return livres.filter(intervalo => intervalo.fim > intervalo.inicio);
    }

    // Aplica os textos institucionais (nome, e-mail, telefone) vindos da
    // configuração mesclada (servidor + padrão) aos elementos da página.
    // Nem toda página tem todos esses elementos (ex.: acesso.php e
    // acessibilidade.php não têm o bloco de contato do rodapé de
    // index.php) — por isso cada atribuição confere se o elemento
    // existe antes de usá-lo, em vez de assumir que está sempre lá.
    function applyConfig(config) {
      const institutionName = config.institution_name || defaultConfig.institution_name;
      const contactEmail = config.contact_email || defaultConfig.contact_email;
      const contactPhone = config.contact_phone || defaultConfig.contact_phone;

      const setText = (id, texto) => {
        const el = document.getElementById(id);
        if (el) el.textContent = texto;
      };

      setText('nav-institution', institutionName);
      setText('footer-institution', institutionName);
      setText('contact-email-display', contactEmail);
      setText('contact-phone-display', contactPhone);
    }

    // Busca em api/records.php todos os registros do banco (equivalente
    // ao antigo "allRecords" lido do localStorage) e atualiza as
    // variáveis em memória: allRecords (todos os tipos) e bookings
    // (apenas agendamentos).
    async function refreshRecords() {
      try {
        const resposta = await fetch('api/records.php', { credentials: 'same-origin' });
        const dados = await resposta.json().catch(() => []);
        allRecords = resposta.ok && Array.isArray(dados) ? dados : [];
        if (!resposta.ok) {
          showToast('❌ ' + ((dados && dados.erro) || 'Não foi possível carregar os dados do servidor.'));
        }
      } catch (erro) {
        allRecords = allRecords || [];
        showToast('❌ Falha de conexão com o servidor. Verifique sua internet e tente novamente.');
      }
      bookings = allRecords.filter(item => !item.record_type || item.record_type === 'booking');
    }

    // Rebusca os registros do banco (após uma criação/alteração/remoção
    // bem-sucedida) e dispara a atualização de toda a interface
    // (painéis públicos e administrativos).
    async function saveRecords() {
      await refreshRecords();
      updateUI();
      renderAdminPanels();
      renderUsuariosAutorizadosList();
      renderCadastrosPendentes();
    }

    // Helper genérico para chamar api/records.php: monta a URL com
    // tipo/id/acao, envia o corpo em JSON (quando houver) e devolve
    // { isOk, dados, erro } — nunca lança exceção, para os chamadores
    // poderem sempre exibir uma mensagem amigável em vez de travar.
    async function apiRequest(metodo, tipo, id, acao, corpo) {
      let url = `api/records.php?tipo=${encodeURIComponent(tipo)}`;
      if (id !== undefined && id !== null) url += `&id=${encodeURIComponent(id)}`;
      if (acao) url += `&acao=${encodeURIComponent(acao)}`;

      try {
        const opcoes = { method: metodo, credentials: 'same-origin' };
        if (corpo !== undefined) {
          opcoes.headers = { 'Content-Type': 'application/json' };
          opcoes.body = JSON.stringify(corpo);
        }
        const resposta = await fetch(url, opcoes);
        const dados = await resposta.json().catch(() => ({}));
        if (!resposta.ok) {
          return { isOk: false, status: resposta.status, erro: (dados && dados.erro) || 'Não foi possível concluir a operação.', dados };
        }
        return { isOk: true, dados };
      } catch (erro) {
        return { isOk: false, erro: 'Falha de conexão com o servidor. Verifique sua internet e tente novamente.' };
      }
    }

    // Recalcula e redesenha todos os blocos dinâmicos da página inicial
    // (estatísticas, listas, relatórios, calendário e horários do dia).
    function updateUI() {
      updateStats();
      updateBookingsList();
      updatePendingRequests();
      updateReports();
      updateActivityLog();
      renderCalendar();
      renderBookingEquipmentChoices();
      renderAreaUsuario();
      if (selectedDate) {
        updateTimeSlots(selectedDate);
      }
    }

    // Atualiza os contadores do hero (disponíveis/ocupados/pendentes) com
    // base nos agendamentos aprovados e pendentes.
    function updateStats() {
      const statAvailableEl = document.getElementById('stat-available');
      // Esses cartões de estatística só existem na página inicial (ver
      // includes/main-content.php) — em outras páginas (acesso.php,
      // acessibilidade.php) não há o que atualizar aqui.
      if (!statAvailableEl) return;

      // Painel "Hoje" do topo, com dados reais (antes eram números de uma
      // capacidade estimada e horários de exemplo fixos no HTML).
      const agora = new Date();
      const p = n => String(n).padStart(2, '0');
      const hoje = `${agora.getFullYear()}-${p(agora.getMonth() + 1)}-${p(agora.getDate())}`;
      const deHoje = bookings
        .filter(b => b.date === hoje && (b.status === 'approved' || b.status === 'pending'))
        .sort((a, b) => a.start_time.localeCompare(b.start_time));
      const fechado = motivoDiaFechado(hoje, false);
      const livres = fechado ? [] : calcularIntervalosLivres(hoje);
      const minutosLivres = livres.reduce((t, l) => t + (l.fim - l.inicio), 0);
      const pendentesFuturos = bookings.filter(b => b.status === 'pending' && b.date >= hoje).length;

      statAvailableEl.textContent = fechado ? '—' : (minutosLivres % 60 ? `${Math.floor(minutosLivres / 60)}h${p(minutosLivres % 60)}` : `${minutosLivres / 60}h`);
      document.getElementById('stat-occupied').textContent = deHoje.filter(b => b.status === 'approved').length;
      document.getElementById('stat-pending').textContent = pendentesFuturos;

      const titulo = document.getElementById('painel-hoje-titulo');
      if (titulo) {
        const diaSemana = agora.toLocaleDateString('pt-BR', { weekday: 'long' });
        titulo.textContent = `Hoje · ${diaSemana.charAt(0).toUpperCase() + diaSemana.slice(1)}, ${formatDate(hoje)}`;
      }

      const lista = document.getElementById('painel-hoje-lista');
      if (!lista) return;
      const linha = (cor, horario, texto) => `
        <div class="bg-white/10 rounded-lg p-3 flex items-center gap-3 border border-white/10">
          <div class="w-3 h-3 ${cor} rounded-full flex-shrink-0"></div>
          <div class="flex-1 min-w-0">
            <div class="text-sm font-semibold">${horario}</div>
            <div class="text-xs text-green-200 truncate">${texto}</div>
          </div>
        </div>`;

      if (fechado) {
        lista.innerHTML = `<p class="text-sm text-green-100">${fechado === 'Fechado' ? 'O CIT não abre aos domingos.' : 'Sábado: o CIT só abre para eventos combinados com a coordenação.'} Veja os próximos dias no calendário.</p>`;
        return;
      }
      // Reservas e pedidos de hoje + os intervalos livres, em ordem.
      const itens = [
        ...deHoje.map(b => ({
          inicio: paraMinutos(b.start_time),
          html: b.status === 'approved'
            ? linha('bg-red-400', `${b.start_time} - ${b.end_time}`, b.responsible ? `${escapeHtml(b.purpose)} - ${escapeHtml(b.responsible)}` : 'Reservado')
            : linha('bg-amber-400', `${b.start_time} - ${b.end_time}`, 'Aguardando aprovação')
        })),
        ...livres.map(l => ({ inicio: l.inicio, html: linha('bg-emerald-300', `${paraHHMM(l.inicio)} - ${paraHHMM(l.fim)}`, 'Livre para agendamento') }))
      ].sort((a, b) => a.inicio - b.inicio);

      lista.innerHTML = itens.length
        ? itens.slice(0, 4).map(i => i.html).join('') + (itens.length > 4 ? `<a href="#calendario" class="block text-xs text-green-100 underline mt-1">Ver o dia completo no calendário</a>` : '')
        : '<p class="text-sm text-green-100">O horário de funcionamento de hoje já terminou. Veja os próximos dias no calendário.</p>';
    }

    // Renderiza a lista de "Agendamentos Registrados", ordenada por data,
    // limitada aos 10 mais próximos.
    function updateBookingsList() {
      const container = document.getElementById('bookings-list');
      const countEl = document.getElementById('booking-count');
      // Essa lista só existe na página inicial (ver
      // includes/main-content.php) — em outras páginas não há o que
      // atualizar aqui.
      if (!container || !countEl) return;
      const titulo = document.getElementById('bookings-list-title');
      const isAdmin = Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin);
      const sessao = obterUsuarioLogado();

      // Aluno/servidor logado: a lista vira "Meus agendamentos", com
      // Editar/Cancelar/Adicionar ao calendário — o lugar mais fácil de
      // achar os próprios pedidos (antes só existia em acesso.php).
      if (sessao) {
        if (titulo) titulo.textContent = 'Meus agendamentos';
        const meus = meusAgendamentos(sessao);
        countEl.textContent = `${meus.length} agendamento${meus.length !== 1 ? 's' : ''}`;
        container.innerHTML = htmlMeusAgendamentos(sessao);
        return;
      }

      // Visitante sem login: a lista geral (com nome, finalidade e
      // equipamentos de todo mundo, inclusive pedidos ainda em análise)
      // não aparece mais — o calendário já mostra a ocupação dos dias.
      if (!isAdmin) {
        if (titulo) titulo.textContent = 'Meus agendamentos';
        countEl.textContent = '';
        countEl.classList.add('hidden');
        container.innerHTML = `
          <div class="text-center py-6">
            <p class="text-gray-600 text-sm mb-3">Entre com sua matrícula para ver, editar e cancelar os seus agendamentos.</p>
            <a href="acesso.php" class="inline-block px-5 py-2.5 rounded-lg bg-green-700 text-white font-semibold text-sm hover:bg-green-800">Entrar</a>
          </div>`;
        return;
      }
      countEl.classList.remove('hidden');

      // Administrador: todos os agendamentos (o painel também tem a Agenda).
      if (titulo) titulo.textContent = 'Agendamentos Registrados';
      countEl.textContent = `${bookings.length} agendamento${bookings.length !== 1 ? 's' : ''}`;

      if (bookings.length === 0) {
        container.innerHTML = '<p class="text-gray-500 text-sm text-center py-4 font-medium">Nenhum agendamento registrado ainda.</p>';
        return;
      }

      const sortedBookings = [...bookings].sort((a, b) => new Date(a.date) - new Date(b.date));

      // Mesmo visual dos cards usados na aba "Agenda" da Central de
      // Gerenciamento (renderAdminPanels), sem o botão Excluir — que
      // é exclusivo da área administrativa.
      container.innerHTML = sortedBookings.slice(0, 10).map(booking => {
        const { texto: statusText, classe: statusClass } = situacaoAgendamento(booking.status);

        return `
          <div class="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl border border-green-200 mb-3">
            <div>
              <strong class="text-gray-800">${escapeHtml(booking.responsible)}</strong>
              <div class="text-sm text-gray-600 font-medium">${formatDate(booking.date)} • ${escapeHtml(booking.time_slot)} • ${escapeHtml(booking.purpose)}</div>
              ${booking.participants ? `<div class="text-xs text-gray-500">${booking.participants} participante${booking.participants !== 1 ? 's' : ''}</div>` : ''}
              ${(booking.equipment_quantities || booking.equipment_requests) ? `<div class="text-xs text-gray-500 mt-1">Equipamentos:${renderEquipmentColumns(booking.equipment_quantities, booking.equipment_requests)}</div>` : ''}
            </div>
            <span class="px-3 py-1 text-xs font-bold rounded-full ${statusClass}">${statusText}</span>
          </div>
        `;
      }).join('');
    }

    // Renderiza o painel de solicitações pendentes na área administrativa,
    // com os botões de aprovar/recusar.
    function updatePendingRequests() {
      const container = document.getElementById('pending-requests');
      // Sem login, a seção Administração nem é renderizada no HTML
      // (ver includes/main-content.php) — não há o que atualizar aqui.
      if (!container) return;
      const pendingBookings = bookings.filter(b => b.status === 'pending');
      
      if (pendingBookings.length === 0) {
        container.innerHTML = '<p class="text-gray-600 text-sm text-center py-4 font-medium">Nenhuma solicitação pendente.</p>';
        return;
      }

      container.innerHTML = pendingBookings.map(booking => {
        const equipamentosHtml = renderEquipmentColumns(booking.equipment_quantities, booking.equipment_requests);
        return `
        <div class="bg-white rounded-lg p-4 border-2 border-green-200">
          <div class="flex flex-wrap items-start justify-between gap-2 mb-2">
            <div>
              <div class="font-bold text-gray-800">${escapeHtml(booking.responsible)}</div>
              <div class="text-sm text-gray-600 font-medium">${formatDate(booking.date)} • ${escapeHtml(booking.time_slot)}</div>
            </div>
            <span class="px-2 py-1 text-xs bg-amber-100 text-amber-800 rounded-full font-bold">${escapeHtml(booking.purpose)}</span>
          </div>
          ${booking.description ? `<p class="text-sm text-gray-600 mb-3 font-medium">${escapeHtml(booking.description)}</p>` : ''}
          <div class="mb-3 rounded-lg bg-green-50 border border-green-200 px-3 py-2 text-sm text-green-800 font-semibold">
            Equipamentos solicitados:${equipamentosHtml || ' Nenhum'}
          </div>
          <div class="flex flex-wrap gap-2">
            <button onclick="approveBooking('${booking.__backendId}')" class="flex-1 px-3 py-2 gradient-ifro text-white text-sm rounded-lg hover:shadow-lg transition-all font-bold">
              Aprovar
            </button>
            <button onclick="openRejectionModal('${booking.__backendId}')" class="flex-1 px-3 py-2 border-2 border-red-200 text-red-700 text-sm rounded-lg hover:bg-red-50 transition-colors font-bold">
              Recusar
            </button>
          </div>
        </div>
      `;
      }).join('');
    }

    // Recalcula os indicadores da seção de Relatórios: total, aprovados,
    // pendentes, taxa de ocupação e o gráfico de barras por finalidade.
    function updateReports() {
      const totalEl = document.getElementById('report-total');
      // Sem login, a seção Relatórios nem é renderizada no HTML (ver
      // includes/main-content.php) — não há o que atualizar aqui.
      if (!totalEl) return;

      const total = bookings.length;
      const approved = bookings.filter(b => b.status === 'approved').length;
      const pending = bookings.filter(b => b.status === 'pending').length;
      // Taxa de ocupação do MÊS ATUAL: horas aprovadas ÷ horas de
      // funcionamento do mês (dias de segunda a sexta × horário de
      // abertura a fechamento). Antes usava uma "capacidade estimada"
      // fixa de 180 reservas, que não correspondia a nada real.
      const agora = new Date();
      const prefixoMes = `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, '0')}`;
      const diasNoMes = new Date(agora.getFullYear(), agora.getMonth() + 1, 0).getDate();
      let diasUteis = 0;
      for (let d = 1; d <= diasNoMes; d++) {
        const semana = new Date(agora.getFullYear(), agora.getMonth(), d).getDay();
        if (semana !== 0 && semana !== 6) diasUteis++;
      }
      const minutosDoMes = diasUteis * (paraMinutos(HORARIO_FECHAMENTO) - paraMinutos(HORARIO_ABERTURA));
      const minutosAprovados = bookings
        .filter(b => b.status === 'approved' && b.date.startsWith(prefixoMes))
        .reduce((t, b) => t + paraMinutos(b.end_time) - paraMinutos(b.start_time), 0);
      const rate = minutosDoMes > 0 ? Math.round(minutosAprovados / minutosDoMes * 100) : 0;

      document.getElementById('report-total').textContent = total;
      document.getElementById('report-approved').textContent = approved;
      document.getElementById('report-pending').textContent = pending;
      document.getElementById('report-rate').textContent = Math.min(rate, 100) + '%';

      const purposes = ['Aula', 'Projeto', 'Reunião', 'Treinamento'];
      const maxCount = Math.max(...purposes.map(p => bookings.filter(b => b.purpose === p).length), 1);

      purposes.forEach(purpose => {
        const count = bookings.filter(b => b.purpose === purpose).length;
        const barId = 'bar-' + purpose.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        const countId = 'count-' + purpose.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
        
        const barEl = document.getElementById(barId);
        const countEl = document.getElementById(countId);
        
        if (barEl) barEl.style.width = (count / maxCount * 100) + '%';
        if (countEl) countEl.textContent = count;
      });

      const othersCount = bookings.filter(b => !purposes.includes(b.purpose)).length;
      const barOutros = document.getElementById('bar-outros');
      const countOutros = document.getElementById('count-outros');
      if (barOutros) barOutros.style.width = (othersCount / maxCount * 100) + '%';
      if (countOutros) countOutros.textContent = othersCount;

      carregarEstatisticas();
    }

    // ---------------------------------------------------------------
    // Gráficos da aba Relatórios (Chart.js, carregado só para o admin —
    // ver includes/footer.php), com os números de
    // api/records.php?tipo=estatisticas:
    //   - Ocupação por dia da semana: barras, um tom só (verde IFRO).
    //   - Equipamentos mais pedidos: barras horizontais (nomes longos e
    //     comparação de ranking ficam melhores assim que em pizza).
    //   - Situação: rosca com as cores de status (aprovado/pendente/
    //     recusado), sempre com o rótulo escrito na legenda e na tabela —
    //     a cor nunca é a única pista.
    // Cada gráfico tem a mesma informação em tabela ("Ver como tabela").
    // ---------------------------------------------------------------
    const graficos = {};
    let estatisticasEmAndamento = null;

    // Cores do gráfico para o tema atual (o modo escuro do site é a
    // classe "dark" no <html> — ver assets/js/acessibilidade.js).
    function coresGrafico() {
      const escuro = document.documentElement.classList.contains('dark');
      return {
        barra: escuro ? '#22c55e' : '#15803d',
        superficie: escuro ? '#1e293b' : '#ffffff',
        texto: escuro ? '#cbd5e1' : '#52514e',
        grade: escuro ? '#334155' : '#e1e0d9',
        // Cancelado: cinza neutro — não é bom nem ruim, só saiu da agenda.
        status: { aprovados: '#0ca30c', pendentes: '#fab219', recusados: '#d03b3b', cancelados: escuro ? '#64748b' : '#94a3b8' }
      };
    }

    function tabelaSimples(cabecalho, linhas) {
      return `<div class="overflow-x-auto"><table class="w-full text-sm"><thead><tr>${cabecalho.map((c, i) =>
        `<th class="text-left font-semibold text-gray-600 py-1 ${i ? 'text-right' : ''}">${escapeHtml(c)}</th>`).join('')}</tr></thead>
        <tbody>${linhas.map(l => `<tr class="border-t border-gray-200">${l.map((c, i) =>
          `<td class="py-1 text-gray-800 ${i ? 'text-right tabular-nums' : ''}">${escapeHtml(String(c))}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
    }

    function desenharGrafico(id, config) {
      const canvas = document.getElementById(id);
      if (!canvas || typeof Chart === 'undefined') return;
      if (graficos[id]) graficos[id].destroy();
      graficos[id] = new Chart(canvas, config);
    }

    async function carregarEstatisticas() {
      // Só existe para o admin (canvas e Chart.js só vêm para ele).
      if (!document.getElementById('grafico-ocupacao') || typeof Chart === 'undefined') return;
      // updateUI() roda várias vezes seguidas; uma busca por vez basta.
      if (estatisticasEmAndamento) return estatisticasEmAndamento;

      estatisticasEmAndamento = (async () => {
        try {
          const resposta = await fetch('api/records.php?tipo=estatisticas', { credentials: 'same-origin' });
          if (!resposta.ok) return;
          window.__ultimasEstatisticas = await resposta.json();
          desenharEstatisticas(window.__ultimasEstatisticas);
        } catch (erro) {
          // Sem conexão: os gráficos ficam como estavam.
        } finally {
          estatisticasEmAndamento = null;
        }
      })();
      return estatisticasEmAndamento;
    }

    function desenharEstatisticas(dados) {
      if (!dados) return;
      const cor = coresGrafico();
      Chart.defaults.font.family = 'Montserrat, system-ui, sans-serif';
      Chart.defaults.color = cor.texto;

      const eixos = (horizontal) => ({
        x: { grid: { display: horizontal, color: cor.grade }, border: { color: cor.grade },
             ticks: { precision: 0 }, beginAtZero: true },
        y: { grid: { display: !horizontal, color: cor.grade }, border: { display: false },
             ticks: { precision: 0 }, beginAtZero: true }
      });
      const barras = (rotulo, valores, horizontal) => ({
        label: rotulo,
        data: valores,
        backgroundColor: cor.barra,
        borderRadius: { topLeft: horizontal ? 0 : 4, topRight: 4, bottomRight: horizontal ? 4 : 0, bottomLeft: 0 },
        borderSkipped: 'start',
        maxBarThickness: 28
      });

      // 1. Ocupação por dia da semana
      const dias = dados.ocupacao_por_dia || [];
      desenharGrafico('grafico-ocupacao', {
        type: 'bar',
        data: { labels: dias.map(d => d.dia.slice(0, 3)), datasets: [barras('Agendamentos aprovados', dias.map(d => d.total), false)] },
        options: {
          responsive: true, maintainAspectRatio: false, animation: false,
          plugins: { legend: { display: false },
            tooltip: { callbacks: { title: itens => dias[itens[0].dataIndex].dia,
              label: item => ` ${item.parsed.y} agendamento${item.parsed.y !== 1 ? 's' : ''} aprovado${item.parsed.y !== 1 ? 's' : ''}` } } },
          scales: eixos(false)
        }
      });
      const tabelaOcupacao = document.getElementById('tabela-ocupacao');
      if (tabelaOcupacao) tabelaOcupacao.innerHTML = tabelaSimples(['Dia', 'Aprovados'], dias.map(d => [d.dia, d.total]));

      // 2. Equipamentos mais pedidos
      const equipamentos = dados.equipamentos || [];
      const tabelaEquip = document.getElementById('tabela-equipamentos');
      if (!equipamentos.length) {
        if (graficos['grafico-equipamentos']) { graficos['grafico-equipamentos'].destroy(); delete graficos['grafico-equipamentos']; }
        const canvas = document.getElementById('grafico-equipamentos');
        if (canvas) canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
        if (tabelaEquip) tabelaEquip.innerHTML = '<p class="text-gray-500">Nenhum equipamento foi pedido ainda.</p>';
      } else {
        desenharGrafico('grafico-equipamentos', {
          type: 'bar',
          data: { labels: equipamentos.map(e => e.nome.length > 22 ? e.nome.slice(0, 21) + '…' : e.nome),
                  datasets: [barras('Pedidos', equipamentos.map(e => e.pedidos), true)] },
          options: {
            indexAxis: 'y', responsive: true, maintainAspectRatio: false, animation: false,
            plugins: { legend: { display: false },
              tooltip: { callbacks: { title: itens => equipamentos[itens[0].dataIndex].nome,
                label: item => {
                  const e = equipamentos[item.dataIndex];
                  return ` ${e.pedidos} pedido${e.pedidos !== 1 ? 's' : ''} · ${e.unidades} unidade${e.unidades !== 1 ? 's' : ''}`;
                } } } },
            scales: eixos(true)
          }
        });
        if (tabelaEquip) tabelaEquip.innerHTML = tabelaSimples(['Equipamento', 'Pedidos', 'Unidades'], equipamentos.map(e => [e.nome, e.pedidos, e.unidades]));
      }

      // 3. Situação dos agendamentos
      const s = dados.situacao || { aprovados: 0, pendentes: 0, recusados: 0, cancelados: 0 };
      const fatias = [
        { rotulo: 'Aprovados', valor: s.aprovados, cor: cor.status.aprovados },
        { rotulo: 'Pendentes', valor: s.pendentes, cor: cor.status.pendentes },
        { rotulo: 'Recusados', valor: s.recusados, cor: cor.status.recusados },
        { rotulo: 'Cancelados', valor: s.cancelados || 0, cor: cor.status.cancelados }
      ];
      const totalSituacao = fatias.reduce((t, f) => t + f.valor, 0);
      const porcento = v => totalSituacao ? Math.round(v / totalSituacao * 100) : 0;
      desenharGrafico('grafico-situacao', {
        type: 'doughnut',
        data: {
          labels: fatias.map(f => `${f.rotulo}: ${f.valor} (${porcento(f.valor)}%)`),
          datasets: [{
            data: totalSituacao ? fatias.map(f => f.valor) : [1],
            backgroundColor: totalSituacao ? fatias.map(f => f.cor) : [cor.grade],
            borderColor: cor.superficie, borderWidth: 2, hoverOffset: 4
          }]
        },
        options: {
          responsive: true, maintainAspectRatio: false, animation: false, cutout: '62%',
          plugins: {
            legend: { position: 'bottom', labels: { boxWidth: 12, boxHeight: 12, usePointStyle: true, pointStyle: 'rectRounded',
              generateLabels: totalSituacao ? undefined : () => [{ text: 'Nenhum agendamento ainda', fillStyle: cor.grade, strokeStyle: cor.grade, fontColor: cor.texto }] } },
            tooltip: { enabled: totalSituacao > 0, callbacks: { label: item => ` ${fatias[item.dataIndex].rotulo}: ${fatias[item.dataIndex].valor} (${porcento(fatias[item.dataIndex].valor)}%)` } }
          }
        }
      });
      const tabelaSituacao = document.getElementById('tabela-situacao');
      if (tabelaSituacao) tabelaSituacao.innerHTML = tabelaSimples(['Situação', 'Agendamentos', '%'],
        [...fatias.map(f => [f.rotulo, f.valor, porcento(f.valor) + '%']), ['Total', totalSituacao, totalSituacao ? '100%' : '0%']]);
    }

    // Trocar o modo escuro redesenha os gráficos com as cores do novo tema.
    new MutationObserver(() => desenharEstatisticas(window.__ultimasEstatisticas))
      .observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });

    // Mostra as últimas atividades (agendamentos criados/aprovados) em
    // ordem cronológica decrescente, com tempo relativo ("há 5min" etc.).
    function updateActivityLog() {
      const container = document.getElementById('activity-log');
      // Sem login, a seção Relatórios nem é renderizada no HTML (ver
      // includes/main-content.php) — não há o que atualizar aqui.
      if (!container) return;

      const recentBookings = [...bookings].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 5);
      
      if (recentBookings.length === 0) {
        container.innerHTML = '<p class="text-gray-600 text-sm text-center py-4 font-medium">Nenhuma atividade registrada.</p>';
        return;
      }

      container.innerHTML = recentBookings.map(booking => {
        const action = booking.status === 'approved' ? 'aprovado' : 'solicitado';
        return `
          <div class="flex items-center gap-3 text-sm">
            <div class="w-2 h-2 rounded-full ${booking.status === 'approved' ? 'bg-emerald-500' : 'bg-amber-500'}"></div>
            <span class="flex-1 text-gray-600 font-medium">
              <strong class="text-gray-800">${escapeHtml(booking.responsible)}</strong> ${action} agendamento para ${formatDate(booking.date)}
            </span>
            <span class="text-gray-400 text-xs font-medium">${getRelativeTime(booking.created_at)}</span>
          </div>
        `;
      }).join('');
    }

    // Desenha os dias do mês corrente no calendário interativo, marcando
    // dias com agendamentos aprovados/pendentes e o dia selecionado.
    function renderCalendar() {
      const container = document.getElementById('calendar-days');
      // O calendário só existe na página inicial (ver
      // includes/main-content.php) — em outras páginas não há o que
      // desenhar aqui.
      if (!container) return;

      const monthNames = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

      document.getElementById('calendar-month').textContent = `${monthNames[currentMonth]} ${currentYear}`;
      
      const firstDay = new Date(currentYear, currentMonth, 1).getDay();
      const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
      const today = new Date();
      
      let html = '';
      
      for (let i = 0; i < firstDay; i++) {
        html += '<div class="p-2"></div>';
      }
      
      for (let day = 1; day <= daysInMonth; day++) {
        const dateStr = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        // Só aprovados e pendentes contam no calendário: recusado e
        // cancelado não ocupam a sala (antes entravam aqui e o nome de quem
        // teve o pedido recusado aparecia no dia como se tivesse agendado).
        const dayBookings = bookings.filter(b => b.date === dateStr && (b.status === 'approved' || b.status === 'pending'));
        const hasApproved = dayBookings.some(b => b.status === 'approved');
        const hasPending = dayBookings.some(b => b.status === 'pending');
        const isToday = today.getDate() === day && today.getMonth() === currentMonth && today.getFullYear() === currentYear;
        const isSelected = selectedDate === dateStr;
        // new Date(currentYear, currentMonth, day) usa o fuso local; new
        // Date('AAAA-MM-DD') seria meia-noite em UTC, que em Rondônia
        // (UTC-4) cai antes da meia-noite local e marcava o próprio dia
        // de hoje como "passado" (bloqueado no calendário).
        const isPast = new Date(currentYear, currentMonth, day) < new Date(today.getFullYear(), today.getMonth(), today.getDate());
        // Domingo (e sábado, para quem não é administrador): sala fechada
        // — fica cinza e não abre os horários, igual a um dia passado.
        const motivoFechado = motivoDiaFechado(dateStr);
        const bloqueado = isPast || motivoFechado !== null;
        
        let statusDot = '';
        if (hasApproved && hasPending) {
          statusDot = '<div class="flex gap-0.5 justify-center mt-1"><div class="w-2 h-2 bg-red-500 rounded-full"></div><div class="w-2 h-2 bg-amber-500 rounded-full"></div></div>';
        } else if (hasApproved) {
          statusDot = '<div class="w-2 h-2 bg-red-500 rounded-full mx-auto mt-1"></div>';
        } else if (hasPending) {
          statusDot = '<div class="w-2 h-2 bg-amber-500 rounded-full mx-auto mt-1"></div>';
        } else if (!bloqueado) {
          statusDot = '<div class="w-2 h-2 bg-emerald-500 rounded-full mx-auto mt-1"></div>';
        }
        
        // Nome no dia só de quem já tem horário APROVADO (sem repetir a
        // mesma pessoa). Pedido pendente ainda não é reserva: aparece como
        // "Em análise". Dia sem nenhum intervalo livre: "Lotado".
        const nomesAprovados = [...new Set(dayBookings.filter(b => b.status === 'approved').map(b => b.responsible).filter(Boolean))];
        const professorNames = escapeHtml(nomesAprovados.slice(0, 2).join(', ') + (nomesAprovados.length > 2 ? ` +${nomesAprovados.length - 2}` : ''));
        const lotado = dayBookings.length > 0 && !bloqueado && calcularIntervalosLivres(dateStr).length === 0;
        // Para o visitante sem login a API não manda o nome: dia com
        // reserva aprovada aparece só como "Reservado".
        const rotuloDia = lotado ? 'Lotado'
          : professorNames || (hasApproved ? 'Reservado' : hasPending ? 'Em análise' : (motivoFechado || 'Livre'));
        const dicaDia = professorNames ? `Reservado por: ${professorNames}${hasPending ? ' (e pedido em análise)' : ''}`
          : hasApproved ? 'Horário reservado'
          : hasPending ? 'Pedido aguardando aprovação da coordenação'
          : motivoFechado ? (motivoFechado === 'Fechado' ? 'CIT fechado aos domingos' : 'Sábado: só eventos combinados com a coordenação')
          : 'Sem agendamentos';
        html += `
          <button onclick="selectDate('${dateStr}')" title="${dicaDia}${lotado ? ' — dia lotado' : ''}" class="min-w-0 p-1 sm:px-1 sm:py-2 xl:p-3 min-h-[52px] sm:min-h-[88px] rounded-lg transition-all font-bold border-2 text-left ${isSelected ? 'gradient-ifro text-white border-green-600' : isToday ? 'bg-green-100 text-green-800 border-green-300' : bloqueado ? 'text-gray-300 cursor-not-allowed border-gray-200' : 'border-gray-200 hover:border-green-300 hover:bg-green-50'}" ${bloqueado ? 'disabled' : ''}>
            <div class="text-sm text-center whitespace-nowrap">${day}</div>
            ${statusDot}
            <!-- No celular a célula é estreita demais para texto: fica só o
                 número e a bolinha de status (a legenda explica as cores). -->
            <div class="hidden sm:block mt-2"><div class="text-[0.7rem] leading-tight text-center line-clamp-2 break-words ${isSelected ? 'text-white' : 'text-gray-500'}">${rotuloDia}</div></div>
          </button>
        `;
      }
      
      container.innerHTML = html;
    }

    // Avança ou retrocede o calendário em um mês (delta = 1 ou -1),
    // ajustando o ano quando necessário.
    function changeMonth(delta) {
      currentMonth += delta;
      if (currentMonth > 11) {
        currentMonth = 0;
        currentYear++;
      } else if (currentMonth < 0) {
        currentMonth = 11;
        currentYear--;
      }
      renderCalendar();
    }

    // Alterna o card do calendário entre o tamanho normal (encaixado no
    // layout de 3 colunas) e um modo expandido, que ocupa quase toda a
    // tela — útil em telas menores, onde os dias ficam bem apertados.
    function toggleCalendarioExpandido() {
      const card = document.getElementById('calendario-card');
      const botao = document.getElementById('btn-expandir-calendario');
      if (!card || !botao) return;

      const expandido = card.classList.toggle('calendario-expandido');
      card.classList.toggle('fixed', expandido);
      card.classList.toggle('inset-3', expandido);
      card.classList.toggle('md:inset-10', expandido);
      card.classList.toggle('z-50', expandido);
      card.classList.toggle('overflow-y-auto', expandido);
      card.classList.toggle('min-h-[620px]', !expandido);

      botao.title = expandido ? 'Recolher calendário' : 'Expandir calendário';
      // Trava a rolagem da página por trás do calendário aberto (quem rola
      // é o <html>, não o <body>).
      document.documentElement.classList.toggle('overflow-hidden', expandido);
    }

    // Marca uma data como selecionada no calendário e exibe os horários
    // daquele dia no painel lateral.
    function selectDate(dateStr) {
      selectedDate = dateStr;
      document.getElementById('selected-date').textContent = '· ' + formatDate(dateStr);
      updateTimeSlots(dateStr);
      renderCalendar();
      // Em telas estreitas (celular/tablet) o painel de horários fica
      // ABAIXO do calendário, então ao clicar num dia a pessoa não via que
      // ele tinha se preenchido — parecia que um dia já reservado não
      // mostrava horário nenhum. Trazemos o painel à vista para ela ver na
      // hora os horários livres, inclusive de um dia que já tem reserva.
      if (window.innerWidth < 1024) {
        const painel = document.getElementById('time-slots');
        if (painel) painel.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }

    // Mostra, para a data selecionada, os horários já reservados
    // naquele dia (aprovados ou pendentes) e os intervalos livres
    // calculados por calcularIntervalosLivres — em vez dos antigos 6
    // blocos fixos de 2h. Clicar num intervalo livre abre o modal de
    // agendamento já com aquele início/término preenchidos.
    function updateTimeSlots(dateStr) {
      const container = document.getElementById('time-slots');
      if (!container) return;

      const dayBookings = bookings
        .filter(b => b.date === dateStr && (b.status === 'approved' || b.status === 'pending'))
        .filter(b => b.__backendId !== editandoAgendamentoId) // ao editar, o próprio não ocupa
        .sort((a, b) => a.start_time.localeCompare(b.start_time));

      const livres = calcularIntervalosLivres(dateStr, editandoAgendamentoId);

      let html = '';

      if (dayBookings.length) {
        html += '<p class="text-xs font-bold text-gray-500 uppercase mb-1">Já reservado</p>';
        html += dayBookings.map(booking => {
          const aprovado = booking.status === 'approved';
          const statusClass = aprovado ? 'bg-red-500' : 'bg-amber-500';
          // Visitante sem login não recebe o nome (a API manda null): mostra só "Reservado".
          const quem = booking.responsible ? ` - ${escapeHtml(booking.responsible)}` : '';
          const statusText = aprovado
            ? (booking.responsible ? `${escapeHtml(booking.purpose)}${quem}` : 'Reservado')
            : `Aguardando aprovação${quem}`;
          const bgClass = aprovado ? 'bg-red-50 border-red-200' : 'bg-amber-50 border-amber-200';
          return `
            <div class="p-3 rounded-lg border-2 ${bgClass} transition-all mb-2">
              <div class="flex items-center gap-2">
                <div class="w-2 h-2 rounded-full ${statusClass}"></div>
                <span class="font-bold text-gray-800">${booking.start_time} - ${booking.end_time}</span>
              </div>
              <div class="text-xs text-gray-600 mt-1 font-medium">${statusText}</div>
              <button onclick="showBookingDetails('${booking.__backendId}'); event.stopPropagation();" class="mt-2 text-xs font-bold text-green-700 underline">Ver detalhes</button>
            </div>
          `;
        }).join('');
      }

      html += '<p class="text-xs font-bold text-gray-500 uppercase mt-3 mb-1">Horários disponíveis</p>';

      if (!livres.length) {
        html += '<p class="text-gray-600 text-sm">Nenhum horário livre nesse dia.</p>';
      } else {
        html += livres.map(({ inicio, fim }) => {
          const inicioStr = paraHHMM(inicio);
          const fimStr = paraHHMM(fim);
          return `
            <div onclick="openBookingModalWithDate('${dateStr}', '${inicioStr}', '${fimStr}')" class="p-3 rounded-lg border-2 bg-white border-gray-200 hover:border-green-500 cursor-pointer hover:bg-green-50 transition-all mb-2">
              <div class="flex items-center gap-2">
                <div class="w-2 h-2 rounded-full bg-emerald-500"></div>
                <span class="font-bold text-gray-800">Disponível: ${inicioStr} até ${fimStr}</span>
              </div>
            </div>
          `;
        }).join('');
      }

      container.innerHTML = html;
    }

    // Exibe um resumo rápido de um agendamento em um toast, ao clicar em
    // "Ver detalhes" em um horário ocupado.
    function showBookingDetails(backendId) {
      const booking = bookings.find(item => item.__backendId === backendId);
      if (!booking) return;
      showToast(`${booking.responsible ? booking.responsible + ' • ' : (booking.status === 'approved' ? 'Reservado • ' : 'Em análise • ')}${formatDate(booking.date)} • ${booking.time_slot} • ${booking.purpose}${booking.equipment_requests ? ' • ' + booking.equipment_requests : ''}`);
    }

    // Abre o modal de novo agendamento "cru": usado pela Ação Rápida do
    // administrador (já autenticado via config.php/login.php), que
    // preenche o Responsável livremente ao criar uma reserva manual.
    // Para a entrada pública (clique num horário do Calendário), use
    // openBookingModalWithDate, que exige login de aluno/servidor.
    // Reserva manual da coordenação: só quando o modal é aberto pelo botão
    // "Novo Agendamento" do painel admin (que chama esta função direto).
    // Clique num horário do calendário e edição de pedido próprio são do
    // aluno/servidor logado — ver openBookingModalWithDate() e
    // abrirEdicaoAgendamento(), que desligam isto.
    let modoReservaManual = false;

    // O pedido em andamento é reserva manual da coordenação?
    function comoReservaAdmin() {
      return modoReservaManual && Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin);
    }

    function openBookingModal() {
      modoReservaManual = true;
      // Sempre começa como "novo agendamento"; abrirEdicaoAgendamento()
      // troca para o modo de edição logo depois, quando for o caso.
      editandoAgendamentoId = null;
      document.getElementById('booking-modal-title').textContent = 'Novo Agendamento';
      document.getElementById('submit-booking-btn').textContent = 'Agendar';
      document.getElementById('booking-modal').classList.remove('hidden');
      document.getElementById('booking-form').reset();
      // Desfaz uma eventual trava deixada por um login anterior de
      // aluno/servidor nesta mesma aba do navegador.
      document.getElementById('booking-responsible').readOnly = false;
      document.getElementById('booking-suggestion').classList.add('hidden');
      renderBookingEquipmentChoices();
    }

    // Preenche o campo Responsável com o nome de quem está logado na
    // Área do aluno/servidor e trava o campo (readonly), impedindo que
    // alguém agende em nome de outra pessoa.
    function aplicarResponsavelLogado() {
      const sessao = obterUsuarioLogado();
      if (!sessao) return;
      const input = document.getElementById('booking-responsible');
      input.value = sessao.nome;
      input.readOnly = true;
    }

    // Atalho que abre o modal de agendamento já com data, início e
    // término preenchidos, a partir de um clique em um intervalo livre
    // no Calendário público. Exige que a pessoa esteja logada na Área
    // do aluno/servidor (agora em acesso.php) — sem isso, manda a
    // pessoa pra lá em vez de abrir o agendamento.
    function openBookingModalWithDate(date, inicio, fim) {
      const isAdmin = Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin);
      const sessao = obterUsuarioLogado();
      // O administrador (coordenação, logado via login.php) também agenda
      // pelo clique no horário — vira uma reserva manual da coordenação.
      // Só manda fazer login quem não é admin E não tem sessão de aluno.
      // (Antes isto só olhava a sessão de aluno, então o admin, mesmo
      // logado, via "Faça login" e era mandado para acesso.php.)
      if (!sessao && !isAdmin) {
        showToast('❌ Faça login ou solicite seu cadastro para agendar.');
        setTimeout(() => { window.location.href = 'acesso.php'; }, 900);
        return;
      }
      openBookingModal(); // já deixa modoReservaManual = true
      document.getElementById('booking-date').value = date;
      document.getElementById('booking-start').value = inicio;
      document.getElementById('booking-end').value = fim;
      if (sessao) {
        // Aluno/servidor logado: o pedido é dele — responsável travado no
        // próprio nome e não é reserva manual da coordenação.
        modoReservaManual = false;
        aplicarResponsavelLogado();
      }
      // Admin: mantém modoReservaManual = true (reserva manual) e o campo
      // Responsável livre, para a coordenação informar de quem é a reserva.
    }

    // Fecha o modal de novo agendamento.
    function closeBookingModal() {
      document.getElementById('booking-modal').classList.add('hidden');
      editandoAgendamentoId = null;
    }

    // ---------------------------------------------------------------
    // Editar o próprio agendamento (só enquanto está pendente): o botão
    // Editar de "Meus agendamentos" (acesso.php) traz para cá com
    // ?editar=<id>; init() chama abrirEdicaoAgendamento(), que reabre o
    // mesmo formulário de agendamento já preenchido. O envio vira um PUT
    // acao=editar (handleBookingSubmit) — o servidor confere de novo que
    // é o dono e que continua pendente.
    // ---------------------------------------------------------------
    let editandoAgendamentoId = null;

    function abrirEdicaoAgendamento(backendId) {
      const sessao = obterUsuarioLogado();
      const b = bookings.find(item => item.__backendId === String(backendId));
      if (!sessao) {
        showToast('❌ Faça login para editar seu agendamento.');
        return;
      }
      if (!b || String(b.usuario_id) !== String(sessao.backendId)) {
        showToast('❌ Agendamento não encontrado entre os seus.');
        return;
      }
      if (b.status !== 'pending') {
        showToast('Só dá para editar um agendamento enquanto ele está pendente. Se precisar mudar um aprovado, cancele e faça um novo pedido.');
        return;
      }

      openBookingModal();
      modoReservaManual = false; // edição do próprio pedido
      editandoAgendamentoId = b.__backendId;
      document.getElementById('booking-modal-title').textContent = 'Editar agendamento';
      document.getElementById('submit-booking-btn').textContent = 'Salvar alterações';
      document.getElementById('booking-date').value = b.date;
      document.getElementById('booking-start').value = b.start_time;
      document.getElementById('booking-end').value = b.end_time;
      document.getElementById('booking-participants').value = b.participants || '';
      document.getElementById('booking-description').value = b.description || '';
      const finalidade = document.getElementById('booking-purpose');
      if (![...finalidade.options].some(o => o.value === b.purpose)) {
        finalidade.add(new Option(b.purpose, b.purpose)); // finalidade antiga que não está mais na lista
      }
      finalidade.value = b.purpose;
      aplicarResponsavelLogado();

      // Marca os equipamentos já pedidos, com as quantidades.
      let pedidos = [];
      try { pedidos = JSON.parse(b.equipment_quantities || '[]'); } catch (e) { pedidos = []; }
      (Array.isArray(pedidos) ? pedidos : []).forEach(item => {
        const caixa = document.querySelector(`.equipment-choice[value="${CSS.escape(String(item.equipment_id))}"]`);
        if (!caixa || caixa.disabled) return; // equipamento removido ou em manutenção
        caixa.checked = true;
        toggleEquipmentQuantity(caixa);
        const quantidade = caixa.closest('div.flex.flex-col')?.querySelector('.equipment-quantity-input');
        if (quantidade) quantidade.value = String(item.quantity);
      });
    }

    // Desenha, dentro do formulário de agendamento, a lista real de
    // equipamentos cadastrados pela coordenação — com uma miniatura da
    // foto ao lado de cada nome, para quem não conhece o equipamento
    // pelo nome conseguir reconhecê-lo visualmente. Equipamentos fora
    // de "Disponível" aparecem apagados e não podem ser selecionados.
    // Converte o campo de quantidades de equipamentos para uma lista
    // legível. A função também entende o formato antigo (por exemplo,
    // "3") para que agendamentos já salvos continuem aparecendo.
    function formatEquipmentQuantities(valor) {
      if (valor === null || valor === undefined || valor === '') return '';
      try {
        const dados = typeof valor === 'string' ? JSON.parse(valor) : valor;
        if (Array.isArray(dados)) {
          return dados
            .filter(item => item && Number(item.quantity) > 0)
            .map(item => `${item.name}: ${Number(item.quantity)}`)
            .join(' • ');
        }
        if (dados && typeof dados === 'object') {
          return Object.entries(dados)
            .filter(([, quantidade]) => Number(quantidade) > 0)
            .map(([nome, quantidade]) => `${nome}: ${Number(quantidade)}`)
            .join(' • ');
        }
      } catch (erro) {
        // Formato antigo: mantém o valor como texto.
      }
      return String(valor);
    }

    // Extrai uma lista de {nome, quantidade} a partir do valor salvo em
    // equipment_quantities (JSON) ou, na falta dele, do texto livre salvo
    // em equipment_requests (ex.: "notebook (4), imprenssora3d (4)").
    // Usado para desenhar os equipamentos em colunas (nome | quantidade)
    // nos cards de agendamento, em vez de uma única string corrida.
    function getEquipmentPairs(quantitiesValor, requestsTexto) {
      if (quantitiesValor) {
        try {
          const dados = typeof quantitiesValor === 'string' ? JSON.parse(quantitiesValor) : quantitiesValor;
          if (Array.isArray(dados)) {
            return dados
              .filter(item => item && Number(item.quantity) > 0)
              .map(item => ({ nome: String(item.name), quantidade: Number(item.quantity) }));
          }
          if (dados && typeof dados === 'object') {
            return Object.entries(dados)
              .filter(([, quantidade]) => Number(quantidade) > 0)
              .map(([nome, quantidade]) => ({ nome, quantidade: Number(quantidade) }));
          }
        } catch (erro) {
          // Não era JSON válido: cai para o texto livre abaixo.
        }
      }
      if (requestsTexto) {
        return String(requestsTexto).split(',').map(parte => parte.trim()).filter(Boolean).map(parte => {
          const match = parte.match(/^(.*?)\s*\((\d+)\)$/);
          if (match) return { nome: match[1].trim(), quantidade: Number(match[2]) };
          return { nome: parte, quantidade: null };
        });
      }
      return [];
    }

    // Monta o HTML dos equipamentos de um agendamento em colunas
    // (nome numa coluna, quantidade alinhada na outra), em vez da antiga
    // string corrida "notebook (4), imprenssora3d (4)". Retorna '' quando
    // não há equipamentos, para o chamador decidir se mostra o bloco.
    function renderEquipmentColumns(quantitiesValor, requestsTexto) {
      const pares = getEquipmentPairs(quantitiesValor, requestsTexto);
      if (!pares.length) return '';
      const linhas = pares.map(({ nome, quantidade }) => `
        <div class="flex items-baseline justify-between gap-3">
          <span class="truncate">${escapeHtml(nome)}</span>
          <span class="font-semibold whitespace-nowrap">${quantidade !== null ? quantidade + 'x' : ''}</span>
        </div>
      `).join('');
      return `<div class="mt-1 space-y-0.5">${linhas}</div>`;
    }

    // Desenha os equipamentos disponíveis no formulário de agendamento.
    // Cada equipamento mostra a quantidade cadastrada no CIT e possui
    // seu próprio campo "Quantidade a usar", liberado somente quando
    // o equipamento é selecionado.
    function renderBookingEquipmentChoices() {
      const container = document.getElementById('booking-equipment-list');
      if (!container) return;

      const equipamentos = allRecords.filter(item => item.record_type === 'equipment');

      if (!equipamentos.length) {
        container.innerHTML = '<p class="col-span-2 text-xs text-gray-500">Nenhum equipamento cadastrado ainda.</p>';
        return;
      }

      container.innerHTML = equipamentos.map(eq => {
        const indisponivel = eq.condition !== 'Disponível';
        const quantidadeTotal = Math.max(0, Number(eq.quantity) || 0);
        const idSeguro = escapeHtml(eq.__backendId || '');
        const nomeSeguro = escapeHtml(eq.name);
        const situacao = indisponivel
          ? `(${escapeHtml(eq.condition || 'Indisponível')})`
          : `${quantidadeTotal} unidade${quantidadeTotal !== 1 ? 's' : ''} disponível${quantidadeTotal !== 1 ? 'is' : ''}`;

        return `
          <div class="flex flex-col gap-2 p-3 rounded-lg border border-gray-200 ${indisponivel || quantidadeTotal < 1 ? 'opacity-60' : 'hover:border-green-300'}">
            <label class="flex items-center gap-2 ${indisponivel || quantidadeTotal < 1 ? '' : 'cursor-pointer'}">
              <input type="checkbox"
                     value="${idSeguro}"
                     class="equipment-choice"
                     onchange="toggleEquipmentQuantity(this)"
                     ${indisponivel || quantidadeTotal < 1 ? 'disabled' : ''}>
              <span class="w-9 h-9 rounded-lg overflow-hidden bg-green-50 border border-green-200 flex items-center justify-center flex-shrink-0">
                ${eq.photo_url
                  ? `<img src="${eq.photo_url}" alt="Foto de ${nomeSeguro}" loading="lazy" class="w-full h-full object-cover">`
                  : '<span class="text-base">📦</span>'}
              </span>
              <span class="text-gray-800 font-medium">${nomeSeguro}</span>
            </label>
            <div class="ml-1 text-xs font-semibold ${indisponivel || quantidadeTotal < 1 ? 'text-gray-500' : 'text-green-700'}">
              ${indisponivel || quantidadeTotal < 1 ? situacao : `Total no CIT: ${quantidadeTotal} unidade${quantidadeTotal !== 1 ? 's' : ''}`}
            </div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-semibold text-gray-600 flex-1">Quantidade a usar:</span>
              <input
                type="number"
                min="1"
                max="${quantidadeTotal}"
                value="1"
                class="equipment-quantity-input w-20 px-2 py-1.5 border-2 border-green-200 rounded-lg text-center font-bold disabled:bg-gray-100 disabled:text-gray-400"
                data-equipment-id="${idSeguro}"
                ${indisponivel || quantidadeTotal < 1 ? 'disabled' : ''}
                aria-label="Quantidade de ${nomeSeguro} a usar">
            </div>
          </div>
        `;
      }).join('');
    }

    // Ativa/desativa a quantidade individual de um equipamento.
    // Ao marcar o equipamento, começa com 1 unidade para deixar claro
    // que a pergunta é feita para aquele equipamento específico.
    function toggleEquipmentQuantity(checkbox) {
      const quantidadeInput = checkbox.closest('div.flex.flex-col')?.querySelector('.equipment-quantity-input');
      if (!quantidadeInput) return;

      quantidadeInput.disabled = !checkbox.checked;

      if (checkbox.checked && (!quantidadeInput.value || Number(quantidadeInput.value) < 1)) {
        quantidadeInput.value = '1';
      }
    }

    // Processa o envio do formulário de agendamento: valida horários,
    // verifica conflito com reservas aprovadas e, se livre, cria o
    // registro com status "pending" para posterior aprovação.
    async function handleBookingSubmit(event) {
      event.preventDefault();
      // (Havia aqui um limite de 999 agendamentos, sobra do protótipo
      // sem banco — contava também o histórico e travaria o sistema com
      // o uso. O servidor não tem limite.)

      const date = document.getElementById('booking-date').value;
      const responsible = document.getElementById('booking-responsible').value;
      const purpose = document.getElementById('booking-purpose').value;
      const description = document.getElementById('booking-description').value;
      const startTime = document.getElementById('booking-start').value;
      const endTime = document.getElementById('booking-end').value;
      const participants = Number(document.getElementById('booking-participants').value);

      // Cada equipamento agora possui sua própria quantidade. O ID do
      // equipamento é usado internamente para evitar confusão quando
      // houver equipamentos com nomes parecidos ou iguais.
      const equipmentSelections = [...document.querySelectorAll('.equipment-choice:checked')].map(input => {
        const equipment = allRecords.find(item =>
          item.record_type === 'equipment' && item.__backendId === input.value
        );
        const quantityInput = input.closest('div.flex.flex-col')?.querySelector('.equipment-quantity-input');
        const quantity = Number(quantityInput?.value || 0);
        return equipment ? {
          equipment_id: equipment.__backendId,
          name: equipment.name,
          quantity,
          available_quantity: Number(equipment.quantity) || 0
        } : null;
      }).filter(Boolean);

      for (const selection of equipmentSelections) {
        if (selection.quantity < 1) {
          showToast(`Informe quantas unidades de ${selection.name} serão usadas.`);
          return;
        }
        if (selection.quantity > selection.available_quantity) {
          showToast(`A quantidade de ${selection.name} não pode ser maior que ${selection.available_quantity} unidade${selection.available_quantity !== 1 ? 's' : ''}.`);
          return;
        }
      }

      const equipmentRequests = equipmentSelections.map(item => item.name).join(', ');
      const equipmentTotalQuantity = equipmentSelections.reduce((total, item) => total + item.quantity, 0);

      if (startTime >= endTime) { showToast('O horário de término deve ser posterior ao início.'); return; }
      if (paraMinutos(startTime) < paraMinutos(HORARIO_ABERTURA) || paraMinutos(endTime) > paraMinutos(HORARIO_FECHAMENTO)) {
        showToast(`A sala do CIT funciona das ${HORARIO_ABERTURA} às ${HORARIO_FECHAMENTO}. Ajuste o horário.`);
        return;
      }
      const motivoFechado = date ? motivoDiaFechado(date, comoReservaAdmin()) : null;
      if (motivoFechado) {
        showToast(motivoFechado === 'Fechado'
          ? '❌ O CIT não funciona aos domingos.'
          : '❌ Aos sábados o CIT só abre para eventos combinados com a coordenação.');
        return;
      }

      // Ninguém agenda sem estar logado na Área do aluno/servidor — o
      // administrador (sessão PHP real, ver config.php) fica de fora
      // dessa exigência, pois ele pode criar reservas manuais para
      // qualquer pessoa a pedido dela. Cadastro pendente/inativo nem
      // consegue fazer login (api/login_usuario.php), e o servidor
      // confere a sessão de novo ao gravar (criarAgendamento()). Antes
      // isso era conferido procurando o nome em allRecords, mas a API
      // não envia mais a lista de cadastros para quem não é
      // administrador — e nenhum aluno/servidor conseguia agendar.
      const isAdmin = Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin);
      if (!isAdmin && !obterUsuarioLogado()) {
        showToast('❌ Faça login ou solicite seu cadastro para agendar.');
        return;
      }

      const timeSlot = `${startTime} - ${endTime}`;

      // Conflito por sobreposição real de horários (não precisa ser o
      // mesmo intervalo exato — basta que os dois períodos se cruzem).
      // Considera tanto agendamentos já APROVADOS quanto PENDENTES: se
      // já existe alguém aguardando aprovação para aquele horário,
      // ninguém mais (nem a mesma pessoa) pode pedir o mesmo período —
      // evita duas solicitações concorrentes para a mesma sala.
      // Ao editar, o próprio agendamento não conflita consigo mesmo.
      const conflict = bookings.find(b =>
        b.__backendId !== editandoAgendamentoId &&
        b.date === date &&
        (b.status === 'approved' || b.status === 'pending') &&
        paraMinutos(startTime) < paraMinutos(b.end_time) &&
        paraMinutos(b.start_time) < paraMinutos(endTime)
      );

      if (conflict) {
        mostrarSugestoesHorario(date, startTime, endTime, calcularIntervalosLivres(date, editandoAgendamentoId));
        return;
      }

      const submitBtn = document.getElementById('submit-booking-btn');
      const editando = editandoAgendamentoId;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Salvando...';

      try {
        // Novo pedido: POST. Edição do próprio pedido pendente: PUT
        // acao=editar (o servidor confere que é o dono e que ainda está
        // pendente).
        const result = await apiRequest(editando ? 'PUT' : 'POST', 'booking', editando, editando ? 'editar' : null, {
          date,
          start_time: startTime,
          end_time: endTime,
          responsible,
          purpose,
          participants,
          description,
          // Array com o equipamento e a quantidade solicitada; o
          // servidor confere de novo a disponibilidade de cada um e
          // monta equipment_requests/equipment_quantities a partir daí.
          // Reserva manual da coordenação (botão "Novo Agendamento" do
          // painel); sem isto, com aluno logado, o pedido é do aluno.
          reserva_manual: comoReservaAdmin(),
          equipamentos: equipmentSelections.map(item => ({
            equipment_id: item.equipment_id,
            quantity: item.quantity
          }))
          // Quem está agendando (quando não é o administrador) vem da
          // sessão PHP criada em api/login_usuario.php — não é mais
          // enviado pelo navegador.
        });

        if (result.isOk) {
          // O servidor confirmou (HTTP 2xx): o pedido FOI salvo. Fechamos
          // o modal e avisamos o sucesso ANTES de redesenhar a tela, e a
          // atualização vira "best-effort": se alguma função de desenho
          // falhar, o usuário NÃO vê um "erro" falso para um agendamento
          // que na verdade foi criado (era isto que acontecia — aparecia
          // erro mas o agendamento chegava).
          closeBookingModal();
          esconderSugestaoHorario();
          showToast(editando
            ? '✅ Alterações salvas! O pedido continua aguardando a coordenação.'
            : '✅ Agendamento solicitado com sucesso!');
          try {
            await saveRecords();
          } catch (erroAtualizacao) {
            console.error('Agendamento salvo, mas falhou ao atualizar a tela:', erroAtualizacao);
          }
        } else {
          if (result.status === 401 && !isAdmin) {
            // A sessão do servidor expirou: o navegador ainda achava
            // que a pessoa estava logada. Limpa para pedir login de novo.
            localStorage.removeItem(CHAVE_USUARIO_LOGADO);
            renderAreaUsuario();
          }
          // Conflito de horário (ou horário de hoje que já passou): o
          // servidor manda os intervalos livres do dia — calculados com
          // os dados mais recentes, inclusive pedidos feitos por outra
          // pessoa depois que esta página carregou.
          if (result.dados && Array.isArray(result.dados.horarios_livres)) {
            mostrarSugestoesHorario(date, startTime, endTime,
              result.dados.horarios_livres.map(l => ({ inicio: paraMinutos(l.inicio), fim: paraMinutos(l.fim) })));
          }
          showToast('❌ ' + (result.erro || 'Erro ao criar agendamento.'));
        }
      } catch (error) {
        showToast('❌ Erro ao criar agendamento.');
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = editandoAgendamentoId ? 'Salvar alterações' : 'Agendar';
      }
    }

    // Sugestão de horário: quando o horário pedido está ocupado, mostra
    // os intervalos livres daquele dia como botões. Clicar num deles
    // preenche Início/Término com a mesma duração pedida (ou o intervalo
    // inteiro, se ele for mais curto) — a pessoa só confere e reenvia.
    // Os intervalos em que a duração pedida cabe aparecem primeiro.
    // `livres` vem do cálculo local (calcularIntervalosLivres) ou do
    // servidor (campo horarios_livres da resposta de conflito), sempre
    // em minutos desde 00:00.
    function mostrarSugestoesHorario(date, startTime, endTime, livres) {
      const caixa = document.getElementById('booking-suggestion');
      const texto = document.getElementById('suggestion-text');
      if (!caixa || !texto) return;

      const duracao = paraMinutos(endTime) - paraMinutos(startTime);
      const opcoes = [...livres]
        .sort((a, b) => ((b.fim - b.inicio >= duracao) - (a.fim - a.inicio >= duracao)) || a.inicio - b.inicio)
        .slice(0, 6);

      if (!opcoes.length) {
        texto.textContent = `O horário ${startTime} – ${endTime} está ocupado e não há outro horário livre em ${formatDate(date)}. Escolha outra data.`;
      } else {
        texto.innerHTML = `O horário ${escapeHtml(startTime)} – ${escapeHtml(endTime)} está ocupado. Horários livres em ${escapeHtml(formatDate(date))}:`
          + '<span class="flex flex-wrap gap-2 mt-2">'
          + opcoes.map(({ inicio, fim }) => {
              const fimSugerido = Math.min(fim, inicio + duracao);
              const cabe = fim - inicio >= duracao;
              return `<button type="button" onclick="usarHorarioSugerido('${paraHHMM(inicio)}', '${paraHHMM(fimSugerido)}')"
                class="px-3 py-1.5 rounded-lg border-2 border-green-600 bg-white text-green-800 text-sm font-bold hover:bg-green-100 whitespace-nowrap"
                title="${cabe ? 'Usar este horário' : 'Intervalo mais curto que o pedido'}">
                ${paraHHMM(inicio)} – ${paraHHMM(fimSugerido)}${cabe ? '' : ' <span class="font-normal text-xs">(mais curto)</span>'}
              </button>`;
            }).join('')
          + '</span>';
      }
      caixa.classList.remove('hidden');
    }

    // Ao escolher a data no formulário, já mostra os horários livres
    // daquele dia (ou avisa que está lotado) — antes de a pessoa tentar
    // agendar. Antes a caixa de sugestão só aparecia depois de um
    // conflito e ficava na tela mesmo depois de mudar data/horário, com a
    // mensagem antiga de "ocupado", o que parecia que a nova escolha
    // também estava ocupada.
    function mostrarHorariosLivresDoDia() {
      const caixa = document.getElementById('booking-suggestion');
      const texto = document.getElementById('suggestion-text');
      const data = document.getElementById('booking-date')?.value;
      if (!caixa || !texto) return;
      if (!data) { caixa.classList.add('hidden'); return; }

      const motivoFechado = motivoDiaFechado(data, comoReservaAdmin());
      const livres = motivoFechado ? [] : calcularIntervalosLivres(data, editandoAgendamentoId);
      const reservasNoDia = bookings.some(b => b.date === data && b.__backendId !== editandoAgendamentoId
        && (b.status === 'approved' || b.status === 'pending'));

      if (motivoFechado) {
        texto.textContent = motivoFechado === 'Fechado'
          ? `O CIT não funciona aos domingos. Escolha outra data.`
          : `Aos sábados o CIT só abre para eventos combinados com a coordenação.`;
      } else if (!livres.length) {
        texto.textContent = `Não há horário livre em ${formatDate(data)} — o dia já está todo reservado (pedidos pendentes também seguram o horário). Escolha outra data.`;
      } else if (!reservasNoDia) {
        caixa.classList.add('hidden'); // dia vazio: tudo livre, nada a avisar
        return;
      } else {
        texto.innerHTML = `Horários livres em ${escapeHtml(formatDate(data))}:<span class="flex flex-wrap gap-2 mt-2">`
          + livres.slice(0, 6).map(({ inicio, fim }) =>
              `<button type="button" onclick="usarHorarioSugerido('${paraHHMM(inicio)}', '${paraHHMM(fim)}')"
                class="px-3 py-1.5 rounded-lg border-2 border-green-600 bg-white text-green-800 text-sm font-bold hover:bg-green-100 whitespace-nowrap">${paraHHMM(inicio)} – ${paraHHMM(fim)}</button>`
            ).join('')
          + '</span>';
      }
      caixa.classList.remove('hidden');
    }

    // Mexeu no horário depois de um aviso de conflito: o aviso antigo não
    // vale mais — some (o horário novo é conferido de novo ao enviar).
    function esconderSugestaoHorario() {
      document.getElementById('booking-suggestion')?.classList.add('hidden');
    }

    document.getElementById('booking-date')?.addEventListener('change', mostrarHorariosLivresDoDia);
    ['booking-start', 'booking-end'].forEach(id =>
      document.getElementById(id)?.addEventListener('input', esconderSugestaoHorario));

    // Botão de sugestão clicado: preenche o formulário e esconde a caixa.
    function usarHorarioSugerido(inicio, fim) {
      document.getElementById('booking-start').value = inicio;
      document.getElementById('booking-end').value = fim;
      document.getElementById('booking-suggestion').classList.add('hidden');
      showToast(`Horário ${inicio} – ${fim} preenchido. Confira e clique em Agendar.`);
    }

    let rejectionBookingId = null;

    // Abre o modal de justificativa de recusa para um agendamento
    // pendente específico.
    function openRejectionModal(backendId) {
      rejectionBookingId = backendId;
      document.getElementById('rejection-reason').value = '';
      document.getElementById('rejection-note').textContent = '';
      document.getElementById('rejection-modal').classList.remove('hidden');
      document.getElementById('rejection-reason').focus();
    }

    // Fecha o modal de justificativa de recusa.
    function closeRejectionModal() {
      rejectionBookingId = null;
      document.getElementById('rejection-modal').classList.add('hidden');
    }

    // Confirma a recusa de um agendamento, exigindo um motivo, e grava o
    // registro com status "rejected" e o texto informado.
    async function confirmRejection() {
      const reason = document.getElementById('rejection-reason').value.trim();
      const button = document.getElementById('confirm-rejection-btn');
      if (!reason) {
        document.getElementById('rejection-note').textContent = 'Informe o motivo antes de confirmar a recusa.';
        return;
      }
      const booking = bookings.find(b => b.__backendId === rejectionBookingId);
      if (!booking) return;
      button.disabled = true;
      button.textContent = 'Salvando...';
      const result = await apiRequest('PUT', 'booking', rejectionBookingId, 'recusar', { motivo: reason });
      button.disabled = false;
      button.textContent = 'Confirmar recusa';
      if (result.isOk) { await saveRecords(); closeRejectionModal(); showToast('✅ Recusa registrada com justificativa.'); }
      else document.getElementById('rejection-note').textContent = result.erro || 'Não foi possível salvar. Tente novamente.';
    }

    // Aprova um agendamento pendente, atualizando seu status para
    // "approved". A checagem de conflito de horário (contra outros
    // agendamentos já aprovados no mesmo dia) é feita pelo servidor —
    // ver acao=aprovar em api/records.php — que devolve um erro claro
    // caso já exista um aprovado sobreposto.
    async function approveBooking(backendId) {
      const result = await apiRequest('PUT', 'booking', backendId, 'aprovar', {});
      if (result.isOk) {
        await saveRecords();
        showToast('✅ Agendamento aprovado!');
      } else {
        showToast('❌ ' + (result.erro || 'Erro ao aprovar.'));
      }
    }

    // Remove definitivamente um agendamento do banco. Usado apenas na
    // aba Agenda da Área Administrativa (protegida por login) — não
    // fica mais exposto na lista pública de agendamentos.
    async function deleteBooking(backendId) {
      const booking = bookings.find(b => b.__backendId === backendId);
      if (!booking) return;

      const identificacao = booking.responsible || booking.purpose || 'agendamento';
      const confirmado = window.confirm(`Deseja confirmar a exclusão desse agendamento de "${identificacao}"?`);
      if (!confirmado) return;

      const result = await apiRequest('DELETE', 'booking', backendId, null, undefined);

      if (result.isOk) {
        await saveRecords();
        showToast('✅ Agendamento removido!');
      } else {
        showToast('❌ ' + (result.erro || 'Erro ao remover.'));
      }
    }

    // Processa o formulário de contato, gravando a mensagem como um
    // registro do tipo "contact" e exibindo a confirmação visual.
    async function handleContactSubmit(event) {
      event.preventDefault();
      const button = event.target.querySelector('button[type="submit"]');
      const name = document.getElementById('contact-name').value.trim();
      const email = document.getElementById('contact-email-input').value.trim();
      const message = document.getElementById('contact-message').value.trim();
      button.disabled = true;
      button.textContent = 'Enviando...';
      const result = await apiRequest('POST', 'contact', null, null, { name, email, message });
      if (result.isOk) {
        document.getElementById('contact-success').classList.remove('hidden');
        document.getElementById('contact-form').reset();
        setTimeout(() => document.getElementById('contact-success').classList.add('hidden'), 5000);
      } else showToast('❌ ' + (result.erro || 'Não foi possível enviar a mensagem.'));
      button.disabled = false;
      button.textContent = 'Enviar Mensagem';
    }

    // Lista os usuários autorizados a agendar (registros do tipo
    // "usuario_autorizado" já aprovados — alunos e servidores) no card
    // "Cadastrar usuário autorizado" da Área Administrativa, cada um
    // com seu papel, um botão para alternar Ativo/Inativo e um botão
    // para remover. Cadastros ainda pendentes (auto-cadastro feito
    // pelo próprio aluno/servidor) aparecem em renderCadastrosPendentes.
    function renderUsuariosAutorizadosList() {
      const container = document.getElementById('lista-usuarios-autorizados');
      // Sem login, a Área Administrativa nem é renderizada no HTML
      // (ver includes/main-content.php) — não há o que atualizar aqui.
      if (!container) return;

      // Filtro de situação e busca (aba Usuários da Central de Gerenciamento).
      const filtro = document.getElementById('usuarios-filtro')?.value || 'aprovados';
      const busca = (document.getElementById('usuarios-busca')?.value || '').trim().toLowerCase();
      const cadastros = allRecords.filter(item => item.record_type === 'usuario_autorizado');
      const porSituacao = {
        aprovados: u => u.aprovacao === 'aprovado',
        ativos: u => u.aprovacao === 'aprovado' && u.ativo,
        inativos: u => u.aprovacao === 'aprovado' && !u.ativo,
        recusados: u => u.aprovacao === 'recusado'
      };
      const usuarios = cadastros
        .filter(porSituacao[filtro] || porSituacao.aprovados)
        .filter(u => !busca || (u.nome || '').toLowerCase().includes(busca) || (u.matricula || '').toLowerCase().includes(busca))
        .sort((a, b) => (a.nome || '').localeCompare(b.nome || '', 'pt-BR'));

      const contagem = document.getElementById('usuarios-contagem');
      if (contagem) {
        const ativos = cadastros.filter(porSituacao.ativos).length;
        const inativos = cadastros.filter(porSituacao.inativos).length;
        contagem.textContent = `${ativos} ativo${ativos !== 1 ? 's' : ''} · ${inativos} inativo${inativos !== 1 ? 's' : ''} · mostrando ${usuarios.length}`;
      }

      if (!usuarios.length) {
        container.innerHTML = busca || filtro !== 'aprovados'
          ? '<p class="text-xs text-gray-500 text-center py-2">Nenhum cadastro encontrado com esse filtro.</p>'
          : '<p class="text-xs text-gray-500 text-center py-2">Ninguém cadastrado ainda — nenhum agendamento será aceito até o primeiro cadastro.</p>';
        return;
      }

      // Recusados: só consulta (motivo) e remoção — para voltar a valer, a
      // pessoa faz um novo pedido com a mesma matrícula, ou o admin a
      // cadastra de novo no formulário ao lado.
      if (filtro === 'recusados') {
        container.innerHTML = usuarios.map(u => `
          <div class="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 bg-white rounded-lg px-3 py-2 border border-red-200">
            <span class="flex-1 basis-48 min-w-0 text-sm font-semibold text-gray-800 break-words">${escapeHtml(u.nome)} <span class="text-xs font-normal text-gray-500">(${u.papel === 'servidor' ? 'Servidor' : 'Aluno'} · matrícula ${escapeHtml(u.matricula || '—')})</span>
              ${u.motivo_recusa ? `<span class="block text-xs font-normal text-red-700">Motivo: ${escapeHtml(u.motivo_recusa)}</span>` : ''}</span>
            <button onclick="removerUsuarioAutorizado('${u.__backendId}')" class="text-gray-400 hover:text-red-600 font-bold text-sm" title="Remover cadastro" aria-label="Remover ${escapeHtml(u.nome)}">✕</button>
          </div>
        `).join('');
        return;
      }

      container.innerHTML = usuarios.map(u => `
        <div class="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 bg-white rounded-lg px-3 py-2 border border-green-200">
          <span class="flex-1 basis-48 min-w-0 text-sm font-semibold text-gray-800 break-words">${escapeHtml(u.nome)} <span class="text-xs font-normal text-gray-500">(${u.papel === 'servidor' ? 'Servidor' : 'Aluno'} · matrícula ${escapeHtml(u.matricula || '—')} · ${u.email ? escapeHtml(u.email) : '<span class="text-amber-700">sem e-mail</span>'})</span></span>
          <div class="flex flex-wrap items-center gap-2">
            <button onclick="definirEmailUsuarioAutorizado('${u.__backendId}')" class="whitespace-nowrap px-2 py-1 rounded-lg border border-gray-200 text-gray-500 hover:text-green-700 hover:border-green-300 font-bold text-xs" title="Definir e-mail para avisos">E-mail</button>
            <button onclick="toggleUsuarioAutorizadoAtivo('${u.__backendId}')" class="whitespace-nowrap px-3 py-1 rounded-full text-xs font-bold ${u.ativo ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}">${u.ativo ? 'Ativo' : 'Inativo'}</button>
            <button onclick="redefinirSenhaUsuarioAutorizado('${u.__backendId}')" class="whitespace-nowrap px-2 py-1 rounded-lg border border-gray-200 text-gray-500 hover:text-green-700 hover:border-green-300 font-bold text-xs" title="Redefinir senha">Redefinir senha</button>
            <button onclick="removerUsuarioAutorizado('${u.__backendId}')" class="text-gray-400 hover:text-red-600 font-bold text-sm" title="Remover cadastro" aria-label="Remover ${escapeHtml(u.nome)}">✕</button>
          </div>
        </div>
      `).join('');
    }

    // Redefine a senha de um usuário autorizado, sem nunca exibir a
    // senha atual — o gestor só consegue DEFINIR uma nova, nunca ver a
    // que já existe (por isso a senha some da lista acima).
    async function redefinirSenhaUsuarioAutorizado(backendId) {
      const usuario = allRecords.find(item => item.__backendId === backendId && item.record_type === 'usuario_autorizado');
      if (!usuario) return;
      const novaSenha = window.prompt(`Nova senha para ${usuario.nome}:`);
      if (!novaSenha) return; // cancelou ou deixou em branco
      if (novaSenha.length < SENHA_MIN_CARACTERES) { showToast(`❌ A senha precisa ter pelo menos ${SENHA_MIN_CARACTERES} caracteres.`); return; }
      const confirmacao = window.prompt('Confirme a nova senha:');
      if (confirmacao === null) return; // cancelou
      if (novaSenha !== confirmacao) { showToast('❌ As senhas digitadas não são iguais. Nada foi alterado.'); return; }
      const result = await apiRequest('PUT', 'usuario_autorizado', backendId, 'redefinir-senha', { senha: novaSenha });
      if (result.isOk) {
        showToast(`✅ Senha de ${usuario.nome} redefinida. Repasse a nova senha para ele(a).`);
      } else {
        showToast('❌ ' + (result.erro || 'Não foi possível redefinir a senha.'));
      }
    }

    // Define (ou corrige) o e-mail de um usuário autorizado — usado nos
    // avisos de aprovação/recusa. Serve principalmente para quem foi
    // cadastrado antes de o campo de e-mail existir.
    async function definirEmailUsuarioAutorizado(backendId) {
      const usuario = allRecords.find(item => item.__backendId === backendId && item.record_type === 'usuario_autorizado');
      if (!usuario) return;
      const email = window.prompt(`E-mail de ${usuario.nome} (deixe vazio para apagar):`, usuario.email || '');
      if (email === null) return; // cancelou
      const result = await apiRequest('PUT', 'usuario_autorizado', backendId, 'definir-email', { email: email.trim() });
      if (result.isOk) {
        await saveRecords();
        showToast(`✅ E-mail de ${usuario.nome} atualizado.`);
      } else {
        showToast('❌ ' + (result.erro || 'Não foi possível salvar o e-mail.'));
      }
    }

    // Lista, na Área Administrativa, os pedidos de auto-cadastro feitos
    // por alunos/servidores na Área do aluno/servidor (Calendário), que
    // ainda aguardam a decisão do gestor.
    function renderCadastrosPendentes() {
      const container = document.getElementById('cadastros-pendentes-lista');
      if (!container) return;

      const pendentes = allRecords.filter(item => item.record_type === 'usuario_autorizado' && item.aprovacao === 'pendente');

      if (!pendentes.length) {
        container.innerHTML = '<p class="text-xs text-gray-500 text-center py-2">Nenhuma solicitação de cadastro pendente.</p>';
        return;
      }

      container.innerHTML = pendentes.map(u => `
        <div class="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 bg-white rounded-lg px-3 py-2 border border-amber-200">
          <span class="flex-1 basis-48 min-w-0 text-sm font-semibold text-gray-800 break-words">${escapeHtml(u.nome)} <span class="text-xs font-normal text-gray-500">(${u.papel === 'servidor' ? 'Servidor' : 'Aluno'} · matrícula ${escapeHtml(u.matricula || '—')}${u.email ? ' · ' + escapeHtml(u.email) : ''})</span></span>
          <div class="flex flex-wrap items-center gap-2">
            <button onclick="aprovarCadastroUsuario('${u.__backendId}')" class="whitespace-nowrap px-3 py-1 rounded-lg bg-green-600 text-white text-xs font-bold">Aceitar</button>
            <button onclick="recusarCadastroUsuario('${u.__backendId}')" class="whitespace-nowrap px-3 py-1 rounded-lg bg-red-100 text-red-700 text-xs font-bold">Recusar</button>
          </div>
        </div>
      `).join('');
    }

    // O gestor aceita um pedido de auto-cadastro: a partir de agora esse
    // aluno/servidor consegue logar e agendar (fica Ativo).
    async function aprovarCadastroUsuario(backendId) {
      const usuario = allRecords.find(item => item.__backendId === backendId && item.record_type === 'usuario_autorizado');
      if (!usuario) return;
      const result = await apiRequest('PUT', 'usuario_autorizado', backendId, 'aprovar', {});
      if (result.isOk) {
        await saveRecords();
        showToast(`✅ Cadastro de ${usuario.nome} aceito.`);
      } else {
        showToast('❌ ' + (result.erro || 'Não foi possível aceitar o cadastro.'));
      }
    }

    // O gestor recusa um pedido de auto-cadastro: diferente de antes,
    // isso NÃO apaga o registro — grava aprovacao='recusado' e o motivo
    // informado, mantendo o histórico (ver acao=recusar em
    // api/records.php). A pessoa some da fila de pendentes e não
    // consegue mais logar, mas o gestor pode consultar o motivo depois.
    async function recusarCadastroUsuario(backendId) {
      const usuario = allRecords.find(item => item.__backendId === backendId && item.record_type === 'usuario_autorizado');
      if (!usuario) return;
      const motivo = window.prompt(`Motivo da recusa do cadastro de ${usuario.nome}:`);
      if (motivo === null) return; // cancelou o prompt
      if (!motivo.trim()) { showToast('❌ Informe o motivo da recusa.'); return; }
      const result = await apiRequest('PUT', 'usuario_autorizado', backendId, 'recusar', { motivo: motivo.trim() });
      if (result.isOk) {
        await saveRecords();
        showToast(`✅ Solicitação de ${usuario.nome} recusada.`);
      } else {
        showToast('❌ ' + (result.erro || 'Não foi possível recusar a solicitação.'));
      }
    }

    // Cadastra um novo usuário autorizado (aluno ou servidor) a partir
    // do nome, senha e papel informados. A senha é definida aqui mesmo
    // pelo administrador, que deve repassá-la para a pessoa — é com
    // ela que o aluno/servidor entra na Área do aluno/servidor, no
    // Calendário, para agendar e ver seus próprios agendamentos. Como
    // é o próprio gestor quem está cadastrando, o registro já nasce
    // aprovado e ativo (sem passar pela fila de pendentes).
    async function cadastrarUsuarioAutorizado() {
      const input = document.getElementById('novo-usuario-nome');
      const inputMatricula = document.getElementById('novo-usuario-matricula');
      const inputSenha = document.getElementById('novo-usuario-senha');
      const inputSenhaConfirmar = document.getElementById('novo-usuario-senha-confirmar');
      const selectPapel = document.getElementById('novo-usuario-papel');
      const nota = document.getElementById('usuario-cadastro-note');
      const nome = input.value.trim();
      const matricula = inputMatricula.value.trim();
      const senha = inputSenha.value;
      const senhaConfirmar = inputSenhaConfirmar.value;
      const papel = selectPapel.value;
      const inputEmail = document.getElementById('novo-usuario-email');
      const email = inputEmail ? inputEmail.value.trim() : '';

      if (!nome) { showToast('Informe o nome do aluno ou servidor.'); return; }
      if (!matricula) { showToast('Informe a matrícula do aluno ou servidor.'); return; }
      if (!senha) { showToast('Defina uma senha de acesso para essa pessoa.'); return; }
      if (senha.length < SENHA_MIN_CARACTERES) { showToast(`❌ A senha precisa ter pelo menos ${SENHA_MIN_CARACTERES} caracteres.`); return; }
      if (senha !== senhaConfirmar) { showToast('❌ As senhas digitadas não são iguais.'); return; }

      // Matrícula de cadastro recusado pode ser reaproveitada (o servidor
      // reabre o mesmo registro — ver criarUsuario() em api/records.php).
      const jaExiste = allRecords.some(item => item.record_type === 'usuario_autorizado' && item.aprovacao !== 'recusado' && (item.matricula || '').toLowerCase() === matricula.toLowerCase());
      if (jaExiste) {
        if (nota) nota.textContent = 'Essa matrícula já está cadastrada.';
        return;
      }

      const result = await apiRequest('POST', 'usuario_autorizado', null, null, {
        nome, matricula, email, senha, papel, origem: 'admin'
      });

      if (result.isOk) {
        showToast(`✅ ${nome} cadastrado(a) como ${papel === 'servidor' ? 'servidor' : 'aluno'}.`);
        input.value = '';
        inputMatricula.value = '';
        if (inputEmail) inputEmail.value = '';
        inputSenha.value = '';
        inputSenhaConfirmar.value = '';
        if (nota) nota.textContent = 'Só quem estiver cadastrado aqui e marcado como Ativo consegue agendar a sala pelo Calendário.';
        await saveRecords();
      } else {
        if (nota) nota.textContent = result.erro || 'Não foi possível cadastrar.';
        showToast('❌ ' + (result.erro || 'Não foi possível cadastrar.'));
      }
    }

    // Alterna a situação (Ativo/Inativo) de um usuário já cadastrado.
    // Enquanto Inativo, essa pessoa não consegue concluir agendamentos.
    async function toggleUsuarioAutorizadoAtivo(backendId) {
      const usuario = allRecords.find(item => item.__backendId === backendId && item.record_type === 'usuario_autorizado');
      if (!usuario) return;
      const result = await apiRequest('PUT', 'usuario_autorizado', backendId, 'toggle-ativo', {});
      if (result.isOk) {
        await saveRecords();
        showToast(`✅ ${usuario.nome} agora está ${!usuario.ativo ? 'ativo' : 'inativo'}.`);
      } else {
        showToast('❌ ' + (result.erro || 'Não foi possível atualizar a situação.'));
      }
    }

    // Remove definitivamente o cadastro de um usuário autorizado.
    async function removerUsuarioAutorizado(backendId) {
      const usuario = allRecords.find(item => item.__backendId === backendId && item.record_type === 'usuario_autorizado');
      if (!usuario) return;
      const confirmado = window.confirm(`Deseja remover definitivamente o cadastro de ${usuario.nome}? Essa ação não pode ser desfeita.`);
      if (!confirmado) return;
      const result = await apiRequest('DELETE', 'usuario_autorizado', backendId, null, undefined);
      if (result.isOk) {
        await saveRecords();
        showToast(`✅ Cadastro de ${usuario.nome} removido.`);
      } else {
        showToast('❌ ' + (result.erro || 'Não foi possível remover o cadastro.'));
      }
    }

    // ---------------------------------------------------------------
    // Área do aluno/servidor: login com nome + senha (definidos pelo
    // administrador no cadastro), sessão guardada no localStorage do
    // navegador, e uma pequena área própria com "Meus agendamentos".
    // Isso é independente da sessão PHP do administrador (config.php).
    // ---------------------------------------------------------------

    const CHAVE_USUARIO_LOGADO = 'CIT_USUARIO_LOGADO';

    // Lê a sessão do aluno/servidor atualmente logado neste navegador,
    // ou null se ninguém tiver feito login.
    function obterUsuarioLogado() {
      try {
        return JSON.parse(localStorage.getItem(CHAVE_USUARIO_LOGADO));
      } catch (e) {
        return null;
      }
    }

    // Processa a solicitação de auto-cadastro de um aluno/servidor: o
    // registro nasce com aprovacao "pendente" e ativo=false, e só passa
    // a valer depois que o gestor aceitar em Cadastros Pendentes de
    // Aprovação, na Área Administrativa.
    async function handleSolicitarCadastro(event) {
      event.preventDefault();
      const nome = document.getElementById('solicitar-nome').value.trim();
      const matricula = document.getElementById('solicitar-matricula').value.trim();
      const senha = document.getElementById('solicitar-senha').value;
      const senhaConfirmar = document.getElementById('solicitar-senha-confirmar').value;
      const papel = document.getElementById('solicitar-papel').value;
      const email = (document.getElementById('solicitar-email')?.value || '').trim();
      const nota = document.getElementById('solicitar-cadastro-note');

      if (!nome || !matricula || !senha || !email) { showToast('Preencha nome, matrícula, e-mail e senha para solicitar o cadastro.'); return; }
      if (senha !== senhaConfirmar) { showToast('❌ As senhas digitadas não são iguais.'); return; }
      if (senha.length < SENHA_MIN_CARACTERES) { showToast(`❌ A senha precisa ter pelo menos ${SENHA_MIN_CARACTERES} caracteres.`); return; }

      // Não dá mais para conferir aqui se a matrícula já existe: a lista
      // completa de aluno/servidor só é enviada pela API para quem está
      // logado como administrador (ver api/records.php), então esta
      // página pública (visitante não logado) não tem mais allRecords
      // com esses itens. O servidor confere a duplicidade de qualquer
      // forma (ver criarUsuario() em api/records.php) e devolve o erro
      // "Essa matrícula já está cadastrada." no result.erro abaixo.
      const result = await apiRequest('POST', 'usuario_autorizado', null, null, {
        nome, matricula, email, senha, papel, origem: 'autocadastro'
      });

      if (result.isOk) {
        showToast('✅ Solicitação enviada! Aguarde a aprovação do gestor do CIT.');
        document.getElementById('cadastro-servidor-form').reset();
        mostrarAreaUsuario('escolha');
      } else {
        if (nota) nota.textContent = result.erro || 'Não foi possível enviar a solicitação.';
        showToast('❌ ' + (result.erro || 'Não foi possível enviar a solicitação.'));
      }
    }

    // Processa o formulário de login da Área do aluno/servidor. A senha
    // é conferida pelo servidor (api/login_usuario.php), com hash — não
    // mais comparando texto puro contra allRecords no navegador — e só
    // libera quem estiver aprovado e ativo.
    async function handleLoginUsuario(event) {
      event.preventDefault();
      const matricula = document.getElementById('login-usuario-matricula').value.trim();
      const senha = document.getElementById('login-usuario-senha').value;

      if (!matricula || !senha) {
        showToast('Informe matrícula e senha.');
        return;
      }

      try {
        const resposta = await fetch('api/login_usuario.php', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ matricula, senha })
        });
        const dados = await resposta.json().catch(() => ({}));

        if (!resposta.ok) {
          showToast('❌ ' + (dados.erro || 'Não foi possível entrar.'));
          return;
        }

        localStorage.setItem(CHAVE_USUARIO_LOGADO, JSON.stringify(dados));
        showToast(`✅ Bem-vindo(a), ${dados.nome}!`);
        document.getElementById('login-usuario-form').reset();
        renderAreaUsuario();
      } catch (erro) {
        showToast('❌ Falha de conexão com o servidor. Verifique sua internet e tente novamente.');
      }
    }

    // Confere com o servidor se a sessão de aluno/servidor guardada no
    // localStorage ainda vale (a sessão PHP pode ter expirado, ou o
    // cadastro pode ter sido desativado depois do login). Se não vale
    // mais, descarta o localStorage para a tela não mostrar alguém
    // "logado" que a API já não reconhece.
    async function sincronizarSessaoUsuario() {
      if (!obterUsuarioLogado()) return;
      try {
        const resposta = await fetch('api/login_usuario.php', { credentials: 'same-origin' });
        if (resposta.status === 401) {
          localStorage.removeItem(CHAVE_USUARIO_LOGADO);
          const dados = await resposta.json().catch(() => ({}));
          if (dados.expirada) showToast('⏱️ Sua sessão foi encerrada por inatividade. Entre novamente.');
        } else if (resposta.ok) {
          const dados = await resposta.json().catch(() => null);
          if (dados) localStorage.setItem(CHAVE_USUARIO_LOGADO, JSON.stringify(dados));
        }
      } catch (erro) {
        // Sem conexão: mantém o que está no navegador; a API recusa
        // qualquer ação de qualquer forma se a sessão não valer.
      }
    }

    // ---------------------------------------------------------------
    // Inatividade: depois de 5 minutos sem mexer no site (mouse,
    // teclado, toque, rolagem), encerra o login de admin e de
    // aluno/servidor e pede para entrar de novo. O limite vem de
    // config/config.php (SESSAO_INATIVIDADE_SEGUNDOS), que também
    // encerra a sessão do lado do servidor — o navegador só antecipa
    // isso e avisa a pessoa.
    //
    // A última atividade fica no localStorage para valer entre abas:
    // quem está usando o site numa aba não é deslogado pela outra.
    // Enquanto a pessoa mexe sem gerar requisição (lendo, preenchendo um
    // formulário), um "ping" (api/sessao.php) a cada minuto mantém a
    // sessão do servidor viva.
    // ---------------------------------------------------------------
    const LIMITE_INATIVIDADE_MS = (Number(resolvedConfig.sessao_inatividade_segundos) || 300) * 1000;
    const CHAVE_ULTIMA_ATIVIDADE = 'CIT_ULTIMA_ATIVIDADE';
    const INTERVALO_PING_MS = 60 * 1000;
    let ultimaAtividadeLocal = Date.now();
    let ultimoPing = Date.now(); // carregar a página já contou como atividade no servidor
    let encerrandoPorInatividade = false;

    function registrarAtividade() {
      const agora = Date.now();
      if (agora - ultimaAtividadeLocal < 2000) return; // mousemove dispara dezenas de vezes por segundo
      ultimaAtividadeLocal = agora;
      try { localStorage.setItem(CHAVE_ULTIMA_ATIVIDADE, String(agora)); } catch (e) {}
    }

    function ultimaAtividade() {
      let outraAba = 0;
      try { outraAba = Number(localStorage.getItem(CHAVE_ULTIMA_ATIVIDADE)) || 0; } catch (e) {}
      return Math.max(ultimaAtividadeLocal, outraAba);
    }

    function haLoginAtivo() {
      return Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin) || Boolean(obterUsuarioLogado());
    }

    async function encerrarPorInatividade() {
      if (encerrandoPorInatividade) return;
      encerrandoPorInatividade = true;
      const eraAdmin = Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin);
      try {
        await fetch('api/sessao.php', { method: 'DELETE', credentials: 'same-origin' });
      } catch (e) {
        // Sem conexão: o servidor encerra sozinho pelo mesmo limite.
      }
      localStorage.removeItem(CHAVE_USUARIO_LOGADO);
      // login.php mostra o aviso de sessão encerrada; acesso.php mostra
      // pelo parâmetro ?sessao=expirada (ver init()).
      window.location.href = eraAdmin ? 'login.php' : 'acesso.php?sessao=expirada';
    }

    async function verificarInatividade() {
      if (encerrandoPorInatividade || !haLoginAtivo()) return;
      const agora = Date.now();
      const ocioso = agora - ultimaAtividade();

      if (ocioso >= LIMITE_INATIVIDADE_MS) {
        encerrarPorInatividade();
        return;
      }

      // Ativo no último minuto, mas sem requisição recente: avisa o
      // servidor. Se ele responder que ninguém está mais logado (a sessão
      // já tinha caído), encerra aqui também.
      if (ocioso < INTERVALO_PING_MS && agora - ultimoPing >= INTERVALO_PING_MS) {
        ultimoPing = agora;
        try {
          const resposta = await fetch('api/sessao.php', { credentials: 'same-origin' });
          const dados = await resposta.json().catch(() => null);
          if (dados && !dados.admin && !dados.usuario) encerrarPorInatividade();
        } catch (e) {
          // Sem conexão agora: tenta de novo no próximo ciclo.
        }
      }
    }

    function iniciarMonitorInatividade() {
      ['mousemove', 'mousedown', 'keydown', 'scroll', 'touchstart', 'wheel'].forEach(evento =>
        window.addEventListener(evento, registrarAtividade, { passive: true })
      );
      try { localStorage.setItem(CHAVE_ULTIMA_ATIVIDADE, String(Date.now())); } catch (e) {}
      setInterval(verificarInatividade, 15 * 1000);
      // Aba que ficou em segundo plano (o navegador atrasa os timers):
      // confere assim que ela volta a ficar visível.
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') verificarInatividade();
      });
    }

    // ---------------------------------------------------------------
    // Novidades em "tempo real" (polling): a cada 15 segundos, com a aba
    // visível e alguém logado, rebusca os registros e compara com os que
    // já estavam carregados:
    //   - aluno/servidor: um agendamento próprio saiu de pendente para
    //     aprovado ou recusado;
    //   - admin: chegou pedido novo de agendamento ou de cadastro.
    // Avisa com showToast() e redesenha a tela. Sem WebSocket — o mesmo
    // GET api/records.php de sempre, com o cabeçalho
    // X-Atualizacao-Automatica para o servidor não contar a consulta
    // como atividade (senão o logout por inatividade nunca aconteceria —
    // ver config/config.php, seção 1b).
    //
    // Redesenhar a tela no meio de um formulário apagaria o que a pessoa
    // já preencheu (ex.: equipamentos escolhidos no modal de
    // agendamento). Então, com um modal aberto ou um campo em uso, o
    // aviso aparece na hora, mas o redesenho espera o próximo ciclo livre.
    // ---------------------------------------------------------------
    const INTERVALO_NOVIDADES_MS = 15 * 1000;
    let timerNovidades = null;
    let redesenhoPendente = false;

    function assinaturaRegistros(registros) {
      return registros
        .map(r => `${r.record_type}:${r.__backendId}:${r.status || r.aprovacao || ''}:${r.updated_at || ''}`)
        .sort()
        .join('|');
    }

    function usuarioEstaEditando() {
      const modalAberto = ['booking-modal', 'rejection-modal', 'equipment-edit-modal']
        .some(id => { const el = document.getElementById(id); return el && !el.classList.contains('hidden'); });
      const ativo = document.activeElement;
      const campoEmUso = ativo && ['INPUT', 'TEXTAREA', 'SELECT'].includes(ativo.tagName);
      return modalAberto || campoEmUso;
    }

    function redesenharTudo() {
      updateUI();
      renderAdminPanels();
      renderUsuariosAutorizadosList();
      renderCadastrosPendentes();
      redesenhoPendente = false;
    }

    // Compara o antes e o depois e devolve as mensagens de aviso.
    function detectarNovidades(antes, depois) {
      const avisos = [];
      const porChave = new Map(antes.map(r => [`${r.record_type}:${r.__backendId}`, r]));
      const isAdmin = Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin);
      const sessao = obterUsuarioLogado();

      depois.forEach(r => {
        const anterior = porChave.get(`${r.record_type}:${r.__backendId}`);
        const tipo = r.record_type || 'booking';

        if (sessao && tipo === 'booking' && String(r.usuario_id) === String(sessao.backendId)
            && anterior && anterior.status === 'pending' && r.status !== 'pending') {
          const quando = `${formatDate(r.date)} às ${r.start_time}`;
          avisos.push(r.status === 'approved'
            ? `✅ Seu agendamento de ${quando} foi aprovado!`
            : `❌ Seu agendamento de ${quando} foi recusado${r.rejection_reason ? ': ' + r.rejection_reason : '.'}`);
        }

        if (isAdmin && tipo === 'booking' && anterior && anterior.status !== 'cancelled' && r.status === 'cancelled') {
          avisos.push(`🔔 ${r.responsible} cancelou o agendamento de ${formatDate(r.date)} às ${r.start_time}${r.cancellation_reason ? ': ' + r.cancellation_reason : '.'}`);
        }
        if (isAdmin && tipo === 'booking' && anterior && anterior.status === 'pending' && r.status === 'pending'
            && `${anterior.date}${anterior.start_time}${anterior.end_time}` !== `${r.date}${r.start_time}${r.end_time}`) {
          avisos.push(`✏️ ${r.responsible} alterou o pedido para ${formatDate(r.date)} às ${r.start_time}.`);
        }

        if (isAdmin && !anterior) {
          if (tipo === 'booking' && r.status === 'pending') {
            avisos.push(`🔔 Novo pedido de agendamento: ${r.responsible}, ${formatDate(r.date)} às ${r.start_time}.`);
          } else if (tipo === 'usuario_autorizado' && r.aprovacao === 'pendente') {
            avisos.push(`🔔 Novo pedido de cadastro: ${r.nome}.`);
          }
        }
      });
      return avisos;
    }

    async function verificarNovidades() {
      if (document.visibilityState !== 'visible' || !haLoginAtivo() || encerrandoPorInatividade) return;

      // Novidade que chegou enquanto a pessoa preenchia algo: redesenha
      // agora que ela terminou.
      if (redesenhoPendente && !usuarioEstaEditando()) redesenharTudo();

      try {
        const resposta = await fetch('api/records.php', {
          credentials: 'same-origin',
          headers: { 'X-Atualizacao-Automatica': '1' }
        });
        if (!resposta.ok) return; // falha silenciosa: tenta no próximo ciclo
        const dados = await resposta.json().catch(() => null);
        if (!Array.isArray(dados)) return;
        if (assinaturaRegistros(dados) === assinaturaRegistros(allRecords)) return;

        const avisos = detectarNovidades(allRecords, dados);
        allRecords = dados;
        bookings = allRecords.filter(item => !item.record_type || item.record_type === 'booking');

        if (usuarioEstaEditando()) {
          redesenhoPendente = true;
        } else {
          redesenharTudo();
        }
        // Vários avisos de uma vez: mostra o primeiro e resume o resto.
        if (avisos.length === 1) showToast(avisos[0]);
        else if (avisos.length > 1) showToast(`${avisos[0]} (+${avisos.length - 1} novidade${avisos.length > 2 ? 's' : ''})`);
      } catch (erro) {
        // Sem conexão agora: tenta no próximo ciclo.
      }
    }

    function iniciarVerificacaoNovidades() {
      const agendar = () => {
        clearInterval(timerNovidades);
        timerNovidades = document.visibilityState === 'visible'
          ? setInterval(verificarNovidades, INTERVALO_NOVIDADES_MS)
          : null; // aba em segundo plano: para de consultar
      };
      document.addEventListener('visibilitychange', () => {
        agendar();
        if (document.visibilityState === 'visible') verificarNovidades(); // voltou: confere na hora
      });
      agendar();
    }

    // Encerra a sessão do aluno/servidor (no servidor e neste navegador).
    async function sairUsuario() {
      try {
        await fetch('api/login_usuario.php', { method: 'DELETE', credentials: 'same-origin' });
      } catch (erro) {
        // Mesmo sem conexão, sai da tela; a sessão no servidor expira sozinha.
      }
      localStorage.removeItem(CHAVE_USUARIO_LOGADO);
      cancelandoAgendamentoId = null;
      showToast('Você saiu da sua área.');
      renderAreaUsuario();
      updateBookingsList();
    }

    // Menu do topo e faixa do calendário conforme o aluno/servidor
    // logado neste navegador: "Olá, Fulano · Sair" no lugar de "Área do
    // aluno", e some a faixa "Para reservar um horário, entre na sua
    // área" (antes continuavam aparecendo mesmo com a pessoa logada).
    function atualizarMenuUsuario() {
      const sessao = obterUsuarioLogado();
      document.querySelectorAll('[data-menu-sem-aluno]').forEach(el => el.classList.toggle('hidden', Boolean(sessao)));
      document.querySelectorAll('[data-menu-com-aluno]').forEach(el => {
        el.classList.toggle('hidden', !sessao);
        el.classList.toggle('flex', Boolean(sessao));
      });
      // Primeiro nome basta no menu (cabe no celular).
      const nome = sessao ? String(sessao.nome || '').trim().split(/\s+/)[0] : '';
      document.querySelectorAll('[data-menu-nome-aluno]').forEach(el => { el.textContent = nome; });
      // A faixa "para reservar, entre na sua área de aluno" também some
      // para o administrador logado — ele reserva direto pelo calendário.
      const isAdmin = Boolean(window.SERVER_CONFIG && window.SERVER_CONFIG.is_admin);
      document.getElementById('faixa-entrar-calendario')?.classList.toggle('hidden', Boolean(sessao) || isAdmin);
      // "Olá, Fulano · Sair" tem largura diferente de "Área do aluno".
      window.ajustarMenu?.();
    }

    // Alterna qual "sub-tela" da Área do aluno/servidor fica visível:
    // 'escolha' (pergunta inicial com os dois botões), 'login',
    // 'cadastro' ou 'esqueci' — nunca mais de uma ao mesmo tempo. Não
    // mexe na área logada, que é controlada por renderAreaUsuario.
    function mostrarAreaUsuario(qual) {
      const escolha = document.getElementById('area-usuario-escolha');
      const formLogin = document.getElementById('login-usuario-form-wrap');
      const formCadastro = document.getElementById('cadastro-servidor-form-wrap');
      const formEsqueci = document.getElementById('esqueci-senha-form-wrap');
      if (!escolha || !formLogin || !formCadastro) return;

      escolha.classList.toggle('hidden', qual !== 'escolha');
      formLogin.classList.toggle('hidden', qual !== 'login');
      formCadastro.classList.toggle('hidden', qual !== 'cadastro');
      if (formEsqueci) formEsqueci.classList.toggle('hidden', qual !== 'esqueci');
    }

    // "Esqueci minha senha": pede ao servidor o envio do link por e-mail
    // (api/recuperar_senha.php). A resposta é sempre a mesma mensagem,
    // exista ou não o cadastro — de propósito, para a tela não revelar
    // quais matrículas/e-mails estão cadastrados.
    async function handleEsqueciSenha(event) {
      event.preventDefault();
      const identificacao = document.getElementById('esqueci-identificacao').value.trim();
      const nota = document.getElementById('esqueci-senha-note');
      const botao = document.getElementById('esqueci-senha-btn');
      if (!identificacao) { showToast('Informe sua matrícula ou seu e-mail.'); return; }

      botao.disabled = true;
      botao.textContent = 'Enviando...';
      try {
        const resposta = await fetch('api/recuperar_senha.php', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identificacao })
        });
        const dados = await resposta.json().catch(() => ({}));
        if (resposta.ok) {
          nota.textContent = dados.mensagem || 'Pedido enviado. Confira seu e-mail.';
          nota.className = 'text-sm text-green-800 mt-3';
          document.getElementById('esqueci-senha-form').reset();
        } else {
          nota.textContent = dados.erro || 'Não foi possível enviar o pedido.';
          nota.className = 'text-sm text-red-700 mt-3';
        }
      } catch (erro) {
        nota.textContent = 'Falha de conexão com o servidor. Verifique sua internet e tente novamente.';
        nota.className = 'text-sm text-red-700 mt-3';
      } finally {
        botao.disabled = false;
        botao.textContent = 'Enviar link';
      }
    }

    // Alterna entre a tela de escolha (com os formulários de login e de
    // solicitação de cadastro) e a área logada (com "Meus
    // agendamentos"), conforme haja ou não uma sessão de aluno/servidor
    // ativa neste navegador. Também atualiza a lista de agendamentos
    // da pessoa logada sempre que os dados mudam.
    function renderAreaUsuario() {
      atualizarMenuUsuario(); // vale em todas as páginas
      const wrapLogado = document.getElementById('area-usuario-logado');
      // A área só existe na seção pública do Calendário — sempre
      // presente no HTML, mas o guard evita erro caso algo mude.
      if (!wrapLogado) return;

      const sessao = obterUsuarioLogado();

      if (!sessao) {
        mostrarAreaUsuario('escolha');
        wrapLogado.classList.add('hidden');
        return;
      }

      mostrarAreaUsuario(null); // esconde escolha, login e cadastro
      wrapLogado.classList.remove('hidden');
      document.getElementById('usuario-logado-nome').textContent = sessao.nome;
      document.getElementById('usuario-logado-papel').textContent = sessao.papel === 'servidor' ? 'Servidor' : 'Aluno';

      const lista = document.getElementById('meus-agendamentos-lista');
      if (!lista) return;
      lista.innerHTML = htmlMeusAgendamentos(sessao);
    }

    // Agendamentos do aluno/servidor logado — pelo id do usuário
    // (agen_usuario_id), não pelo nome: duas pessoas com o mesmo nome
    // viam os agendamentos uma da outra.
    function meusAgendamentos(sessao) {
      return bookings
        .filter(b => b.usuario_id !== null && String(b.usuario_id) === String(sessao.backendId))
        .sort((a, b) => `${a.date}${a.start_time}`.localeCompare(`${b.date}${b.start_time}`));
    }

    // Lista "Meus agendamentos" com as ações de cada um. Usada na área do
    // aluno (acesso.php) e na lista da página inicial, quando há
    // aluno/servidor logado (updateBookingsList).
    function htmlMeusAgendamentos(sessao) {
      const lista = meusAgendamentos(sessao);
      if (!lista.length) {
        return '<p class="text-sm text-gray-500 text-center py-4">Você ainda não tem agendamentos. Escolha um dia no calendário para pedir um horário.</p>';
      }
      return `<div class="space-y-2">${lista.map(cartaoMeuAgendamento).join('')}</div>`;
    }

    function cartaoMeuAgendamento(b) {
      const { texto: statusText, classe: statusClass } = situacaoAgendamento(b.status);
      // Cancelar: pendente ou aprovado que ainda não terminou. Editar:
      // só pendente (depois de aprovado, o caminho é cancelar e pedir
      // de novo) — as mesmas regras o servidor confere.
      const jaTerminou = `${b.date} ${b.end_time}` <= agoraAAAAMMDDHHMM();
      const podeCancelar = (b.status === 'pending' || b.status === 'approved') && !jaTerminou;
      const podeEditar = b.status === 'pending' && !jaTerminou;
      const id = escapeHtml(b.__backendId);
      // Na página inicial o formulário de agendamento está ali mesmo;
      // em acesso.php, o Editar leva para a página inicial (?editar=).
      const botaoEditar = !podeEditar ? ''
        : document.getElementById('booking-modal')
          ? `<button type="button" onclick="abrirEdicaoAgendamento('${id}')" class="text-xs font-semibold text-blue-700 hover:underline whitespace-nowrap">Editar</button>`
          : `<a href="index.php?editar=${encodeURIComponent(b.__backendId)}#calendario" class="text-xs font-semibold text-blue-700 hover:underline whitespace-nowrap">Editar</a>`;
      const botoes = `
        ${b.status === 'approved' ? botaoCalendario(b.__backendId) : ''}
        ${botaoEditar}
        ${podeCancelar && cancelandoAgendamentoId !== b.__backendId ? `<button type="button" onclick="abrirCancelamento('${id}')" class="text-xs font-semibold text-red-600 hover:underline whitespace-nowrap">Cancelar</button>` : ''}`;

      // Cancelamento aberto neste cartão: pede a justificativa aqui mesmo.
      const formCancelamento = cancelandoAgendamentoId === b.__backendId ? `
        <div class="w-full mt-1 p-3 rounded-lg bg-red-50 border border-red-200">
          <label for="motivo-cancelamento-${id}" class="block text-xs font-bold text-red-800 mb-1">Por que você vai cancelar? (a coordenação do CIT vai ver)</label>
          <textarea id="motivo-cancelamento-${id}" rows="2" maxlength="255" class="w-full px-3 py-2 text-sm rounded-md border border-red-200 bg-white" placeholder="Ex.: a turma foi dispensada nesse dia"></textarea>
          <div class="flex flex-wrap gap-2 mt-2">
            <button type="button" onclick="confirmarCancelamento('${id}')" class="px-3 py-1.5 rounded-md bg-red-600 text-white text-xs font-bold hover:bg-red-700">Confirmar cancelamento</button>
            <button type="button" onclick="fecharCancelamento()" class="px-3 py-1.5 rounded-md border border-gray-300 text-gray-700 text-xs font-bold hover:bg-gray-50">Voltar</button>
          </div>
        </div>` : '';

      const equipamentos = renderEquipmentColumns(b.equipment_quantities, b.equipment_requests);
      return `
        <div class="flex flex-wrap items-center justify-between gap-x-3 gap-y-2 bg-white rounded-lg px-3 py-2 border border-gray-200">
          <div class="min-w-0">
            <div class="text-sm font-semibold text-gray-800">${formatDate(b.date)} • ${escapeHtml(b.time_slot)}</div>
            <div class="text-xs text-gray-500">${escapeHtml(b.purpose)}${b.participants ? ` • ${b.participants} participante${b.participants !== 1 ? 's' : ''}` : ''}</div>
            ${equipamentos ? `<div class="text-xs text-gray-500 max-w-xs">${equipamentos}</div>` : ''}
            ${motivoDoAgendamento(b)}
          </div>
          <div class="flex flex-wrap items-center gap-3">
            <span class="px-2 py-1 rounded-full text-xs font-bold ${statusClass}">${statusText}</span>
            ${botoes}
          </div>
          ${formCancelamento}
        </div>
      `;
    }

    // "AAAA-MM-DD HH:MM" de agora (horário local), para comparar com a
    // data/hora de um agendamento.
    function agoraAAAAMMDDHHMM() {
      const d = new Date();
      const p = n => String(n).padStart(2, '0');
      return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
    }

    // Link "Adicionar ao calendário" de um agendamento aprovado: baixa o
    // .ics (api/exportar-ics.php), que o Google Agenda, o Outlook e o
    // calendário do celular importam. Usado em "Meus agendamentos" e na
    // Agenda do painel administrativo.
    function botaoCalendario(backendId) {
      return `<a href="api/exportar-ics.php?id=${encodeURIComponent(backendId)}"
        class="inline-flex items-center gap-1 text-xs font-semibold text-green-700 hover:underline whitespace-nowrap"
        title="Baixar arquivo .ics para o Google Agenda, Outlook ou celular">
        <svg class="w-4 h-4" aria-hidden="true" focusable="false"><use href="assets/img/icones.svg#calendario"></use></svg>Adicionar ao calendário</a>`;
    }

    // Cancelar o próprio agendamento (UC04), com justificativa: o botão
    // Cancelar abre, no próprio cartão de "Meus agendamentos", um campo
    // para o motivo. O servidor confere que quem pede é o dono
    // (cancelarAgendamentoProprio() em api/records.php) e guarda o
    // agendamento como "Cancelado", com o motivo — não apaga mais.
    let cancelandoAgendamentoId = null;

    function abrirCancelamento(backendId) {
      cancelandoAgendamentoId = backendId;
      renderAreaUsuario();
      updateBookingsList(); // a mesma lista aparece na página inicial
      document.getElementById(`motivo-cancelamento-${backendId}`)?.focus();
    }

    function fecharCancelamento() {
      cancelandoAgendamentoId = null;
      renderAreaUsuario();
      updateBookingsList(); // a mesma lista aparece na página inicial
    }

    async function confirmarCancelamento(backendId) {
      const campo = document.getElementById(`motivo-cancelamento-${backendId}`);
      const motivo = (campo?.value || '').trim();
      if (motivo.length < 5) {
        showToast('Explique em poucas palavras o motivo do cancelamento.');
        campo?.focus();
        return;
      }

      const result = await apiRequest('PUT', 'booking', backendId, 'cancelar', { motivo });
      if (!result.isOk) {
        if (result.status === 401) {
          // Sessão do servidor expirou: pede login de novo.
          localStorage.removeItem(CHAVE_USUARIO_LOGADO);
          cancelandoAgendamentoId = null;
          renderAreaUsuario();
        }
        showToast('❌ ' + (result.erro || 'Não foi possível cancelar o agendamento.'));
        return;
      }

      cancelandoAgendamentoId = null;
      showToast('✅ Agendamento cancelado. A coordenação do CIT foi avisada.');
      await saveRecords();
      renderAreaUsuario();
    }

    // Lista o histórico de agendamentos aprovados, aplicando os filtros
    // de mês/data selecionados no painel de Histórico.
    function renderHistoryResults() {
      const target = document.getElementById('history-results');
      if (!target) return;
      const month = document.getElementById('history-month')?.value || '';
      const date = document.getElementById('history-date')?.value || '';
      const records = bookings.filter(b => b.status === 'approved' && (!month || b.date.startsWith(month)) && (!date || b.date === date)).sort((a,b) => `${b.date}${b.start_time}`.localeCompare(`${a.date}${a.start_time}`));
      target.innerHTML = records.length ? records.map(b => `<div class="bg-white p-4 rounded-xl border border-blue-200 mb-3"><div class="font-bold text-gray-800">${formatDate(b.date)} • ${b.start_time}–${b.end_time}</div><div class="text-sm text-gray-600 mt-1"><strong>${escapeHtml(b.responsible)}</strong> utilizou a sala para ${escapeHtml(b.purpose)}, com ${b.participants || 0} participantes.</div><div class="text-xs text-gray-500 mt-1">Equipamentos:${renderEquipmentColumns(b.equipment_quantities, b.equipment_requests) || ' Nenhum'}</div></div>`).join('') : '<p class="text-gray-500 text-center py-6">Nenhum registro encontrado para o período selecionado.</p>';
    }

    function filterHistory() { renderHistoryResults(); }

    // Relatório de Uso em PDF (api/exportar-pdf.php), com os mesmos
    // filtros de mês/data escolhidos na aba Histórico.
    const ICONE_DOWNLOAD_PDF = '<svg class="w-4 h-4" aria-hidden="true" focusable="false"><use href="assets/img/icones.svg#download"></use></svg>';
    function exportarPdfHistorico() {
      const parametros = new URLSearchParams();
      const mes = document.getElementById('history-month')?.value || '';
      const data = document.getElementById('history-date')?.value || '';
      if (mes) parametros.set('mes', mes);
      if (data) parametros.set('data', data);
      const consulta = parametros.toString();
      window.location.href = 'api/exportar-pdf.php' + (consulta ? '?' + consulta : '');
      showToast('📄 Gerando o relatório em PDF...');
    }
    function clearHistoryFilters() { document.getElementById('history-month').value = ''; document.getElementById('history-date').value = ''; renderHistoryResults(); }

    // Alterna entre as abas do painel administrativo (Agenda, Histórico,
    // Equipamentos), destacando a aba ativa.
    function showAdminPanel(panel) {
      const painel = document.getElementById(`admin-panel-${panel}`);
      const aba = document.getElementById(`admin-tab-${panel}`);
      if (!painel || !aba) return; // Botões só existem para quem está logado.
      document.querySelectorAll('.admin-panel').forEach(el => el.classList.add('hidden'));
      document.querySelectorAll('.admin-tab').forEach(el => {
        el.className = 'admin-tab px-4 py-2 rounded-lg bg-white border-2 border-green-200 text-gray-700 font-bold text-sm';
      });
      painel.classList.remove('hidden');
      aba.className = 'admin-tab px-4 py-2 rounded-lg bg-green-600 text-white font-bold text-sm';
      renderAdminPanels();
      if (panel === 'auditoria') carregarAuditoria();
    }

    // ---------------------------------------------------------------
    // Aba Auditoria: quem fez cada ação administrativa e quando (tabela
    // log_auditoria, lida de api/records.php?tipo=auditoria). Carrega
    // só quando a aba é aberta — o log não vem junto do refreshRecords().
    // ---------------------------------------------------------------
    const ACOES_AUDITORIA = {
      aprovar_agendamento: 'Aprovou agendamento',
      recusar_agendamento: 'Recusou agendamento',
      criar_agendamento: 'Criou agendamento (reserva manual)',
      remover_agendamento: 'Removeu agendamento',
      editar_agendamento: 'Editou o próprio pedido',
      cancelar_agendamento: 'Cancelou o próprio agendamento',
      aprovar_cadastro: 'Aceitou cadastro',
      recusar_cadastro: 'Recusou cadastro',
      cadastrar_usuario: 'Cadastrou usuário',
      ativar_usuario: 'Ativou usuário',
      desativar_usuario: 'Desativou usuário',
      redefinir_senha: 'Redefiniu senha',
      definir_email: 'Alterou e-mail',
      remover_usuario: 'Removeu usuário',
      cadastrar_equipamento: 'Cadastrou equipamento',
      editar_equipamento: 'Editou equipamento',
      remover_equipamento: 'Removeu equipamento',
      atualizar_mensagem: 'Atualizou mensagem',
      remover_mensagem: 'Removeu mensagem'
    };

    async function carregarAuditoria() {
      const painel = document.getElementById('admin-panel-auditoria');
      if (!painel) return;

      // Monta o filtro uma vez só (mantém a opção escolhida ao recarregar).
      if (!document.getElementById('auditoria-filtro')) {
        const opcoes = Object.entries(ACOES_AUDITORIA)
          .map(([valor, rotulo]) => `<option value="${valor}">${escapeHtml(rotulo)}</option>`).join('');
        painel.innerHTML = `
          <div class="flex flex-wrap items-end gap-3 mb-4">
            <div class="min-w-0 max-w-full">
              <label for="auditoria-filtro" class="block text-xs font-bold text-gray-700 mb-1">Tipo de ação</label>
              <select id="auditoria-filtro" onchange="carregarAuditoria()" class="max-w-full px-3 py-2 rounded-lg border-2 border-green-200 bg-white text-sm font-medium">
                <option value="">Todas as ações</option>${opcoes}
              </select>
            </div>
            <p class="text-xs text-gray-500 pb-2">Mostra as 200 ações mais recentes.</p>
          </div>
          <div id="auditoria-lista"></div>`;
      }

      const lista = document.getElementById('auditoria-lista');
      const filtro = document.getElementById('auditoria-filtro').value;
      lista.innerHTML = '<p class="text-gray-500 text-center py-6">Carregando...</p>';

      let url = 'api/records.php?tipo=auditoria';
      if (filtro) url += `&acao=${encodeURIComponent(filtro)}`;
      try {
        const resposta = await fetch(url, { credentials: 'same-origin' });
        const dados = await resposta.json().catch(() => []);
        if (!resposta.ok) {
          lista.innerHTML = `<p class="text-red-700 text-center py-6">${escapeHtml((dados && dados.erro) || 'Não foi possível carregar o log.')}</p>`;
          return;
        }
        if (!dados.length) {
          lista.innerHTML = '<p class="text-gray-500 text-center py-6">Nenhuma ação registrada ainda.</p>';
          return;
        }
        lista.innerHTML = dados.map(item => {
          const [data, hora = ''] = String(item.created_at).split(' ');
          return `
            <div class="flex flex-wrap items-start justify-between gap-x-3 gap-y-1 bg-white p-3 rounded-xl border border-green-200 mb-2">
              <div class="min-w-0 flex-1">
                <div class="text-sm font-bold text-gray-800">${escapeHtml(ACOES_AUDITORIA[item.acao] || item.acao)}</div>
                ${item.detalhes ? `<div class="text-sm text-gray-600 break-words">${escapeHtml(item.detalhes)}</div>` : ''}
              </div>
              <div class="text-xs text-gray-500 text-right">
                <div class="whitespace-nowrap">${formatDate(data)} ${escapeHtml(hora.slice(0, 5))}</div>
                <div>por <strong>${escapeHtml(item.usuario)}</strong></div>
              </div>
            </div>`;
        }).join('');
      } catch (erro) {
        lista.innerHTML = '<p class="text-red-700 text-center py-6">Falha de conexão com o servidor.</p>';
      }
    }

    // Redesenha o conteúdo das três abas administrativas: agenda completa,
    // filtros de histórico e cadastro/lista de equipamentos.
    function renderAdminPanels() {
      const agenda = document.getElementById('admin-panel-agenda');
      const historico = document.getElementById('admin-panel-historico');
      const equipamentos = document.getElementById('admin-panel-equipamentos');
      // Sem login, esses elementos não existem no HTML (ver
      // includes/main-content.php) — nada a redesenhar aqui.
      if (!agenda || !historico || !equipamentos) return;
      const sorted = [...bookings].sort((a,b) => `${a.date}${a.start_time}`.localeCompare(`${b.date}${b.start_time}`));
      agenda.innerHTML = sorted.length ? sorted.map(b => `<div class="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl border border-green-200 mb-3"><div><strong>${escapeHtml(b.responsible)}</strong><div class="text-sm text-gray-600">${formatDate(b.date)} • ${b.start_time}–${b.end_time} • ${escapeHtml(b.purpose)}</div><div class="text-xs text-gray-500">${b.participants || 0} participantes</div>${motivoDoAgendamento(b)}${(b.equipment_quantities || b.equipment_requests) ? `<div class="text-xs text-gray-500">Equipamentos:${renderEquipmentColumns(b.equipment_quantities, b.equipment_requests)}</div>` : ''}</div><div class="flex flex-wrap items-center gap-3"><span class="px-3 py-1 rounded-full text-xs font-bold ${situacaoAgendamento(b.status).classe}">${situacaoAgendamento(b.status).texto}</span>${b.status === 'approved' ? botaoCalendario(b.__backendId) : ''}<button onclick="deleteBooking('${b.__backendId}')" class="px-3 py-2 rounded-lg border-2 border-red-200 text-red-700 hover:bg-red-50 font-bold text-xs" title="Excluir agendamento">Excluir</button></div></div>`).join('') : '<p class="text-gray-500 text-center py-6">Nenhum agendamento cadastrado.</p>';
      historico.innerHTML = `<div class="bg-blue-50 border-2 border-blue-200 rounded-xl p-4 mb-5"><div class="grid grid-cols-1 sm:grid-cols-2 gap-3"><div><label for="history-month" class="block text-xs font-bold text-gray-700 mb-1">Filtrar por mês</label><input id="history-month" type="month" onchange="filterHistory()" class="w-full px-3 py-2 rounded-lg border-2 border-blue-200"></div><div><label for="history-date" class="block text-xs font-bold text-gray-700 mb-1">Filtrar por data</label><input id="history-date" type="date" onchange="filterHistory()" class="w-full px-3 py-2 rounded-lg border-2 border-blue-200"></div></div><div class="flex flex-wrap items-center gap-4 mt-3"><button onclick="clearHistoryFilters()" class="text-sm font-bold text-blue-700 underline">Limpar filtros</button><button onclick="exportarPdfHistorico()" class="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-green-700 text-white text-sm font-bold hover:bg-green-800">${ICONE_DOWNLOAD_PDF} Exportar PDF</button></div></div><div id="history-results"></div>`;
      renderHistoryResults();
      equipamentos.innerHTML = `<div class="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-2"><input id="new-equipment-name" aria-label="Nome do equipamento" placeholder="Nome do equipamento" class="px-4 py-3 rounded-lg border-2 border-green-200"><select id="new-equipment-type" aria-label="Tipo do equipamento" class="px-4 py-3 rounded-lg border-2 border-green-200"><option value="Informática">Informática</option><option value="Audiovisual">Audiovisual</option><option value="Mobiliário">Mobiliário</option><option value="Outro">Outro</option></select><input id="new-equipment-category" aria-label="Classificação do equipamento" placeholder="Classificação (ex.: Projeção)" class="px-4 py-3 rounded-lg border-2 border-green-200"><div><label for="new-equipment-photo" class="sr-only">Foto do equipamento</label><input id="new-equipment-photo" aria-label="Foto do equipamento" type="file" accept="image/*" class="w-full px-3 py-2.5 rounded-lg border-2 border-green-200 bg-white text-sm"></div><input id="new-equipment-quantity" aria-label="Quantidade" type="number" min="1" value="1" class="px-4 py-3 rounded-lg border-2 border-green-200"><select id="new-equipment-condition" aria-label="Situação" class="px-4 py-3 rounded-lg border-2 border-green-200"><option>Disponível</option><option>Indisponível</option><option>Em manutenção</option></select><button onclick="addEquipment()" class="px-5 py-3 rounded-lg bg-green-600 text-white font-bold">Cadastrar equipamento</button></div><p class="text-xs text-gray-500 mb-5">Escolha uma foto do seu computador ou celular (opcional, ideal até 1MB) — ela ajuda quem for agendar a reconhecer o equipamento.</p><div id="equipment-list"></div>`;
      renderEquipmentList();
    }

    // Calcula quantas unidades de um equipamento estão comprometidas em
    // agendamentos aprovados DE HOJE EM DIANTE — o maior número usado em
    // um mesmo agendamento (a sala é uma só, então dois agendamentos
    // aprovados nunca se sobrepõem no horário). Antes somava todos os
    // aprovados de todas as datas, inclusive os que já passaram: com o
    // tempo o equipamento aparecia como esgotado para sempre. É também
    // o mínimo que o total do equipamento pode ter ao ser editado (mesma
    // regra de atualizarEquipamento() em api/records.php). A quantidade
    // é lida do campo equipment_quantities, que guarda cada equipamento
    // separadamente.
    function getApprovedEquipmentQuantity(equipmentId, equipmentName) {
      const agora = new Date();
      const hojeStr = `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, '0')}-${String(agora.getDate()).padStart(2, '0')}`;
      return bookings
        .filter(b => b.status === 'approved' && b.date >= hojeStr)
        .reduce((maior, booking) => {
          let itens = [];
          try {
            itens = JSON.parse(booking.equipment_quantities || '[]');
            if (!Array.isArray(itens)) itens = [];
          } catch (e) {
            itens = [];
          }

          const nesteAgendamento = itens.reduce((soma, item) => {
            const mesmoId = equipmentId && item.equipment_id === equipmentId;
            const mesmoNome = !equipmentId && equipmentName &&
              String(item.name || '').trim().toLowerCase() === String(equipmentName || '').trim().toLowerCase();
            return soma + (mesmoId || mesmoNome ? Math.max(0, Number(item.quantity) || 0) : 0);
          }, 0);
          return Math.max(maior, nesteAgendamento);
        }, 0);
    }

    // Lista os equipamentos cadastrados (registros do tipo "equipment"),
    // mostrando a quantidade TOTAL cadastrada e a quantidade DISPONÍVEL
    // (o que sobra no agendamento aprovado futuro que mais usa o item).
    function renderEquipmentList() {
      const list = document.getElementById('equipment-list');
      if (!list) return;
      const items = allRecords.filter(b => b.record_type === 'equipment');
      list.innerHTML = items.length ? items.map(e => {
        const total = Math.max(0, Number(e.quantity) || 0);
        const reservados = Math.min(total, getApprovedEquipmentQuantity(e.__backendId, e.name));
        const disponiveis = Math.max(0, total - reservados);
        const disponivelClass = disponiveis > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800';

        return `<div class="flex flex-wrap items-center justify-between gap-4 bg-white p-4 rounded-xl border border-green-200 mb-3"><div class="flex flex-wrap items-center gap-4 min-w-0"><div class="w-16 h-16 shrink-0 rounded-xl overflow-hidden bg-green-50 border border-green-200 flex items-center justify-center">${e.photo_url ? `<img src="${e.photo_url}" alt="Foto de ${escapeHtml(e.name)}" loading="lazy" class="w-full h-full object-cover" onerror="this.style.display='none';this.parentElement.textContent='📦'">` : '<span class="text-2xl">📦</span>'}</div><div class="min-w-0"><strong>${escapeHtml(e.name)}</strong><div class="text-sm text-gray-600">${escapeHtml(e.equipment_type) || 'Não classificado'} • ${escapeHtml(e.category) || 'Sem classificação'}</div><div class="flex flex-wrap gap-2 mt-2"><span class="text-xs font-bold px-3 py-1 rounded-full bg-blue-100 text-blue-800">Total: ${total}</span><span class="text-xs font-bold px-3 py-1 rounded-full ${disponivelClass}">Disponível: ${disponiveis}</span>${reservados > 0 ? `<span class="text-xs font-bold px-3 py-1 rounded-full bg-amber-100 text-amber-800">Reservado: ${reservados}</span>` : ''}</div></div></div><div class="flex flex-wrap items-center gap-2"><span class="text-xs font-bold px-3 py-1 rounded-full bg-green-100 text-green-800">${escapeHtml(e.condition)}</span><button onclick="openEditEquipmentModal('${e.__backendId}')" class="px-3 py-2 rounded-lg border-2 border-green-300 text-green-700 hover:bg-green-50 font-bold text-xs">Editar</button><button onclick="showEquipmentDetails('${e.__backendId}')" class="px-3 py-2 rounded-lg border-2 border-blue-200 text-blue-700 hover:bg-blue-50 font-bold text-xs">Ver detalhes</button><button onclick="deleteEquipment('${e.__backendId}')" class="px-3 py-2 rounded-lg border-2 border-red-200 text-red-700 hover:bg-red-50 font-bold text-xs">Remover</button></div></div>`;
      }).join('') : '<p class="text-gray-500 text-center py-6">Nenhum equipamento cadastrado. Cadastre o primeiro acima.</p>';
    }

    // Mostra os detalhes de um equipamento em um toast.
    function showEquipmentDetails(backendId) {
      const equipment = allRecords.find(item => item.__backendId === backendId && item.record_type === 'equipment');
      if (!equipment) return;
      showToast(`${equipment.name} • Tipo: ${equipment.equipment_type || 'Não informado'} • Classificação: ${equipment.category || 'Não informada'} • Quantidade: ${equipment.quantity} • Situação: ${equipment.condition}`);
    }

    // Remove um equipamento cadastrado.
    async function deleteEquipment(backendId) {
      const equipment = allRecords.find(item => item.__backendId === backendId && item.record_type === 'equipment');
      if (!equipment) return;

      const confirmado = window.confirm(`Deseja confirmar a exclusão desse equipamento "${equipment.name}"?`);
      if (!confirmado) return;

      const result = await apiRequest('DELETE', 'equipment', backendId, null, undefined);
      if (result.isOk) {
        await saveRecords();
        showToast('✅ Equipamento removido!');
      } else {
        showToast('❌ ' + (result.erro || 'Não foi possível remover o equipamento.'));
      }
    }

    // Lê um arquivo escolhido pelo usuário (input type="file") e devolve
    // seu conteúdo como uma data URL em base64, pronta para ser salva no
    // localStorage e usada diretamente em uma tag <img>.
    function lerArquivoComoDataURL(arquivo) {
      return new Promise((resolve, reject) => {
        const leitor = new FileReader();
        leitor.onload = () => resolve(leitor.result);
        leitor.onerror = () => reject(leitor.error);
        leitor.readAsDataURL(arquivo);
      });
    }

    // Cadastra um novo equipamento a partir dos campos do formulário da
    // aba Equipamentos, validando nome e quantidade mínima. A foto é
    // opcional: se o usuário escolher um arquivo, ele é convertido para
    // base64 e salvo junto do registro (sem depender de link externo).
    async function addEquipment() {
      const name = document.getElementById('new-equipment-name').value.trim();
      const equipmentType = document.getElementById('new-equipment-type').value;
      const category = document.getElementById('new-equipment-category').value.trim();
      const quantity = Number(document.getElementById('new-equipment-quantity').value);
      const condition = document.getElementById('new-equipment-condition').value;
      const inputFoto = document.getElementById('new-equipment-photo');
      const arquivoFoto = inputFoto.files && inputFoto.files[0];

      if (!name || quantity < 1) { showToast('Informe o nome e uma quantidade válida.'); return; }

      let photoUrl = '';
      if (arquivoFoto) {
        try {
          photoUrl = await lerArquivoComoDataURL(arquivoFoto);
        } catch (erro) {
          showToast('❌ Não foi possível ler a foto selecionada. O equipamento não foi cadastrado.');
          return;
        }
      }

      const result = await apiRequest('POST', 'equipment', null, null, {
        name, equipment_type: equipmentType, category, photo_url: photoUrl, quantity, condition
      });
      if (result.isOk) { showToast('✅ Equipamento cadastrado!'); await saveRecords(); } else showToast('❌ ' + (result.erro || 'Não foi possível cadastrar.'));
    }

    // Abre o modal de edição já preenchido com os dados atuais do
    // equipamento, e mostra quantas unidades já estão reservadas em
    // agendamentos aprovados (a nova quantidade total não pode ficar
    // abaixo disso, senão o número de "disponíveis" ficaria negativo).
    function openEditEquipmentModal(backendId) {
      const equipment = allRecords.find(item => item.__backendId === backendId && item.record_type === 'equipment');
      if (!equipment) return;

      document.getElementById('edit-equipment-id').value = equipment.__backendId;
      document.getElementById('edit-equipment-name').value = equipment.name || '';
      document.getElementById('edit-equipment-type').value = equipment.equipment_type || 'Informática';
      document.getElementById('edit-equipment-condition').value = equipment.condition || 'Disponível';
      document.getElementById('edit-equipment-category').value = equipment.category || '';
      document.getElementById('edit-equipment-quantity').value = Math.max(0, Number(equipment.quantity) || 0);
      document.getElementById('edit-equipment-photo').value = '';

      const reservados = getApprovedEquipmentQuantity(equipment.__backendId, equipment.name);
      const hint = document.getElementById('edit-equipment-quantity-hint');
      if (hint) {
        hint.textContent = reservados > 0
          ? `${reservados} unidade${reservados !== 1 ? 's' : ''} já reservada${reservados !== 1 ? 's' : ''} em agendamentos aprovados — a quantidade total não pode ficar abaixo disso.`
          : 'Nenhuma unidade reservada em agendamentos aprovados no momento.';
      }

      document.getElementById('equipment-edit-modal').classList.remove('hidden');
    }

    // Fecha o modal de edição de equipamento.
    function closeEditEquipmentModal() {
      document.getElementById('equipment-edit-modal').classList.add('hidden');
    }

    // Salva as alterações feitas no modal de edição: nome, tipo,
    // classificação, situação, quantidade total (permitindo aumentar
    // ou diminuir o estoque) e, opcionalmente, uma nova foto.
    async function submitEditEquipment(event) {
      event.preventDefault();

      const backendId = document.getElementById('edit-equipment-id').value;
      const equipment = allRecords.find(item => item.__backendId === backendId && item.record_type === 'equipment');
      if (!equipment) return;

      const name = document.getElementById('edit-equipment-name').value.trim();
      const equipmentType = document.getElementById('edit-equipment-type').value;
      const category = document.getElementById('edit-equipment-category').value.trim();
      const quantity = Number(document.getElementById('edit-equipment-quantity').value);
      const condition = document.getElementById('edit-equipment-condition').value;
      const inputFoto = document.getElementById('edit-equipment-photo');
      const arquivoFoto = inputFoto.files && inputFoto.files[0];

      if (!name || Number.isNaN(quantity) || quantity < 0) {
        showToast('Informe o nome e uma quantidade válida.');
        return;
      }

      const reservados = getApprovedEquipmentQuantity(equipment.__backendId, equipment.name);
      if (quantity < reservados) {
        showToast(`❌ A quantidade total não pode ser menor que ${reservados} — já reservada em agendamentos aprovados.`);
        return;
      }

      let photoUrl = equipment.photo_url || '';
      if (arquivoFoto) {
        try {
          photoUrl = await lerArquivoComoDataURL(arquivoFoto);
        } catch (erro) {
          showToast('❌ Não foi possível ler a nova foto. Nada foi salvo — tente novamente.');
          return;
        }
      }

      const result = await apiRequest('PUT', 'equipment', equipment.__backendId, null, {
        name,
        equipment_type: equipmentType,
        category,
        quantity,
        condition,
        photo_url: photoUrl
      });

      if (result.isOk) {
        showToast('✅ Equipamento atualizado!');
        closeEditEquipmentModal();
        await saveRecords();
      } else {
        showToast('❌ ' + (result.erro || 'Não foi possível salvar as alterações.'));
      }
    }

    // Gera um arquivo .json com todos os agendamentos e dispara o download
    // no navegador (Blob + link temporário).
    // Gera uma planilha CSV com todos os agendamentos (abre direto no
    // Excel/LibreOffice/Google Planilhas), com colunas em português e
    // datas no formato brasileiro. Antes exportava o JSON cru da API,
    // com campos internos (__backendId, record_type...) que não servem
    // para quem administra o CIT.
    function exportData() {
      if (!bookings.length) {
        showToast('Nenhum agendamento para exportar.');
        return;
      }

      const situacoes = { approved: 'Aprovado', pending: 'Pendente', rejected: 'Recusado', cancelled: 'Cancelado' };

      // Uma célula do CSV: entre aspas (aspas internas dobradas). Texto
      // que começa com = + - @ ganha um apóstrofo na frente, para o Excel
      // não executar como fórmula algo digitado por um usuário no site.
      const celula = (valor) => {
        let texto = String(valor ?? '');
        if (/^[=+\-@]/.test(texto)) texto = "'" + texto;
        return '"' + texto.replace(/"/g, '""') + '"';
      };

      const formatarDataHora = (valor) => {
        if (!valor) return '';
        const [data, hora = ''] = String(valor).split(' ');
        return `${formatDate(data)} ${hora.slice(0, 5)}`.trim();
      };

      const cabecalho = ['Data', 'Início', 'Fim', 'Responsável', 'Finalidade', 'Participantes',
        'Equipamentos', 'Situação', 'Motivo (recusa ou cancelamento)', 'Observações', 'Solicitado em'];

      const linhas = [...bookings]
        .sort((a, b) => `${a.date}${a.start_time}`.localeCompare(`${b.date}${b.start_time}`))
        .map(b => [
          formatDate(b.date),
          b.start_time,
          b.end_time,
          b.responsible,
          b.purpose,
          b.participants || 0,
          getEquipmentPairs(b.equipment_quantities, b.equipment_requests)
            .map(({ nome, quantidade }) => quantidade !== null ? `${nome} (${quantidade})` : nome)
            .join(', '),
          situacoes[b.status] || b.status,
          b.rejection_reason || b.cancellation_reason || '',
          b.description || '',
          formatarDataHora(b.created_at)
        ]);

      // ";" como separador e o BOM (﻿) no início: é o que faz o Excel
      // em português abrir já dividido em colunas e com acentos certos.
      const csv = '﻿' + [cabecalho, ...linhas]
        .map(colunas => colunas.map(celula).join(';'))
        .join('\r\n');

      const agora = new Date();
      const hoje = `${agora.getFullYear()}-${String(agora.getMonth() + 1).padStart(2, '0')}-${String(agora.getDate()).padStart(2, '0')}`;

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `agendamentos-cit-${hoje}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      showToast(`📥 Planilha com ${linhas.length} agendamento${linhas.length !== 1 ? 's' : ''} exportada!`);
    }

    // Formata uma data no padrão ISO (AAAA-MM-DD) para o formato
    // brasileiro (DD/MM/AAAA).
    function formatDate(dateStr) {
      const date = new Date(dateStr + 'T00:00:00');
      return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
    }

    // Converte um timestamp ISO em um texto de tempo relativo
    // ("agora", "5min", "3h", "2d").
    function getRelativeTime(isoString) {
      const date = new Date(isoString);
      const now = new Date();
      const diffMs = now - date;
      const diffMins = Math.floor(diffMs / 60000);
      const diffHours = Math.floor(diffMs / 3600000);
      const diffDays = Math.floor(diffMs / 86400000);
      
      if (diffMins < 1) return 'agora';
      if (diffMins < 60) return `${diffMins}min`;
      if (diffHours < 24) return `${diffHours}h`;
      return `${diffDays}d`;
    }

    // Exibe uma notificação temporária (toast) no canto da tela.
    function showToast(message) {
      const toast = document.getElementById('toast');
      document.getElementById('toast-message').textContent = message;
      toast.classList.remove('translate-y-20', 'opacity-0');
      setTimeout(() => {
        toast.classList.add('translate-y-20', 'opacity-0');
      }, 3000);
    }

    // Alterna a visibilidade do menu de navegação mobile.
    function toggleMobileMenu() {
      document.getElementById('mobile-menu').classList.toggle('hidden');
    }

    // Rola suavemente a página até a seção informada.
    function scrollToSection(sectionId) {
      document.getElementById(sectionId).scrollIntoView({ behavior: 'smooth' });
    }

    // Ponto de entrada: carrega os registros do localStorage, aplica a
    // configuração institucional e desenha toda a interface. A seção
    // Administração só existe no HTML para quem está logado (ver
    // includes/main-content.php); as funções abaixo já verificam isso
    // antes de tentar renderizar qualquer coisa nela.
    async function init() {
      await Promise.all([refreshRecords(), sincronizarSessaoUsuario()]);
      applyConfig(resolvedConfig);
      updateUI();
      renderAdminPanels();
      renderUsuariosAutorizadosList();
      renderCadastrosPendentes();
      renderCalendar();
      iniciarMonitorInatividade();
      iniciarVerificacaoNovidades();
      const parametros = new URLSearchParams(window.location.search);
      if (parametros.get('sessao') === 'expirada') {
        showToast('⏱️ Sua sessão foi encerrada por inatividade. Entre novamente.');
        mostrarAreaUsuario('login');
      }
      // Vindo do botão Editar de "Meus agendamentos": abre o formulário
      // já preenchido e tira o ?editar= do endereço (recarregar a página
      // não reabre a edição).
      if (parametros.get('editar') && document.getElementById('booking-modal')) {
        abrirEdicaoAgendamento(parametros.get('editar'));
        parametros.delete('editar');
        const consulta = parametros.toString();
        history.replaceState(null, '', window.location.pathname + (consulta ? '?' + consulta : '') + window.location.hash);
      }
    }

    init();