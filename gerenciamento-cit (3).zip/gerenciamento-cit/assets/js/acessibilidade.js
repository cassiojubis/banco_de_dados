/**
 * assets/js/acessibilidade.js
 * ---------------------------------------------------------------------
 * Controles de acessibilidade do site, aplicados em TODA página (ver
 * inclusão em includes/footer.php) e configurados na página dedicada
 * acessibilidade.php:
 *   - Tamanho da fonte (escala o <html>, o que escala junto todo o
 *     texto do site, já que o Tailwind usa unidades rem)
 *   - Modo escuro (classe "dark" no <html>, estilizada em
 *     assets/css/acessibilidade.css)
 *   - Idioma (Português/Inglês/Espanhol) via widget do Google Tradutor
 *
 * Todas as preferências ficam salvas no localStorage do navegador e
 * são reaplicadas a cada página visitada.
 * ---------------------------------------------------------------------
 */

(function () {
  'use strict';

  const CHAVE_FONTE = 'CIT_ACESSIBILIDADE_FONTE_V3';
  const CHAVE_MODO_ESCURO = 'CIT_ACESSIBILIDADE_MODO_ESCURO';
  const CHAVE_IDIOMA = 'CIT_IDIOMA';

  // Níveis em % do tamanho do navegador. O padrão do site é 100% (16px —
  // ver assets/css/style.css); daí dá para diminuir um passo ou aumentar
  // até 150% (24px). Na tela, o nível aparece relativo ao padrão
  // (padrão = 100%), que é o que faz sentido para quem usa.
  const NIVEIS_FONTE = [87.5, 100, 112.5, 125, 137.5, 150];
  const NIVEL_FONTE_PADRAO = 100;

  function rotuloNivel(nivel) {
    return Math.round(nivel / NIVEL_FONTE_PADRAO * 100) + '%';
  }

  // ---------------------------------------------------------------
  // Tamanho da fonte
  // ---------------------------------------------------------------

  function obterNivelFonte() {
    const salvo = Number(localStorage.getItem(CHAVE_FONTE));
    return NIVEIS_FONTE.includes(salvo) ? salvo : NIVEL_FONTE_PADRAO;
  }

  function aplicarFonte(nivel) {
    document.documentElement.style.fontSize = nivel + '%';
    localStorage.setItem(CHAVE_FONTE, String(nivel));
    const rotulo = document.getElementById('fonte-nivel-atual');
    if (rotulo) rotulo.textContent = rotuloNivel(nivel);
    ajustarMenu();
  }

  // ---------------------------------------------------------------
  // Menu do topo: as faixas de largura do Tailwind (xl = 1280px) não
  // sabem do tamanho da fonte. Com a fonte aumentada ou zoom, o menu
  // completo não cabia e passava por cima do nome do site. Aqui medimos
  // se ele cabe de verdade; se não, a barra usa o botão ☰ (ver
  // .menu-apertado em assets/css/style.css).
  // ---------------------------------------------------------------

  function ajustarMenu() {
    const barra = document.getElementById('barra-navegacao');
    const linha = document.getElementById('barra-navegacao-linha');
    const marca = document.getElementById('barra-navegacao-marca');
    const menu = document.getElementById('menu-desktop');
    if (!barra || !linha || !marca || !menu) return;

    barra.classList.remove('menu-apertado');
    if (getComputedStyle(menu).display === 'none') return; // tela pequena: já é ☰

    const estiloLinha = getComputedStyle(linha);
    const larguraUtil = linha.clientWidth - parseFloat(estiloLinha.paddingLeft) - parseFloat(estiloLinha.paddingRight);
    const espacoEntre = parseFloat(estiloLinha.columnGap) || 0;
    const naoCabe = marca.scrollWidth + espacoEntre + menu.scrollWidth > larguraUtil;
    barra.classList.toggle('menu-apertado', naoCabe);
  }

  let esperaAjusteMenu = null;
  window.addEventListener('resize', () => {
    clearTimeout(esperaAjusteMenu);
    esperaAjusteMenu = setTimeout(ajustarMenu, 100);
  });
  // A fonte Montserrat chega depois do HTML e muda a largura dos textos.
  if (document.fonts && document.fonts.ready) document.fonts.ready.then(ajustarMenu);
  window.addEventListener('load', ajustarMenu);

  function aumentarFonte() {
    const atual = obterNivelFonte();
    const indice = NIVEIS_FONTE.indexOf(atual);
    aplicarFonte(NIVEIS_FONTE[Math.min(indice + 1, NIVEIS_FONTE.length - 1)]);
  }

  function diminuirFonte() {
    const atual = obterNivelFonte();
    const indice = NIVEIS_FONTE.indexOf(atual);
    aplicarFonte(NIVEIS_FONTE[Math.max(indice - 1, 0)]);
  }

  function restaurarFonte() {
    aplicarFonte(NIVEL_FONTE_PADRAO);
  }

  // ---------------------------------------------------------------
  // Modo escuro
  // ---------------------------------------------------------------

  function estaModoEscuroAtivo() {
    return localStorage.getItem(CHAVE_MODO_ESCURO) === 'true';
  }

  function aplicarModoEscuro(ativo) {
    document.documentElement.classList.toggle('dark', ativo);
    localStorage.setItem(CHAVE_MODO_ESCURO, ativo ? 'true' : 'false');
    const chk = document.getElementById('toggle-modo-escuro');
    if (chk) chk.checked = ativo;
  }

  function alternarModoEscuro() {
    aplicarModoEscuro(!estaModoEscuroAtivo());
  }

  // ---------------------------------------------------------------
  // Idioma — traduzido pelo widget do Google Tradutor. Traduzir à mão
  // todos os textos do site para 3 idiomas está fora do escopo deste
  // protótipo; o widget lê um cookie próprio ("googtrans") para saber
  // qual idioma mostrar, então é isso que gravamos aqui.
  // ---------------------------------------------------------------

  function definirIdioma(codigo) {
    const dominio = location.hostname;
    // Limpa cookies antigos em qualquer domínio/caminho antes de setar o novo
    document.cookie = 'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    document.cookie = 'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=' + dominio + ';';

    if (codigo !== 'pt') {
      document.cookie = 'googtrans=/pt/' + codigo + '; path=/;';
      document.cookie = 'googtrans=/pt/' + codigo + '; path=/; domain=' + dominio + ';';
    }

    localStorage.setItem(CHAVE_IDIOMA, codigo);
    window.location.reload();
  }

  function idiomaAtual() {
    return localStorage.getItem(CHAVE_IDIOMA) || 'pt';
  }

  // ---------------------------------------------------------------
  // Inicialização: marca os controles da página de Acessibilidade
  // (quando ela está aberta) com o estado atual salvo. A aplicação em
  // si de fonte/modo escuro já acontece mais cedo, de forma inline no
  // <head> (ver includes/header.php), para não haver "flash" da
  // versão clara/tamanho padrão antes deste arquivo carregar.
  // ---------------------------------------------------------------

  function inicializarControles() {
    const rotuloFonte = document.getElementById('fonte-nivel-atual');
    if (rotuloFonte) rotuloFonte.textContent = rotuloNivel(obterNivelFonte());

    const chkModoEscuro = document.getElementById('toggle-modo-escuro');
    if (chkModoEscuro) chkModoEscuro.checked = estaModoEscuroAtivo();

    document.querySelectorAll('[data-idioma]').forEach(botao => {
      botao.classList.toggle('acessibilidade-idioma-ativo', botao.dataset.idioma === idiomaAtual());
    });
  }

  window.aumentarFonte = aumentarFonte;
  window.diminuirFonte = diminuirFonte;
  window.restaurarFonte = restaurarFonte;
  window.alternarModoEscuro = alternarModoEscuro;
  window.definirIdioma = definirIdioma;
  window.ajustarMenu = ajustarMenu;

  document.addEventListener('DOMContentLoaded', () => {
    inicializarControles();
    ajustarMenu();
  });
})();
